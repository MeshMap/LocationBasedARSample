// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;
 

namespace MeshMap.XR.Editor.Tools
{
    /// <summary>
    /// Automatic wrapper that detects device-specific packages already present in the project
    /// and wraps their C# files with the appropriate scripting defines to prevent compilation
    /// conflicts. This script does not modify `Packages/manifest.json` in any way.
    /// </summary>
    [InitializeOnLoad]
    public static class UPMWrapper
    {
        // Base platform defines expected from Build Profiles
        private const string DefineMetaQuest = "METAQUEST";
        private const string DefineMagicLeap = "MAGICLEAP";
        private const string DefineXReal = "XREAL";

        // Package wrap rules -> wrap ALL scripts in these packages behind a platform condition
        // We use compound guards to ensure only one platform wins when multiple defines are present
        private static readonly Dictionary<string, string> PackageWrapRules = new Dictionary<string, string>
        {
            // Meta Quest
            ["com.unity.xr.meta-openxr"] = "(" + DefineMetaQuest + ") && !(" + DefineMagicLeap + ") && !(" + DefineXReal + ")",
            ["com.meta.xr.sdk.core"]      = "(" + DefineMetaQuest + ") && !(" + DefineMagicLeap + ") && !(" + DefineXReal + ")",
            ["com.meta.xr.mrutilitykit"]  = "(" + DefineMetaQuest + ") && !(" + DefineMagicLeap + ") && !(" + DefineXReal + ")",

            // Magic Leap
            ["com.magicleap.unitysdk"] = "(" + DefineMagicLeap + ") && !(" + DefineMetaQuest + ") && !(" + DefineXReal + ")",
            ["com.meshmap.sdk.magicleap2"]     = "(" + DefineMagicLeap + ") && !(" + DefineMetaQuest + ") && !(" + DefineXReal + ")",

            // XREAL
            ["com.xreal.xr"] = "(" + DefineXReal + ") && !(" + DefineMetaQuest + ") && !(" + DefineMagicLeap + ")",

            // AprilTag (used for Quest tracking workflows)
            ["jp.keijiro.apriltag.meshmap"] = "(" + DefineMetaQuest + ") && !(" + DefineMagicLeap + ") && !(" + DefineXReal + ")",
        };

        // Optional: specific single-file wraps in MeshMap XR
        private static readonly (string relativeFile, string define)[] MeshMapXrFileWraps = new (string, string)[]
        {
            (Path.Combine("Runtime","MarkerTracking","MarkerTrackingControls.cs"), "(" + DefineMetaQuest + ") && !(" + DefineMagicLeap + ") && !(" + DefineXReal + ")"),
        };

        // Generic platform directory name → define mapping used for any package scan
        private static readonly Dictionary<string, string> PlatformDirNameToDefine = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "MetaQuest",  "(" + DefineMetaQuest + ") && !(" + DefineMagicLeap + ") && !(" + DefineXReal + ")" },
            { "MagicLeap",  "(" + DefineMagicLeap + ") && !(" + DefineMetaQuest + ") && !(" + DefineXReal + ")" },
            { "XREAL",      "(" + DefineXReal + ") && !(" + DefineMetaQuest + ") && !(" + DefineMagicLeap + ")" },
            { "Desktop",    "(" + DefineMetaQuest + ") && !(" + DefineMagicLeap + ") && !(" + DefineXReal + ")" },
        };

        // Packages that must be completely ignored by any wrapping logic
        private static readonly HashSet<string> ExcludedPackagesForWrapping = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            // Unity OpenXR core must not be modified
            "com.unity.xr.openxr",
        };
        
        private static bool isProcessing = false;
        private static int skipNextCompilations = 0;

        // Editor preference key for controlling verbosity of info logs
        private const string VerboseLogsEditorPrefsKey = "MeshMap_UPMWrapper_ShowInfoLogs";

        private static bool IsVerboseLoggingEnabled
        {
            get { return EditorPrefs.GetBool(VerboseLogsEditorPrefsKey, false); }
        }

        private static void LogInfo(string message)
        {
            if (IsVerboseLoggingEnabled)
            {
                Debug.Log(message);
            }
        }
        
        static UPMWrapper()
        {
            // Hook into compilation complete event
            CompilationPipeline.compilationFinished += OnCompilationFinished;
            
            // Run initial check after a delay
            EditorApplication.delayCall += () => 
            {
                if (!EditorApplication.isCompiling && !EditorApplication.isUpdating)
                {
                    OnCompilationComplete();
                }
            };
        }
        
        private static void OnCompilationFinished(object obj)
        {
            // Skip if Unity is still updating or if we should skip
            if (EditorApplication.isUpdating || skipNextCompilations > 0)
            {
                if (skipNextCompilations > 0)
                {
                    skipNextCompilations--;
                    LogInfo($"[UPMWrapper] Skipping compilation cycle (remaining skips: {skipNextCompilations})");
                }
                return;
            }
            
            // Add a small delay to ensure Unity has finished its operations
            EditorApplication.delayCall += () =>
            {
                if (!EditorApplication.isCompiling && !EditorApplication.isUpdating && !isProcessing)
                {
                    OnCompilationComplete();
                }
            };
        }
        
        /// <summary>
        /// Main processing - runs every time compilation is complete from the top
        /// </summary>
        private static void OnCompilationComplete()
        {
            // Prevent re-entry
            if (isProcessing)
            {
                LogInfo("[UPMWrapper] Already processing, skipping...");
                return;
            }
            
            // Don't run if Unity is busy
            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            {
                LogInfo("[UPMWrapper] Unity is busy, skipping...");
                return;
            }
            
            isProcessing = true;
            
            try
            {
                LogInfo("[UPMWrapper] Checking for platform packages to wrap...");

                var wrappedAnything = WrapAllDetectedPlatformPackages();

                if (wrappedAnything)
                {
                    AssetDatabase.Refresh();
                    LogInfo("[UPMWrapper] Wrapping complete. Unity will recompile.");
                }
                else
                {
                    LogInfo("[UPMWrapper] No wrapping needed.");
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"[UPMWrapper] Error during package sync: {e.Message}\n{e.StackTrace}");
            }
            finally
            {
                isProcessing = false;
            }
        }
        
        /// <summary>
        /// Find and wrap all unwrapped platform packages that are present in the project
        /// </summary>
        private static bool WrapAllDetectedPlatformPackages()
        {
            var madeAnyChanges = false;
            foreach (var kvp in PackageWrapRules)
            {
                // Check both possible locations
                var packagePaths = new[]
                {
                    $"Packages/{kvp.Key}",  // Embedded packages
                    GetPackageCachePath(kvp.Key)  // Resolved packages in Library/PackageCache
                };
                
                foreach (var packagePath in packagePaths)
                {
                    if (!string.IsNullOrEmpty(packagePath) && Directory.Exists(packagePath))
                    {
                        // Always attempt wrapping; per-file logic is idempotent and skips already wrapped files
                        LogInfo($"[UPMWrapper] Ensuring wrap for {kvp.Key} at {packagePath} with {kvp.Value}...");
                        var wrappedCount = WrapSDK(packagePath, kvp.Value);
                        if (wrappedCount > 0)
                        {
                            madeAnyChanges = true;
                        }
                    }
                }
            }
            
            // Also scan all embedded packages and cache for platform-named subdirectories and wrap those
            WrapPlatformDirsUnderRoot("Packages", ref madeAnyChanges);
            WrapPlatformDirsUnderRoot("Library/PackageCache", ref madeAnyChanges);

            // Wrap subdirs/files in local MeshMap XR package
            var meshMapXrRoot = GetActualPackagePath("com.meshmap.sdk.xr");
            if (!string.IsNullOrEmpty(meshMapXrRoot) && Directory.Exists(meshMapXrRoot))
            {
                try
                {
                    string[] allDirs = Directory.GetDirectories(meshMapXrRoot, "*", SearchOption.AllDirectories);
                    foreach (string dir in allDirs)
                    {
                        string dirName = new DirectoryInfo(dir).Name;
                        if (PlatformDirNameToDefine.TryGetValue(dirName, out string define))
                        {
                            var wrappedCount = WrapSDK(dir, define);
                            if (wrappedCount > 0)
                            {
                                LogInfo($"[UPMWrapper] Wrapped {wrappedCount} files in {dir} with #if {define}");
                                madeAnyChanges = true;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[UPMWrapper] Error scanning MeshMap.XR directories: {ex.Message}");
                }

                foreach (var (relativeFile, define) in MeshMapXrFileWraps)
                {
                    var targetFile = Path.Combine(meshMapXrRoot, relativeFile);
                    if (File.Exists(targetFile))
                    {
                        if (WrapSingleFile(targetFile, define)) madeAnyChanges = true;
                    }
                }
            }
            return madeAnyChanges;
        }

        private static void WrapPlatformDirsUnderRoot(string root, ref bool madeAnyChanges)
        {
            try
            {
                if (!Directory.Exists(root)) return;
                // Only consider package-like folders (contain package.json)
                foreach (string pkgDir in Directory.GetDirectories(root))
                {
                    var packageJsonPath = Path.Combine(pkgDir, "package.json");
                    if (!File.Exists(packageJsonPath)) continue;

                    // Resolve package name and respect exclusions
                    var packageName = TryGetPackageName(packageJsonPath);
                    if (string.IsNullOrEmpty(packageName))
                    {
                        // Fallback: infer from directory name (e.g., com.unity.xr.openxr@version)
                        var dirName = new DirectoryInfo(pkgDir).Name;
                        int atIdx = dirName.IndexOf('@');
                        packageName = atIdx > 0 ? dirName.Substring(0, atIdx) : dirName;
                    }
                    if (ExcludedPackagesForWrapping.Contains(packageName))
                    {
                        // Skip excluded packages entirely
                        continue;
                    }

                    string[] allDirs = Directory.GetDirectories(pkgDir, "*", SearchOption.AllDirectories);
                    foreach (string dir in allDirs)
                    {
                        string dirName = new DirectoryInfo(dir).Name;
                        if (PlatformDirNameToDefine.TryGetValue(dirName, out string define))
                        {
                            var wrappedCount = WrapSDK(dir, define);
                            if (wrappedCount > 0)
                            {
                                LogInfo($"[UPMWrapper] Wrapped {wrappedCount} files in {dir} with #if {define}");
                                madeAnyChanges = true;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogError($"[UPMWrapper] Error scanning root '{root}' for platform dirs: {ex.Message}");
            }
        }

        private static string TryGetPackageName(string packageJsonPath)
        {
            try
            {
                var json = File.ReadAllText(packageJsonPath);
                var match = Regex.Match(json, "\"name\"\\s*:\\s*\"([^\"]+)\"", RegexOptions.IgnoreCase);
                if (match.Success && match.Groups.Count > 1)
                {
                    return match.Groups[1].Value;
                }
            }
            catch (Exception)
            {
                // ignore
            }
            return null;
        }
        
        /// <summary>
        /// Get the actual path of a package in Library/PackageCache
        /// </summary>
        private static string GetPackageCachePath(string packageName)
        {
            var cacheDir = "Library/PackageCache";
            if (!Directory.Exists(cacheDir))
                return null;
                
            // Package folders in cache include version: com.magicleap.unitysdk.meshmap@version
            var dirs = Directory.GetDirectories(cacheDir, $"{packageName}@*");
            return dirs.Length > 0 ? dirs[0] : null;
        }
        
        /// <summary>
        /// Get the actual path of a package (checks both Packages and Library/PackageCache)
        /// </summary>
        private static string GetActualPackagePath(string packageName)
        {
            // First check embedded packages
            var embeddedPath = $"Packages/{packageName}";
            if (Directory.Exists(embeddedPath))
                return embeddedPath;
                
            // Then check Library/PackageCache
            var cache = GetPackageCachePath(packageName);
            if (!string.IsNullOrEmpty(cache)) return cache;

            // Finally check Packages/manifest.json for a local file: dependency
            var manifestPath = Path.Combine(Application.dataPath, "..", "Packages", "manifest.json");
            if (File.Exists(manifestPath))
            {
                try
                {
                    var text = File.ReadAllText(manifestPath);
                    var key = "\"" + packageName + "\"";
                    var keyIndex = text.IndexOf(key, StringComparison.OrdinalIgnoreCase);
                    if (keyIndex >= 0)
                    {
                        var valueStart = text.IndexOf("\"file:", keyIndex, StringComparison.OrdinalIgnoreCase);
                        if (valueStart >= 0)
                        {
                            var pathStart = valueStart + 7; // '"file:'
                            var pathEnd = text.IndexOf('"', pathStart);
                            if (pathEnd > pathStart)
                            {
                                var local = text.Substring(pathStart, pathEnd - pathStart)
                                    .Replace('/', Path.DirectorySeparatorChar)
                                    .Replace('\\', Path.DirectorySeparatorChar);
                                if (Directory.Exists(local)) return local;
                            }
                        }
                    }
                }
                catch (Exception)
                {
                    // ignore parse errors
                }
            }
            return null;
        }
        
        // Removed heuristic pre-check; we always attempt wrapping and skip per-file if already wrapped
        
        
        
        /// <summary>
        /// Wrap SDK with platform defines
        /// </summary>
        private static int WrapSDK(string sdkRoot, string define)
        {
            try
            {
                string[] csFiles = Directory.GetFiles(sdkRoot, "*.cs", SearchOption.AllDirectories);
                int wrappedCount = 0;
                
                foreach (string file in csFiles)
                {
                    if (WrapSingleFile(file, define)) wrappedCount++;
                }
                
                if (wrappedCount > 0)
                {
                    LogInfo($"[UPMWrapper] Wrapped {wrappedCount} scripts in {sdkRoot} with #if {define}");
                }
                return wrappedCount;
            }
            catch (Exception e)
            {
                Debug.LogError($"[UPMWrapper] Failed to wrap SDK {sdkRoot}: {e.Message}");
                return 0;
            }
        }

        private static bool WrapSingleFile(string file, string define)
        {
            try
            {
                string content = File.ReadAllText(file);
                var first = ReadFirstSignificantLine(content);

                // If already wrapped with a platform gate but not with the exact target expression, replace
                if (!string.IsNullOrEmpty(first) && first.StartsWith("#if "))
                {
                    if (string.Equals(first, $"#if {define}", StringComparison.Ordinal))
                    {
                        return false; // already wrapped with the exact same condition
                    }

                    if (first.StartsWith("#if METAQUEST") || first.StartsWith("#if MAGICLEAP") || first.StartsWith("#if XREAL"))
                    {
                        var replaced = Regex.Replace(content, "^\\s*#if (METAQUEST|MAGICLEAP|XREAL)", $"#if {define}", RegexOptions.Multiline);
                        File.WriteAllText(file, replaced);
                        return true;
                    }
                }

                // Not wrapped at all: wrap fresh
                if (!IsAlreadyWrapped(content, define))
                {
                    string wrapped = $"#if {define}\n{content.Trim()}\n#endif\n";
                    File.WriteAllText(file, wrapped);
                    return true;
                }
                return false;
            }
            catch (Exception e)
            {
                Debug.LogError($"[UPMWrapper] Failed to wrap file {file}: {e.Message}");
                return false;
            }
        }

        private static string ReadFirstSignificantLine(string content)
        {
            using (var reader = new StringReader(content))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    var t = line.Trim();
                    if (string.IsNullOrEmpty(t) || t.StartsWith("//")) continue;
                    return t;
                }
            }
            return string.Empty;
        }
        
        private static bool IsAlreadyWrapped(string content, string define)
        {
            using (var reader = new StringReader(content))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    line = line.Trim();
                    if (string.IsNullOrEmpty(line) || line.StartsWith("//"))
                        continue;

                    // Consider wrapped only if first significant line matches the exact define expression
                    return string.Equals(line, $"#if {define}", StringComparison.Ordinal);
                }
            }
            return false;
        }
        
        // Toggle for showing/hiding informational logs
        [MenuItem("MeshMap/Tools/UPM Wrapper/Show Wrapping Info Logs")]
        public static void ToggleShowInfoLogs()
        {
            bool current = EditorPrefs.GetBool(VerboseLogsEditorPrefsKey, true);
            bool next = !current;
            EditorPrefs.SetBool(VerboseLogsEditorPrefsKey, next);
            Menu.SetChecked("MeshMap/Tools/UPM Wrapper/Show Wrapping Info Logs", next);
            Debug.Log($"[UPMWrapper] Show Wrapping Info Logs: {(next ? "Enabled" : "Disabled")}" );
        }

        // Validation method keeps the checkmark in sync like the Meta > Tools > Use Required Project Settings menu
        [MenuItem("MeshMap/Tools/UPM Wrapper/Show Wrapping Info Logs", true)]
        public static bool ToggleShowInfoLogsValidate()
        {
            Menu.SetChecked("MeshMap/Tools/UPM Wrapper/Show Wrapping Info Logs", IsVerboseLoggingEnabled);
            return true;
        }

        // Note: Active target selection is governed by Build Profiles; no additional menu needed.
    }
}
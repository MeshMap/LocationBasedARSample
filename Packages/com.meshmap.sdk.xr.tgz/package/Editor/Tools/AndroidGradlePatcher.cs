// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using System.IO;
using System.Text;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Android;

namespace MeshMap.XR.Editor.Tools
{
    /// <summary>
    /// Injects Gradle packagingOptions to resolve duplicate native libs during Android builds.
    /// </summary>
    /// <remarks>
    /// For example, libc++_shared.so (common with various AARs)
    /// and libopenxr_loader.so (e.g., OVRPlugin and OpenXR loader).
    /// </remarks>
    public sealed class AndroidGradlePatcher : IPostGenerateGradleAndroidProject
    {
        public int callbackOrder => 999; // Run late to win over other generators

        public void OnPostGenerateGradleAndroidProject(string path)
        {
            // Patch both launcher and unityLibrary modules if present
            string launcher = Path.Combine(path, "launcher", "build.gradle");
            string unityLib = Path.Combine(path, "unityLibrary", "build.gradle");

            // If not building for XREAL, remove NRSDK AARs that drag in duplicate STL
            string defines;
            #if UNITY_2021_2_OR_NEWER
            defines = PlayerSettings.GetScriptingDefineSymbols(NamedBuildTarget.Android) ?? string.Empty;
            #else
            defines = PlayerSettings.GetScriptingDefineSymbolsForGroup(BuildTargetGroup.Android) ?? string.Empty;
            #endif
            if (!defines.Contains("XREAL"))
            {
                TryRemoveXrealAars(launcher);
                TryRemoveXrealAars(unityLib);
            }

            TryPatchBuildGradle(launcher);
            TryPatchBuildGradle(unityLib);

            // Also patch at settings.gradle level in case AGP merges libs differently
            TryPatchGradleProperties(Path.Combine(path, "gradle.properties"));
        }

        private static void TryPatchBuildGradle(string gradlePath)
        {
            if (!File.Exists(gradlePath))
                return;

            string content = File.ReadAllText(gradlePath);

            // Determine what's already present to avoid duplication
            bool hasLibcxx = content.Contains("libc++_shared.so");
            bool hasOpenXr = content.Contains("libopenxr_loader.so");
            if (hasLibcxx && hasOpenXr)
            {
                UnityEngine.Debug.Log($"[AndroidGradlePatcher] Skipping {gradlePath}, pickFirsts already present.");
                return;
            }

            // Preferred for AGP 8+: use 'packaging { jniLibs { pickFirsts/excludes ... } }'
            if (content.Contains("useLegacyPackaging"))
            {
                // Append missing pickFirsts right after useLegacyPackaging to keep the existing structure
                var sb = new StringBuilder();
                sb.Append("useLegacyPackaging true");
                if (!hasLibcxx)
                {
                    sb.Append("\n            pickFirsts += ['**/libc++_shared.so','lib/**/libc++_shared.so']\n            excludes += ['**/libc++_shared.so']");
                }
                if (!hasOpenXr)
                {
                    sb.Append("\n            pickFirsts += ['**/libopenxr_loader.so','lib/**/libopenxr_loader.so']");
                }
                var newContent = content.Replace("useLegacyPackaging true", sb.ToString());
                if (newContent != content)
                {
                    content = newContent;
                    UnityEngine.Debug.Log($"[AndroidGradlePatcher] Injected pickFirsts next to useLegacyPackaging in {gradlePath}.");
                }
            }
            else
            {
                // Fallback: inject a new packaging block inside android {}
                const string androidBlock = "android {";
                int idx = content.IndexOf(androidBlock);
                if (idx < 0)
                {
                    UnityEngine.Debug.LogWarning($"[AndroidGradlePatcher] Could not locate 'android {{' block in {gradlePath}. Skipping.");
                    return;
                }

                int insertPos = idx + androidBlock.Length;
                var inj = new StringBuilder();
                inj.Append("\n    // Added by MeshMap XR: resolve duplicate native libs from multiple AARs");
                inj.Append("\n    packaging {");
                inj.Append("\n        jniLibs {");
                if (!hasLibcxx)
                {
                    inj.Append("\n            pickFirsts += ['**/libc++_shared.so','lib/**/libc++_shared.so']");
                    inj.Append("\n            excludes += ['**/libc++_shared.so']");
                }
                if (!hasOpenXr)
                {
                    inj.Append("\n            pickFirsts += ['**/libopenxr_loader.so','lib/**/libopenxr_loader.so']");
                }
                inj.Append("\n        }");
                inj.Append("\n    }\n");

                content = content.Insert(insertPos, inj.ToString());
                UnityEngine.Debug.Log($"[AndroidGradlePatcher] Injected packaging/jniLibs block into {gradlePath}.");
            }
            File.WriteAllText(gradlePath, content);
            AssetDatabase.Refresh();
        }

        private static void TryPatchGradleProperties(string propertiesPath)
        {
            if (!File.Exists(propertiesPath)) return;
            string content = File.ReadAllText(propertiesPath);
            if (!content.Contains("android.suppressUnsupportedCompileSdk"))
            {
                content += "\nandroid.suppressUnsupportedCompileSdk=36\n";
                File.WriteAllText(propertiesPath, content);
                UnityEngine.Debug.Log("[AndroidGradlePatcher] Added android.suppressUnsupportedCompileSdk=36 to gradle.properties.");
            }
        }

        private static void TryRemoveXrealAars(string gradlePath)
        {
            if (!File.Exists(gradlePath)) return;
            string content = File.ReadAllText(gradlePath);
            string[] lines = content.Split('\n');
            bool changed = false;
            for (int i = 0; i < lines.Length; i++)
            {
                string l = lines[i];
                if (l.Contains("implementation(name: 'nr_common', ext:'aar')") ||
                    l.Contains("implementation(name: 'nr_loader', ext:'aar')") ||
                    l.Contains("implementation(name: 'nrunityandroidpermission-release', ext:'aar')") ||
                    l.Contains("implementation(name: 'Glasses-Display-Plug-Event-"))
                {
                    lines[i] = "// [MeshMap XR] Removed XREAL NRSDK AAR for non-XREAL build: " + l.Trim();
                    changed = true;
                }
            }
            if (changed)
            {
                File.WriteAllText(gradlePath, string.Join("\n", lines));
                UnityEngine.Debug.Log($"[AndroidGradlePatcher] Stripped XREAL NRSDK AARs from {gradlePath}.");
            }
        }
    }
}



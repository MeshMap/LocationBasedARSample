// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace MeshMap.XR.Editor.Tools
{
    /// <summary>
    /// Selects the correct AndroidManifest.xml template for the active target (METAQUEST, MAGICLEAP, XREAL)
    /// before Android builds, with no user interaction required.
    /// </summary>
    public sealed class MeshMapManifestSwitcher : IPreprocessBuildWithReport
    {
        public int callbackOrder => -100; // Ensure manifest is applied before other preprocessors

        private const string AndroidPluginsDir = "Assets/Plugins/Android";
        private const string OutputManifestPath = AndroidPluginsDir + "/AndroidManifest.xml";
        private const string PackageResourcesFolder = "Manifests"; // (Packages/mmsdk-xr-upm/Resources/Manifests)

        public void OnPreprocessBuild(BuildReport report)
        {
            if (report.summary.platform != BuildTarget.Android)
            {
                return;
            }

            // Use new API to avoid deprecation warnings
            string defines = PlayerSettings.GetScriptingDefineSymbols(NamedBuildTarget.Android) ?? string.Empty;
            string templateName = null;

            if (defines.Contains("MAGICLEAP"))
            {
                templateName = "AndroidManifest_MagicLeap.xml";
            }
            else if (defines.Contains("METAQUEST"))
            {
                templateName = "AndroidManifest_MetaQuest.xml";
            }
            else if (defines.Contains("XREAL"))
            {
                templateName = "AndroidManifest_XREAL.xml";
            }

            if (string.IsNullOrEmpty(templateName))
            {
                Debug.LogWarning("[MeshMapManifestSwitcher] No known platform define found. Using Meta Quest template as fallback.");
                templateName = "AndroidManifest_MetaQuest.xml";
            }

            string resourcePath = PackageResourcesFolder + "/" + Path.GetFileNameWithoutExtension(templateName);
            TextAsset packaged = Resources.Load<TextAsset>(resourcePath);
            Directory.CreateDirectory(AndroidPluginsDir);

            if (packaged != null)
            {
                File.WriteAllText(OutputManifestPath, packaged.text);
                AssetDatabase.ImportAsset(OutputManifestPath);
                Debug.Log($"[MeshMapManifestSwitcher] Applied manifest from package Resources: {templateName}");
                return;
            }
        }
    }
}



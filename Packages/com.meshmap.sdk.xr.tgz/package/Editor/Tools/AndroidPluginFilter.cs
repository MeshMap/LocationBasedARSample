// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;

namespace MeshMap.XR.Editor.Tools
{
    /// <summary>
    /// Disables platform-specific Android AARs when building for other targets to avoid native lib conflicts.
    /// </summary>
    public sealed class AndroidPluginFilter : IPreprocessBuildWithReport, IPostprocessBuildWithReport
    {
        public int callbackOrder => -200; // Run before manifest switcher

        // XREAL NRSDK AARs that pull in libc++_shared.so
        private static readonly string[] NrAarNames =
        {
            "nr_common.aar",
            "nr_loader.aar",
            "nrunityandroidpermission-release.aar",
            "Glasses-Display-Plug-Event-2.3.7.aar"
        };

        // Remember what we changed to restore after build
        private static readonly List<(string path, bool anyPlatform, bool androidCompat)> Changes = new();

        public void OnPreprocessBuild(BuildReport report)
        {
            if (report.summary.platform != BuildTarget.Android)
                return;

            string defines;
            #if UNITY_2021_2_OR_NEWER
            defines = PlayerSettings.GetScriptingDefineSymbols(NamedBuildTarget.Android) ?? string.Empty;
            #else
            defines = PlayerSettings.GetScriptingDefineSymbolsForGroup(BuildTargetGroup.Android) ?? string.Empty;
            #endif

            // Prefer disabling NR SDK when targeting other platforms even if XREAL define is present
            bool isMetaQuest = defines.Contains("METAQUEST");
            bool isMagicLeap = defines.Contains("MAGICLEAP");
            bool isXreal = defines.Contains("XREAL");
            UnityEngine.Debug.Log($"[AndroidPluginFilter] Defines: {defines}");

            // Disable when building for METAQUEST or MAGICLEAP. Only keep when explicitly XREAL-only.
            if (isMetaQuest || isMagicLeap || !isXreal)
            {
                UnityEngine.Debug.Log("[AndroidPluginFilter] Disabling XREAL NRSDK AARs for this build.");
                DisableAars(NrAarNames);
            }
        }

        public void OnPostprocessBuild(BuildReport report)
        {
            // Restore any changes
            foreach (var (path, anyPlatform, androidCompat) in Changes)
            {
                var importer = AssetImporter.GetAtPath(path) as PluginImporter;
                if (importer == null) continue;
                importer.SetCompatibleWithAnyPlatform(anyPlatform);
                importer.SetCompatibleWithPlatform(BuildTarget.Android, androidCompat);
                importer.SaveAndReimport();
            }
            Changes.Clear();
        }

        private static void DisableAars(IEnumerable<string> aarNames)
        {
            // Find all PluginImporter assets and filter by filename
            string[] pluginGuids = AssetDatabase.FindAssets("t:PluginImporter");
            foreach (string guid in pluginGuids)
            {
                string path = AssetDatabase.GUIDToAssetPath(guid);
                if (string.IsNullOrEmpty(path)) continue;
                string fileName = System.IO.Path.GetFileName(path);
                if (!aarNames.Contains(fileName)) continue;

                var importer = AssetImporter.GetAtPath(path) as PluginImporter;
                if (importer == null) continue;

                // Record original to restore later
                Changes.Add((path, importer.GetCompatibleWithAnyPlatform(), importer.GetCompatibleWithPlatform(BuildTarget.Android)));

                importer.SetCompatibleWithAnyPlatform(false);
                importer.SetCompatibleWithPlatform(BuildTarget.Android, false);
                importer.SaveAndReimport();
            }
        }
    }
}



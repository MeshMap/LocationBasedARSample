// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

namespace MeshMap.XR.Editor.MarkerTracking
{
    [CustomPropertyDrawer(typeof(MeshMap.XR.MarkerTracking.MarkerContent))]
    public class MarkerContentListDrawer : PropertyDrawer
    {
        private const string IdField = "Id";
        private const string ContentField = "Content";
        private const float Padding = 5f;
        private const float MarkerIdWidth = 150f;
        private const float ContentFieldWidth = 250f;

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            SerializedProperty idProp = property.FindPropertyRelative(IdField);
            SerializedProperty contentProp = property.FindPropertyRelative(ContentField);

            Rect markerIDRect = new Rect(position.x, position.y, MarkerIdWidth, position.height);
            Rect contentRect = new Rect(position.x + MarkerIdWidth + Padding, position.y, ContentFieldWidth, position.height);

            EditorGUI.PropertyField(markerIDRect, idProp, GUIContent.none);
            EditorGUI.PropertyField(contentRect, contentProp, GUIContent.none);
        }

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            return EditorGUIUtility.singleLineHeight;
        }
    }
}
#endif



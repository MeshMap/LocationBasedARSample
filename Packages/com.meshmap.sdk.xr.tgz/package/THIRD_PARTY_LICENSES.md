## jp.keijiro.apriltag
- Version: 1.0.2-meshmap.2
- License: BSD 2-Clause License
- Copyright (c) 2013-2016, The Regents of The University of Michigan
- License Text: /licenses/BSD-2-Clause.txt
- Note: Original [keijiro Unity repository](https://github.com/keijiro/jp.keijiro.apriltag) and original [AprilTag project repository](https://github.com/AprilRobotics/apriltag).

## Magic Leap SDK
- Version: 2.6.0-pre.R15-meshmap
- License: Magic Leap 2 Software License Agreement
- Copyright (c) 2017-2024, Magic Leap, Inc.
- License Text: /licenses/MagicLeap.txt
- Notices: https://www.magicleap.com/legal/open-source-software-notices-ml2
- Note: The license allows to publish, reproduce, and distribute the SDK in apps, samples, templates, etc., and to modify solely to the extent necessary to incorporate it into an app. However, standalone redistribution of the SDK or modified package is not allowed.

// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Filtering;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using UnityEngine.XR.Interaction.Toolkit.Interactors;

namespace MeshMap.XR.Interactables
{
    /// <summary>
    /// Prevents rapid re-hovering or re-selecting of an <see cref="XRBaseInteractable"/>.
    /// Implements both <see cref="IXRSelectFilter"/> and <see cref="IXRHoverFilter"/>.
    /// Attach this component to the same GameObject as the interactable and add it
    /// to the Hover Filters and/or Select Filters list in the inspector.
    /// </summary>
    [DisallowMultipleComponent]
    public class XRInteractableCooldownFilter : MonoBehaviour, IXRSelectFilter, IXRHoverFilter
    {
        [SerializeField, Min(0f), Tooltip("The cooldown time (seconds) between each select.")]
        private float _selectCooldownSeconds = 0.5f;
        
        [SerializeField, Min(0f), Tooltip("Cooldown time (seconds) required after hover exit before the same interactor can hover again.")]
        private float _hoverCooldownSeconds = 0.25f;

        /// <summary>
        /// Tracks the last time each interactor exited selection on this interactable.
        /// </summary>
        readonly Dictionary<IXRSelectInteractor, float> _lastSelectExitTime = new();
        
        /// <summary>
        /// Tracks the last time each interactor exited hover on this interactable.
        /// </summary>
        readonly Dictionary<IXRHoverInteractor, float> _lastHoverExitTime = new();
        
        /// <summary>
        /// Cached reference to the interactable this filter is attached to.
        /// </summary>
        private XRBaseInteractable _interactable;

        public bool canProcess => isActiveAndEnabled;

        private void Awake()
        {
            _interactable = GetComponent<XRBaseInteractable>();
        }

        private void OnEnable()
        {
            _interactable.selectExited.AddListener(OnSelectExited);
            _interactable.hoverExited.AddListener(OnHoverExited);
        }

        private void OnDisable()
        {
            _interactable.selectExited.RemoveListener(OnSelectExited);
            _interactable.hoverExited.RemoveListener(OnHoverExited);
        }
        
        /// <summary>
        /// Determines whether this interactable can currently be selected by the given interactor.
        /// Returns false if the cooldown after a previous select exit has not elapsed.
        /// </summary>
        public bool Process(IXRSelectInteractor interactor, IXRSelectInteractable interactable)
        {
            if (!ReferenceEquals(interactable, _interactable))
                return true;

            if (!_lastSelectExitTime.TryGetValue(interactor, out var t))
                return true;

            return Time.time - t >= _selectCooldownSeconds;
        }
        
        /// <summary>
        /// Determines whether this interactable can currently be hovered by the given interactor.
        /// Returns false if the cooldown after a previous hover exit has not elapsed.
        /// </summary>
        public bool Process(IXRHoverInteractor interactor, IXRHoverInteractable interactable)
        {
            // Only gate this interactable
            if (!ReferenceEquals(interactable, _interactable))
                return true;

            if (!_lastHoverExitTime.TryGetValue(interactor, out var lastExit))
                return true;

            return Time.time - lastExit >= _hoverCooldownSeconds;
        }

        /// <summary>
        /// Records the time of a select exit for the given interactor.
        /// </summary>
        public void OnSelectExited(SelectExitEventArgs args)
        {
            _lastSelectExitTime[args.interactorObject] = Time.time;
        }
        
        /// <summary>
        /// Records the time of a hover exit for the given interactor.
        /// </summary>
        public void OnHoverExited(HoverExitEventArgs args)
        {
            _lastHoverExitTime[args.interactorObject] = Time.time;
        }
    }
}
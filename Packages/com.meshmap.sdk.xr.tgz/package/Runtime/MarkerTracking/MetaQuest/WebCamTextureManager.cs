// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if (METAQUEST) && !(MAGICLEAP) && !(XREAL)
// Copyright (c) Meta Platforms, Inc. and affiliates.

using System.Collections;
using System.Linq;
using UnityEngine;
using UnityEngine.Assertions;
using PCD = MeshMap.XR.MarkerTracking.MetaQuest.PassthroughCameraDebugger;

namespace MeshMap.XR.MarkerTracking.MetaQuest
{
    public class WebCamTextureManager : MonoBehaviour
    {
        [SerializeField] public PassthroughCameraEye Eye = PassthroughCameraEye.Left;
        [SerializeField, Tooltip("The requested resolution of the camera may not be supported by the chosen camera. In such cases, the closest available values will be used.\n\n" +
                                 "When set to (0,0), the highest supported resolution will be used.")]
        public Vector2Int RequestedResolution;
        [SerializeField] public PassthroughCameraPermissions CameraPermissions;

        /// <summary>
        /// Returns <see cref="WebCamTexture"/> reference if required permissions were granted and this component is enabled. Else, returns null.
        /// </summary>
        public WebCamTexture WebCamTexture { get; private set; }

        private bool m_hasPermission;

        private void Awake()
        {
            PCD.DebugMessage(LogType.Log, $"{nameof(WebCamTextureManager)}.{nameof(Awake)}() was called");
            Assert.AreEqual(1, UnityEngine.Object.FindObjectsByType<WebCamTextureManager>(UnityEngine.FindObjectsInactive.Include, UnityEngine.FindObjectsSortMode.None).Length,
                $"PCA: Passthrough Camera: more than one {nameof(WebCamTextureManager)} component. Only one instance is allowed at a time. Current instance: {name}");
#if UNITY_ANDROID
            // Be robust if the reference is not set via inspector/creation order
            if (CameraPermissions == null)
            {
                CameraPermissions = GetComponent<PassthroughCameraPermissions>();
                if (CameraPermissions == null)
                {
                    PCD.DebugMessage(LogType.Warning, "PCA: No PassthroughCameraPermissions assigned; adding one automatically.");
                    CameraPermissions = gameObject.AddComponent<PassthroughCameraPermissions>();
                }
            }
            CameraPermissions.AskCameraPermissions();
#endif
        }

        private void OnEnable()
        {
            PCD.DebugMessage(LogType.Log, $"PCA: {nameof(OnEnable)}() was called");
            if (!PassthroughCameraUtils.IsSupported)
            {
                PCD.DebugMessage(LogType.Log, "PCA: Passthrough Camera functionality is not supported by the current device." +
                          $" Disabling {nameof(WebCamTextureManager)} object");
                enabled = false;
                return;
            }

            m_hasPermission = PassthroughCameraPermissions.HasCameraPermission == true;
            if (!m_hasPermission)
            {
                PCD.DebugMessage(LogType.Error,
                    $"PCA: Passthrough Camera requires permission(s) {string.Join(" and ", PassthroughCameraPermissions.CameraPermissions)}. Waiting for them to be granted...");
                return;
            }

            PCD.DebugMessage(LogType.Log, "PCA: All permissions have been granted");
            _ = StartCoroutine(InitializeWebCamTexture());
        }

        private void OnDisable()
        {
            PCD.DebugMessage(LogType.Log, $"PCA: {nameof(OnDisable)}() was called");
            StopCoroutine(InitializeWebCamTexture());
            if (WebCamTexture != null)
            {
                WebCamTexture.Stop();
                Destroy(WebCamTexture);
                WebCamTexture = null;
            }
        }

        private void Update()
        {
            if (!m_hasPermission)
            {
                if (PassthroughCameraPermissions.HasCameraPermission != true)
                    return;

                m_hasPermission = true;
                _ = StartCoroutine(InitializeWebCamTexture());
            }
        }

        private IEnumerator InitializeWebCamTexture()
        {
            PCD.DebugMessage(LogType.Log, "PCA: InitializeWebCamTexture() started");
            PCD.DebugMessage(LogType.Log, $"PCA: Current Eye setting: {Eye}");
            PCD.DebugMessage(LogType.Log, $"PCA: Requested Resolution: {RequestedResolution}");
            
            // Check if Passthrough is present in the scene and is enabled
            // Only check for OpenXR passthrough layers
            var compositionLayers = UnityEngine.Object.FindObjectsByType<Unity.XR.CompositionLayers.CompositionLayer>(UnityEngine.FindObjectsInactive.Include, UnityEngine.FindObjectsSortMode.None);
            PCD.DebugMessage(LogType.Log, $"PCA: Found {compositionLayers.Length} composition layers");
            
            bool hasPassthroughLayer = false;
            foreach (var layer in compositionLayers)
            {
                if (layer != null && layer.LayerData != null)
                {
                    var layerDataType = layer.LayerData.GetType();
                    PCD.DebugMessage(LogType.Log, $"PCA: Found CompositionLayer with LayerData type: {layerDataType.FullName}");
                    
                    // Check if it's a passthrough layer data type
                    if (layerDataType.Name.Contains("Passthrough") && layerDataType.Namespace.Contains("Meta"))
                    {
                        hasPassthroughLayer = true;
                        PCD.DebugMessage(LogType.Log, "PCA: Found OpenXR PassthroughLayer");
                        break;
                    }
                }
            }
            
            PCD.DebugMessage(LogType.Log, $"PCA: Has passthrough layer: {hasPassthroughLayer}");
            
            if (!hasPassthroughLayer || !PassthroughCameraUtils.IsPassthroughEnabled())
            {
                PCD.DebugMessage(LogType.Error, "PCA: Passthrough must be enabled to use the Passthrough Camera API.");
                PCD.DebugMessage(LogType.Error, $"PCA: IsPassthroughEnabled() returned: {PassthroughCameraUtils.IsPassthroughEnabled()}");
                yield break;
            }

            PCD.DebugMessage(LogType.Log, "PCA: Passthrough is enabled, proceeding with WebCamTexture initialization");

#if !UNITY_6000_OR_NEWER
            // There is a bug on Unity 2022 that causes a crash if you don't wait a frame before initializing the WebCamTexture.
            // Waiting for one frame is important and prevents the bug.
            PCD.DebugMessage(LogType.Log, "PCA: Waiting for end of frame before WebCamTexture initialization");
            yield return new WaitForEndOfFrame();
#endif

            int retryCount = 0;
            const int maxRetries = 10;
            
            while (retryCount < maxRetries)
            {
                retryCount++;
                PCD.DebugMessage(LogType.Log, $"PCA: Attempt {retryCount}/{maxRetries} to initialize WebCamTexture");
                
                var devices = WebCamTexture.devices;
                PCD.DebugMessage(LogType.Log, $"PCA: Found {devices.Length} WebCamTexture devices");
                for (int i = 0; i < devices.Length; i++)
                {
                    PCD.DebugMessage(LogType.Log, $"PCA: Device {i}: {devices[i].name}");
                }
                
                PCD.DebugMessage(LogType.Log, $"PCA: Calling EnsureInitialized()...");
                bool initialized = PassthroughCameraUtils.EnsureInitialized();
                PCD.DebugMessage(LogType.Log, $"PCA: EnsureInitialized() returned: {initialized}");
                
                if (initialized && PassthroughCameraUtils.CameraEyeToCameraIdMap.TryGetValue(Eye, out var cameraData))
                {
                    PCD.DebugMessage(LogType.Log, $"PCA: Camera data found for eye {Eye}: id={cameraData.id}, index={cameraData.index}");
                    
                    if (cameraData.index < devices.Length)
                    {
                        var deviceName = devices[cameraData.index].name;
                        PCD.DebugMessage(LogType.Log, $"PCA: Using device: {deviceName}");
                        
                        WebCamTexture webCamTexture;
                        if (RequestedResolution == Vector2Int.zero)
                        {
                            var outputSizes = PassthroughCameraUtils.GetOutputSizes(Eye);
                            PCD.DebugMessage(LogType.Log, $"PCA: Available output sizes: {string.Join(", ", outputSizes)}");
                            var largestResolution = outputSizes.OrderBy(static size => size.x * size.y).Last();
                            PCD.DebugMessage(LogType.Log, $"PCA: Using largest resolution: {largestResolution}");
                            webCamTexture = new WebCamTexture(deviceName, largestResolution.x, largestResolution.y);
                        }
                        else
                        {
                            PCD.DebugMessage(LogType.Log, $"PCA: Using requested resolution: {RequestedResolution}");
                            webCamTexture = new WebCamTexture(deviceName, RequestedResolution.x, RequestedResolution.y);
                        }
                        
                        PCD.DebugMessage(LogType.Log, $"PCA: WebCamTexture created, calling Play()");
                        webCamTexture.Play();
                        
                        // Wait a few frames for the texture to initialize
                        PCD.DebugMessage(LogType.Log, "PCA: Waiting for WebCamTexture to initialize...");
                        yield return new WaitForSeconds(0.1f);
                        
                        var currentResolution = new Vector2Int(webCamTexture.width, webCamTexture.height);
                        PCD.DebugMessage(LogType.Log, $"PCA: WebCamTexture initialized - width: {webCamTexture.width}, height: {webCamTexture.height}, isPlaying: {webCamTexture.isPlaying}");
                        PCD.DebugMessage(LogType.Log, $"PCA: WebCamTexture device name: {webCamTexture.deviceName}");
                        PCD.DebugMessage(LogType.Log, $"PCA: WebCamTexture is readable: {webCamTexture.isReadable}");
                        
                        if (RequestedResolution != Vector2Int.zero && RequestedResolution != currentResolution)
                        {
                            PCD.DebugMessage(LogType.Warning, $"PCA: WebCamTexture created, but '{nameof(RequestedResolution)}' {RequestedResolution} is not supported. Current resolution: {currentResolution}.");
                        }
                        
                        WebCamTexture = webCamTexture;
                        PCD.DebugMessage(LogType.Log, $"PCA: WebCamTexture created successfully, texturePtr: {WebCamTexture.GetNativeTexturePtr()}, size: {WebCamTexture.width}/{WebCamTexture.height}");
                        yield break;
                    }
                    else
                    {
                        PCD.DebugMessage(LogType.Error, $"PCA: Camera index {cameraData.index} is out of range. Available devices: {devices.Length}");
                    }
                }
                else
                {
                    PCD.DebugMessage(LogType.Error, $"PCA: Failed to get camera data for eye {Eye}");
                    PCD.DebugMessage(LogType.Error, $"PCA: EnsureInitialized() returned: {PassthroughCameraUtils.EnsureInitialized()}");
                    PCD.DebugMessage(LogType.Error, $"PCA: CameraEyeToCameraIdMap contains eye {Eye}: {PassthroughCameraUtils.CameraEyeToCameraIdMap.ContainsKey(Eye)}");
                    PCD.DebugMessage(LogType.Error, $"PCA: CameraEyeToCameraIdMap count: {PassthroughCameraUtils.CameraEyeToCameraIdMap.Count}");
                }

                PCD.DebugMessage(LogType.Error, $"PCA: Requested camera is not present in WebCamTexture.devices: {string.Join(", ", devices)}.");
                PCD.DebugMessage(LogType.Log, $"PCA: Waiting 1 second before retry...");
                yield return new WaitForSeconds(1.0f); // Wait longer before retrying
            }
            
            PCD.DebugMessage(LogType.Error, $"PCA: Failed to initialize WebCamTexture after {maxRetries} attempts");
        }
    }

    /// <summary>
    /// Defines the position of a passthrough camera relative to the headset
    /// </summary>
    public enum PassthroughCameraEye
    {
        Left,
        Right
    }
}
#endif

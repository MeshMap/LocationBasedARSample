// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if (METAQUEST) && !(MAGICLEAP) && !(XREAL)
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace MeshMap.XR.MarkerTracking.MetaQuest
{
    public sealed class MQMarkerService : MeshMap.XR.MarkerTracking.IPlatformMarkerService
    {
        private readonly List<DetectedMarker> _buffer = new();
        private readonly HashSet<int> _allowedIds = new();
        private float _tagSizeMeters = 0.15f;
        private global::AprilTag.TagDetector _detector;
        private global::MeshMap.XR.MarkerTracking.MetaQuest.WebCamTextureManager _webcam;
        private WebCamTexture _tex;
        private bool _ready;
	        private readonly System.Collections.Generic.Dictionary<int, Pose> _lastSmoothed = new();
	        private readonly System.Collections.Generic.Dictionary<int, float> _lastSeenTime = new();
	        private const float PositionAlpha = 0.2f;
	        private const float RotationAlphaDeg = 0.2f;
	        private const float ReacquireSnapSeconds = 0.25f;

        public void Initialize(GameObject owner, IEnumerable<string> markerIds, float markerSizeMeters)
        {
            _allowedIds.Clear();
            if (markerIds != null)
            {
                foreach (var id in markerIds)
                {
                    if (int.TryParse(id, out var num))
                        _allowedIds.Add(num);
                }
            }
            if (markerSizeMeters > 0) _tagSizeMeters = markerSizeMeters;

            _webcam = Object.FindAnyObjectByType<global::MeshMap.XR.MarkerTracking.MetaQuest.WebCamTextureManager>(FindObjectsInactive.Include);
            if (_webcam == null)
            {
                var deps = new GameObject("QuestPassthroughDeps");
                deps.transform.SetParent(owner.transform, false);
                var perms = deps.AddComponent<global::MeshMap.XR.MarkerTracking.MetaQuest.PassthroughCameraPermissions>();
                if (!perms.PermissionRequestsOnStartup.Contains("com.oculus.permission.USE_SCENE"))
                {
                    perms.PermissionRequestsOnStartup.Add("com.oculus.permission.USE_SCENE");
                }
                _webcam = deps.AddComponent<global::MeshMap.XR.MarkerTracking.MetaQuest.WebCamTextureManager>();
                _webcam.CameraPermissions = perms;
                _webcam.Eye = global::MeshMap.XR.MarkerTracking.MetaQuest.PassthroughCameraEye.Left;
                _webcam.RequestedResolution = Vector2Int.zero;
            }
            else
            {
                var perms = _webcam.CameraPermissions
                           ?? _webcam.GetComponent<global::MeshMap.XR.MarkerTracking.MetaQuest.PassthroughCameraPermissions>()
                           ?? _webcam.gameObject.AddComponent<global::MeshMap.XR.MarkerTracking.MetaQuest.PassthroughCameraPermissions>();
                if (!perms.PermissionRequestsOnStartup.Contains("com.oculus.permission.USE_SCENE"))
                {
                    perms.PermissionRequestsOnStartup.Add("com.oculus.permission.USE_SCENE");
                }
                _webcam.CameraPermissions = perms;
                _webcam.Eye = global::MeshMap.XR.MarkerTracking.MetaQuest.PassthroughCameraEye.Left;
                _webcam.RequestedResolution = Vector2Int.zero;
            }
        }

        public void Shutdown()
        {
            _detector?.Dispose();
            _detector = null;
            if (_webcam != null && _webcam.WebCamTexture != null)
            {
                _webcam.WebCamTexture.Stop();
            }
        }

	        public void UpdateService()
        {
            if (_webcam == null)
                return;

            if (_tex == null)
            {
                _tex = _webcam.WebCamTexture;
                if (_tex == null || !_tex.isPlaying)
                    return;
            }

            if (_detector == null && _tex.width > 0 && _tex.height > 0)
            {
                _detector = new global::AprilTag.TagDetector(_tex.width, _tex.height, 4, global::AprilTag.Interop.Family.TagType.Tag36h11);
                _lastSmoothed.Clear();
                _lastSeenTime.Clear();
                _ready = true;
            }

            if (!_ready || _detector == null || !_tex.isPlaying)
                return;

            var pixels = _tex.GetPixels32();
            if (pixels == null || pixels.Length == 0)
                return;

            float fov;
            if (global::MeshMap.XR.MarkerTracking.MetaQuest.PassthroughCameraUtils.IsSupported)
            {
                var intr = global::MeshMap.XR.MarkerTracking.MetaQuest.PassthroughCameraUtils.GetCameraIntrinsics(global::MeshMap.XR.MarkerTracking.MetaQuest.PassthroughCameraEye.Left);
                int imageHeight = _tex.height;
                fov = 2f * Mathf.Atan(imageHeight / (2f * intr.FocalLength.y));
            }
            else
            {
                fov = Mathf.Deg2Rad * 60f;
            }

	            _detector.ProcessImage(new System.ReadOnlySpan<Color32>(pixels), fov, _tagSizeMeters);

            _buffer.Clear();
            if (_detector.DetectedTags != null)
            {
	                Pose GetHeadPose()
	                {
	                    var devices = new System.Collections.Generic.List<UnityEngine.XR.InputDevice>();
	                    UnityEngine.XR.InputDevices.GetDevicesAtXRNode(UnityEngine.XR.XRNode.Head, devices);
	                    if (devices.Count > 0 && devices[0].isValid &&
	                        devices[0].TryGetFeatureValue(UnityEngine.XR.CommonUsages.devicePosition, out var headPos) &&
	                        devices[0].TryGetFeatureValue(UnityEngine.XR.CommonUsages.deviceRotation, out var headRot))
	                    {
	                        return new Pose(headPos, headRot);
	                    }
	                    return Camera.main != null
	                        ? new Pose(Camera.main.transform.position, Camera.main.transform.rotation)
	                        : new Pose(Vector3.zero, Quaternion.identity);
	                }

	                var head = GetHeadPose();
	                var camOffset = global::MeshMap.XR.MarkerTracking.MetaQuest.PassthroughCameraUtils.GetCameraPoseInWorld(global::MeshMap.XR.MarkerTracking.MetaQuest.PassthroughCameraEye.Left);
	                var cameraPosition = head.position + head.rotation * camOffset.position;
	                var cameraRotation = head.rotation * camOffset.rotation;

                foreach (var tag in _detector.DetectedTags)
                {
                    if (_allowedIds.Count > 0 && !_allowedIds.Contains(tag.ID))
                        continue;

	                    var worldPos = cameraPosition + cameraRotation * tag.Position;
	                    var worldRot = cameraRotation * tag.Rotation;

	                    if (_lastSmoothed.TryGetValue(tag.ID, out var prev))
	                    {
	                        var wasSeen = _lastSeenTime.TryGetValue(tag.ID, out var lastSeen);
	                        var reacquired = wasSeen && (Time.time - lastSeen) > ReacquireSnapSeconds;
	                        if (!reacquired)
	                        {
	                            worldPos = Vector3.Lerp(prev.position, worldPos, PositionAlpha);
	                            worldRot = Quaternion.RotateTowards(prev.rotation, worldRot, RotationAlphaDeg);
	                        }
	                        _lastSmoothed[tag.ID] = new Pose(worldPos, worldRot);
	                    }
	                    else
	                    {
	                        _lastSmoothed[tag.ID] = new Pose(worldPos, worldRot);
	                    }

	                    _lastSeenTime[tag.ID] = Time.time;

                    _buffer.Add(new DetectedMarker
                    {
                        Id = tag.ID.ToString(),
                        Pose = new Pose(worldPos, worldRot)
                    });
                }
            }
        }

        public IReadOnlyList<DetectedMarker> GetDetections() => _buffer;
    }
}
#endif

// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

namespace MeshMap.XR.MarkerTracking
{
    /// <summary>
    /// Toggles the visibility of localization visual hint GameObjects based on input action.
    /// </summary>
    public class ToggleMarkerVisuals : MonoBehaviour
    {
        [SerializeField, Tooltip("Optional input action to toggle visuals.")]
        protected InputActionProperty _actionProperty;
        
        [SerializeField, Tooltip("Optional button to toggle visuals.")]
        protected Button _button;

        [SerializeField] protected TextMeshProUGUI _buttonText;
        
        [SerializeField] protected GameObject[] _visualObjects;

        [SerializeField] protected bool _visible = true;

        protected void Start()
        {
            _actionProperty.action.performed += ToggleAction;

            if (_button != null)
                _button.onClick.AddListener(SetVisiblility);
            
            UpdateText();
        }

        protected void OnDestroy()
        {
            _actionProperty.action.performed -= ToggleAction;

            if (_button != null)
                _button.onClick.RemoveListener(SetVisiblility);
        }
        
        protected void ToggleAction(InputAction.CallbackContext context)
        {
            SetVisiblility();
        }
        
        public void SetVisiblility()
        {
            if (_visualObjects == null) return;
            foreach (var visual in _visualObjects)
            {
                if (visual != null)
                {
                    visual.SetActive(!_visible);
                }
            }
            _visible = !_visible;
            UpdateText();
        }

        private void UpdateText()
        {
            if (_buttonText != null)
                _buttonText.text = _visible ? "Hide Visuals" : "Show Visuals";
        }
    }
}
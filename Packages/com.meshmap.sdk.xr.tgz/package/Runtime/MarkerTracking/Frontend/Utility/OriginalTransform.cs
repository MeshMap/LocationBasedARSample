// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using UnityEngine;

namespace MeshMap.XR.MarkerTracking
{
    /// <summary>
    /// Represents the original position and rotation of a transform.
    /// Used to store and restore the initial state of objects during localization.
    /// </summary>
    public class OriginalTransform
    {
        public Vector3 Position;
        public Quaternion Rotation;

        public OriginalTransform(Vector3 position, Quaternion rotation)
        {
            Position = position;
            Rotation = rotation;
        }
    }
}



using System;
using UnityEngine;

namespace MeshMap.XR.MarkerTracking
{
    /// <summary>
    /// Pairs an AR marker's encoded ID (e.g., 0) with the GameObject that localizes to its position.
    /// </summary>
    [Serializable]
    public class MarkerContent
    {
        public string Id;
        public GameObject Content;
    }
}



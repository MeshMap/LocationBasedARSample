using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace MeshMap.XR.MarkerTracking
{
    public class MarkerTrackerUI : MonoBehaviour
    {
        [Header("Panels")]
        [SerializeField] private GameObject _localizationPanel;
        [SerializeField] private GameObject _localizationProgressPanel;

        [Header("Text")]
        [SerializeField] private TextMeshProUGUI _localizeText;

        [Header("Dropdown")]
        [SerializeField] private TMP_Dropdown _orientationDropdown;

        [Header("Toggles")]
        [SerializeField] private Toggle _xToggle;
        [SerializeField] private Toggle _yToggle;
        [SerializeField] private Toggle _zToggle;
        
        [Header("Buttons")]
        public Button StartButton;
        public Button CancelButton;

        public void OpenLocalizationProgressPanel()
        {
            _localizationProgressPanel.SetActive(true);
            _localizationPanel.SetActive(false);
        }

        public void CloseLocalizationProgressPanel()
        {
            _localizationPanel.SetActive(true);
            _localizationProgressPanel.SetActive(false);
        }

        public IEnumerator CloseLocalizationProgressPanelAfterDelay()
        {
            CancelButton.gameObject.SetActive(false);
            UpdateLocalizeText("Localization Complete.\nReturning to Main Menu in 3...");
            yield return new WaitForSeconds(1);
            UpdateLocalizeText("Localization Complete.\nReturning to Main Menu in 2...");
            yield return new WaitForSeconds(1);
            UpdateLocalizeText("Localization Complete.\nReturning to Main Menu in 1...");
            yield return new WaitForSeconds(1);
            CloseLocalizationProgressPanel();
            CancelButton.gameObject.SetActive(true);
        }

        public void UpdateLocalizeText(string text)
        {
            _localizeText.text = text;
        }

        public MarkerOrientation GetMarkerOrientation()
        {
            return (MarkerOrientation)_orientationDropdown.value;
        }

        public bool GetXToggle() => _xToggle.isOn;
        public bool GetYToggle() => _yToggle.isOn;
        public bool GetZToggle() => _zToggle.isOn;
    }
}


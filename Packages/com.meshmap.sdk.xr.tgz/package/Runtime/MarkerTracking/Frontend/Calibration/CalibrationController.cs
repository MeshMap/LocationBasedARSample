// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using UnityEngine;
using UnityEngine.UI;

namespace MeshMap.XR.MarkerTracking
{
    /// <summary>
    /// Provides UI controls for adjusting positional and rotational calibration values,
    /// and resetting to a predefined state. Also allows toggling visibility of position controls.
    /// </summary>
    public class CalibrationController : MonoBehaviour
    {
        [Header("Position Toggle")]
        [SerializeField] private Toggle _posToggle;
        [SerializeField] private RectTransform _posContainer;
        
        [Header("Position Buttons")]
        [SerializeField] private Button _xPosIncreaseButton;
        [SerializeField] private Button _xPosDecreaseButton;
        [SerializeField] private Button _yPosIncreaseButton;
        [SerializeField] private Button _yPosDecreaseButton;
        [SerializeField] private Button _zPosIncreaseButton;
        [SerializeField] private Button _zPosDecreaseButton;
        
        [Header("Rotation Buttons")]
        [SerializeField] private Button _xRotIncreaseButton;
        [SerializeField] private Button _xRotDecreaseButton;
        [SerializeField] private Button _yRotIncreaseButton;
        [SerializeField] private Button _yRotDecreaseButton;
        [SerializeField] private Button _zRotIncreaseButton;
        [SerializeField] private Button _zRotDecreaseButton;
        
        [Header("Reset Button")]
        [SerializeField] private Button _resetButton;

        [SerializeField] private CalibrationModel _calibrationModel;

        private void Start()
        {
            if (_calibrationModel == null)
                _calibrationModel = FindObjectOfType<CalibrationModel>(true);

            _xPosIncreaseButton.onClick.AddListener(_calibrationModel.IncreaseXPosDiff);
            _xPosDecreaseButton.onClick.AddListener(_calibrationModel.DecreaseXPosDiff);
            _yPosIncreaseButton.onClick.AddListener(_calibrationModel.IncreaseYPosDiff);
            _yPosDecreaseButton.onClick.AddListener(_calibrationModel.DecreaseYPosDiff);
            _zPosIncreaseButton.onClick.AddListener(_calibrationModel.IncreaseZPosDiff);
            _zPosDecreaseButton.onClick.AddListener(_calibrationModel.DecreaseZPosDiff);
            
            _xRotIncreaseButton.onClick.AddListener(_calibrationModel.IncreaseXRotDiff);
            _xRotDecreaseButton.onClick.AddListener(_calibrationModel.DecreaseXRotDiff);
            _yRotIncreaseButton.onClick.AddListener(_calibrationModel.IncreaseYRotDiff);
            _yRotDecreaseButton.onClick.AddListener(_calibrationModel.DecreaseYRotDiff);
            _zRotIncreaseButton.onClick.AddListener(_calibrationModel.IncreaseZRotDiff);
            _zRotDecreaseButton.onClick.AddListener(_calibrationModel.DecreaseZRotDiff);
            
            _resetButton.onClick.AddListener(_calibrationModel.ResetPrecalibratedState);

            _posToggle.onValueChanged.AddListener(TogglePosVisiblity);
        }

        private void OnDestroy()
        {
            _xPosIncreaseButton.onClick.RemoveListener(_calibrationModel.IncreaseXPosDiff);
            _xPosDecreaseButton.onClick.RemoveListener(_calibrationModel.DecreaseXPosDiff);
            _yPosIncreaseButton.onClick.RemoveListener(_calibrationModel.IncreaseYPosDiff);
            _yPosDecreaseButton.onClick.RemoveListener(_calibrationModel.DecreaseYPosDiff);
            _zPosIncreaseButton.onClick.RemoveListener(_calibrationModel.IncreaseZPosDiff);
            _zPosDecreaseButton.onClick.RemoveListener(_calibrationModel.DecreaseZPosDiff);
    
            _xRotIncreaseButton.onClick.RemoveListener(_calibrationModel.IncreaseXRotDiff);
            _xRotDecreaseButton.onClick.RemoveListener(_calibrationModel.DecreaseXRotDiff);
            _yRotIncreaseButton.onClick.RemoveListener(_calibrationModel.IncreaseYRotDiff);
            _yRotDecreaseButton.onClick.RemoveListener(_calibrationModel.DecreaseYRotDiff);
            _zRotIncreaseButton.onClick.RemoveListener(_calibrationModel.IncreaseZRotDiff);
            _zRotDecreaseButton.onClick.RemoveListener(_calibrationModel.DecreaseZRotDiff);
            
            _resetButton.onClick.RemoveListener(_calibrationModel.ResetPrecalibratedState);

            _posToggle.onValueChanged.RemoveListener(TogglePosVisiblity);
        }

        private void TogglePosVisiblity(bool visibility)
        {
            _posContainer.gameObject.SetActive(visibility);
        }
    }
}



// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using System;
using UnityEngine;

namespace MeshMap.XR.MarkerTracking
{
    /// <summary>
    /// Manages calibration adjustments for localized AR content.
    /// Provides methods to manipulate position and rotation offsets and broadcasts changes via events.
    /// </summary>
    public class CalibrationModel : MonoBehaviour
    {
        public static event Action<float> OnXPosDiffChanged;
        public static event Action<float> OnYPosDiffChanged;
        public static event Action<float> OnZPosDiffChanged;
        public static event Action<float> OnXRotDiffChanged;
        public static event Action<float> OnYRotDiffChanged;
        public static event Action<float> OnZRotDiffChanged;

        [SerializeField, Range(0.01f, 1f)] private float _increment = 0.05f;

        private float _xPosDiff;
        private float _yPosDiff;
        private float _zPosDiff;
        private float _xRotDiff;
        private float _yRotDiff;
        private float _zRotDiff;

        private GameObject _currentContent;
        private Vector3 _initialPos;
        private Quaternion _initialRot;

        private void Start()
        {
            MarkerTrackingControls.OnLocalizationCompleted += SetContent;
        }

        private void OnDestroy()
        {
            MarkerTrackingControls.OnLocalizationCompleted -= SetContent;
        }

        private void SetDiff(ref float diff, float value, Action<float> eventCallback)
        {
            if (Mathf.Approximately(diff, value)) return;
            diff = value;
            eventCallback?.Invoke(diff);
        }

        private float XPosDiff { get => _xPosDiff; set => SetDiff(ref _xPosDiff, value, OnXPosDiffChanged); }
        private float YPosDiff { get => _yPosDiff; set => SetDiff(ref _yPosDiff, value, OnYPosDiffChanged); }
        private float ZPosDiff { get => _zPosDiff; set => SetDiff(ref _zPosDiff, value, OnZPosDiffChanged); }
        private float XRotDiff { get => _xRotDiff; set => SetDiff(ref _xRotDiff, value, OnXRotDiffChanged); }
        private float YRotDiff { get => _yRotDiff; set => SetDiff(ref _yRotDiff, value, OnYRotDiffChanged); }
        private float ZRotDiff { get => _zRotDiff; set => SetDiff(ref _zRotDiff, value, OnZRotDiffChanged); }

        public void SetContent(GameObject go)
        {
            ResetCalibrationData();
            _currentContent = go;
            _initialPos = go.transform.position;
            _initialRot = go.transform.rotation;
        }

        public void ResetPrecalibratedState()
        {
            if (!_currentContent) return;
            _currentContent.transform.position = _initialPos;
            _currentContent.transform.rotation = _initialRot;
            ResetCalibrationData();
        }

        private void MoveContent(Vector3 direction)
        {
            _currentContent.transform.Translate(direction * _increment);
        }

        private void RotateContent(Vector3 axis)
        {
            _currentContent.transform.Rotate(axis * _increment);
        }

        public void IncreaseXPosDiff() { if (_currentContent) { MoveContent(Vector3.right); XPosDiff += _increment; } }
        public void DecreaseXPosDiff() { if (_currentContent) { MoveContent(Vector3.left); XPosDiff -= _increment; } }
        public void IncreaseYPosDiff() { if (_currentContent) { MoveContent(Vector3.up); YPosDiff += _increment; } }
        public void DecreaseYPosDiff() { if (_currentContent) { MoveContent(Vector3.down); YPosDiff -= _increment; } }
        public void IncreaseZPosDiff() { if (_currentContent) { MoveContent(Vector3.forward); ZPosDiff += _increment; } }
        public void DecreaseZPosDiff() { if (_currentContent) { MoveContent(Vector3.back); ZPosDiff -= _increment; } }
        public void IncreaseXRotDiff() { if (_currentContent) { RotateContent(Vector3.right); XRotDiff += _increment; } }
        public void DecreaseXRotDiff() { if (_currentContent) { RotateContent(Vector3.left); XRotDiff -= _increment; } }
        public void IncreaseYRotDiff() { if (_currentContent) { RotateContent(Vector3.up); YRotDiff += _increment; } }
        public void DecreaseYRotDiff() { if (_currentContent) { RotateContent(Vector3.down); YRotDiff -= _increment; } }
        public void IncreaseZRotDiff() { if (_currentContent) { RotateContent(Vector3.forward); ZRotDiff += _increment; } }
        public void DecreaseZRotDiff() { if (_currentContent) { RotateContent(Vector3.back); ZRotDiff -= _increment; } }

        public Vector3 GetPositionData() => new Vector3(XPosDiff, YPosDiff, ZPosDiff);
        public Quaternion GetRotationData() => Quaternion.Euler(XRotDiff, YRotDiff, ZRotDiff);

        private void ResetCalibrationData()
        {
            XPosDiff = 0; YPosDiff = 0; ZPosDiff = 0; XRotDiff = 0; YRotDiff = 0; ZRotDiff = 0;
        }
    }
}



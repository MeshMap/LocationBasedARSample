// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using UnityEngine;
using TMPro;

namespace MeshMap.XR.MarkerTracking
{
    /// <summary>
    /// Displays calibration diffs (position and rotation) using TextMeshPro fields.
    /// </summary>
    public class CalibrationView : MonoBehaviour
    {
        [Header("Text Outputs")]
        [SerializeField] private TMP_Text _xPosDiffText;
        [SerializeField] private TMP_Text _yPosDiffText;
        [SerializeField] private TMP_Text _zPosDiffText;
        [SerializeField] private TMP_Text _xRotDiffText;
        [SerializeField] private TMP_Text _yRotDiffText;
        [SerializeField] private TMP_Text _zRotDiffText;

        [Header("Formatting")]
        [SerializeField] private string _format = "F2";

        [SerializeField] private CalibrationModel _model;

        private void Awake()
        {
            if (_model == null)
                _model = FindObjectOfType<CalibrationModel>(true);
        }

        private void OnEnable()
        {
            CalibrationModel.OnXPosDiffChanged += OnXPosChanged;
            CalibrationModel.OnYPosDiffChanged += OnYPosChanged;
            CalibrationModel.OnZPosDiffChanged += OnZPosChanged;
            CalibrationModel.OnXRotDiffChanged += OnXRotChanged;
            CalibrationModel.OnYRotDiffChanged += OnYRotChanged;
            CalibrationModel.OnZRotDiffChanged += OnZRotChanged;

            // Initialize display with current model values if available
            if (_model != null)
            {
                var pos = _model.GetPositionData();
                var rot = _model.GetRotationData().eulerAngles;
                OnXPosChanged(pos.x);
                OnYPosChanged(pos.y);
                OnZPosChanged(pos.z);
                OnXRotChanged(rot.x);
                OnYRotChanged(rot.y);
                OnZRotChanged(rot.z);
            }
        }

        private void OnDisable()
        {
            CalibrationModel.OnXPosDiffChanged -= OnXPosChanged;
            CalibrationModel.OnYPosDiffChanged -= OnYPosChanged;
            CalibrationModel.OnZPosDiffChanged -= OnZPosChanged;
            CalibrationModel.OnXRotDiffChanged -= OnXRotChanged;
            CalibrationModel.OnYRotDiffChanged -= OnYRotChanged;
            CalibrationModel.OnZRotDiffChanged -= OnZRotChanged;
        }

        private void OnXPosChanged(float v) { if (_xPosDiffText) _xPosDiffText.text = v.ToString(_format); }
        private void OnYPosChanged(float v) { if (_yPosDiffText) _yPosDiffText.text = v.ToString(_format); }
        private void OnZPosChanged(float v) { if (_zPosDiffText) _zPosDiffText.text = v.ToString(_format); }
        private void OnXRotChanged(float v) { if (_xRotDiffText) _xRotDiffText.text = v.ToString(_format); }
        private void OnYRotChanged(float v) { if (_yRotDiffText) _yRotDiffText.text = v.ToString(_format); }
        private void OnZRotChanged(float v) { if (_zRotDiffText) _zRotDiffText.text = v.ToString(_format); }
    }
}



namespace MeshMap.XR.MarkerTracking
{
    /// <summary>
    /// Defines the orientation of a tracked marker relative to the environment. Flat or Upright.
    /// </summary>
    public enum MarkerOrientation
    {
        Flat,
        Upright
    }
}



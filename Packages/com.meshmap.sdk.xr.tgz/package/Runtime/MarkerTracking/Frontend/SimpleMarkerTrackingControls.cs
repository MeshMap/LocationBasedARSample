using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
#if MAGICLEAP && !METAQUEST && !XREAL
using MagicLeap.OpenXR.Features.MarkerUnderstanding;
#endif

namespace MeshMap.XR.MarkerTracking
{
    /// <summary>
    /// Simplified marker tracking controls without UI dependencies or content manipulation.
    /// Uses events to communicate with external UI systems.
    /// </summary>
    public class SimpleMarkerTrackingControls : MonoBehaviour
    {
        // Events for UI components to observe
        public static event Action<GameObject> OnLocalizationCompleted;
        public static event Action<string> OnLocalizationStarted; // marker type
        public static event Action OnLocalizationStopped;
        public static event Action<float, string> OnLocalizationProgress; // progress percentage, message
        
        [Header("Marker Configuration")]
        [Tooltip("Map of marker IDs to anchor objects. Leave ID (key) empty to use this anchor for any marker.")]
        public List<MarkerAnchor> MarkerAnchorList;
        private Dictionary<string, GameObject> _markerAnchorDict = new();
        private GameObject _fallbackAnchor; // used when an entry has an empty Id
        
        [Tooltip("Map of marker IDs to content objects. Leave ID (key) empty to use this content for any marker.")]
        public List<MarkerContent> MarkerContentList;
        private Dictionary<string, GameObject> _markerContentDict = new();
        private GameObject _fallbackContent; // used when an entry has an empty Id
        
        [Header("Content Settings")]
        [SerializeField] private bool _hideContentUntilLocalizedOnce = true;

        [Header("Marker Detector Settings")]
#if MAGICLEAP && !METAQUEST && !XREAL
        [SerializeField] private MarkerDetectorProfile _markerDetectorProfile = MarkerDetectorProfile.Accuracy;
        [SerializeField] private MarkerType _markerType = MarkerType.AprilTag;
        [SerializeField] private AprilTagType _aprilTagType = AprilTagType.Dictionary_36H11;
        [SerializeField] private ArucoType _arucoType = ArucoType.Dictionary_7x7_50;
#endif
        [SerializeField] private float _markerSize = 0.17f;
        [SerializeField] private bool _estimateSize = false;
        
        [Header("Additional Localization Settings")]
        [SerializeField] private string _markerEncodedSubstring = null;
        [SerializeField, Range(10, 200)] private int _localizationSteps = 200;
        
        // Internal state
        private IPlatformMarkerService _service;
        private int _currentLocalizationStep = 0;
        private bool _localizationInProgress = false;
        private string _currentMarkerID = null;
        private GameObject _currentAnchor;
        private GameObject _currentContent;
        
        // Parent/transform cache for cancel/restore semantics
        private Vector3 _previousAnchorPosition = Vector3.zero;
        private Quaternion _previousAnchorRotation = Quaternion.identity;
        private Vector3 _previousContentPosition = Vector3.zero;
        private Quaternion _previousContentRotation = Quaternion.identity;
        private bool _previousTransformsCached = false;
        private Transform _originalAnchorParent;
        private Transform _originalContentParent;
        
        // Public properties for external systems to read
        public bool IsTracking => _localizationInProgress;
        public float LocalizationProgress => _localizationSteps > 0 ? (_currentLocalizationStep / (float)_localizationSteps) : 0f;
        public string CurrentMarkerID => _currentMarkerID;

        protected virtual void Start()
        {
            PopulateDicts();
            
            if (_hideContentUntilLocalizedOnce)
            {
                HideContent();
            }

            _service = PlatformMarkerServiceFactory.Create(gameObject);
            var ids = _markerAnchorDict.Keys.ToList();
            _service.Initialize(gameObject, ids, _markerSize);
            
#if MAGICLEAP && !METAQUEST && !XREAL
            if (_service is MeshMap.XR.MarkerTracking.MagicLeap.MLMarkerService ml)
            {
                ml.Configure(_markerDetectorProfile, _markerType, _aprilTagType, _arucoType, _estimateSize, _markerEncodedSubstring);
            }
#endif
        }
        
        private void OnDestroy()
        {
            _service?.Shutdown();
        }

        private void Update()
        {
            if (_localizationInProgress)
            {
                FindMarker();
            }
        }

        private void PopulateDicts()
        {
            _markerAnchorDict.Clear();
            _fallbackAnchor = null;
            foreach (var pair in MarkerAnchorList)
            {
                if (pair == null) continue;
                if (string.IsNullOrWhiteSpace(pair.Id))
                {
                    if (_fallbackAnchor == null)
                        _fallbackAnchor = pair.Anchor;
                }
                else
                {
                    _markerAnchorDict[pair.Id] = pair.Anchor;
                }
            }
            
            _markerContentDict.Clear();
            _fallbackContent = null;
            foreach (var pair in MarkerContentList)
            {
                if (pair == null) continue;
                if (string.IsNullOrWhiteSpace(pair.Id))
                {
                    if (_fallbackContent == null)
                        _fallbackContent = pair.Content;
                }
                else
                {
                    _markerContentDict[pair.Id] = pair.Content;
                }
            }
        }

        private void HideContent()
        {
            var uniqueContent = _markerContentDict.Values.Distinct().ToList();
            if (_fallbackContent != null && !uniqueContent.Contains(_fallbackContent))
                uniqueContent.Add(_fallbackContent);
            foreach (var content in uniqueContent)
            {
                content.SetActive(false);
            }
        }

        public virtual void StartLocalization()
        {
            if (_localizationInProgress) return;

            string markerType = GetMarkerTypeName();
            Debug.Log($"Starting localization for {markerType} marker");
            
            // Fire event for UI systems
            OnLocalizationStarted?.Invoke(markerType);

            _currentLocalizationStep = 0;
            _currentMarkerID = null;
            _currentContent = null;
            _localizationInProgress = true;
        }

        private string GetMarkerTypeName()
        {
#if MAGICLEAP && !METAQUEST && !XREAL
            return _markerType.ToString();
#else
            return "AprilTag";
#endif
        }

        private void FindMarker()
        {
            _service.UpdateService();
            var detections = _service.GetDetections();
            
            for (int i = 0; i < detections.Count; i++)
            {
                var d = detections[i];
                
                // Continue tracking current marker
                if (_currentMarkerID != null && d.Id == _currentMarkerID)
                {
                    LocalizeContent(_currentAnchor.transform, _currentContent.transform, d.Pose);
                }
                // Found a new marker
                else
                {
                    GameObject correspondingAnchor;
                    if (!_markerAnchorDict.TryGetValue(d.Id, out correspondingAnchor))
                        correspondingAnchor = _fallbackAnchor;
                    if (correspondingAnchor == null)
                        continue; // cannot localize without an anchor

                    GameObject correspondingContent;
                    if (!_markerContentDict.TryGetValue(d.Id, out correspondingContent))
                        correspondingContent = _fallbackContent;
                    if (correspondingContent == null)
                        continue; // cannot localize without content

                    _currentMarkerID = d.Id;
                    _currentAnchor = correspondingAnchor;
                    _currentContent = correspondingContent;
                    _currentContent.SetActive(true);

                    if (!_previousTransformsCached)
                    {
                        _previousAnchorPosition = _currentAnchor.transform.position;
                        _previousAnchorRotation = _currentAnchor.transform.rotation;
                        _previousContentPosition = _currentContent.transform.position;
                        _previousContentRotation = _currentContent.transform.rotation;
                        _originalAnchorParent = _currentAnchor.transform.parent;
                        _originalContentParent = _currentContent.transform.parent;
                        _previousTransformsCached = true;
                    }

                    // Reparent so content follows anchor during localization
                    _currentAnchor.transform.SetParent(_originalContentParent, true);
                    _currentContent.transform.SetParent(_currentAnchor.transform, true);

                    LocalizeContent(_currentAnchor.transform, _currentContent.transform, d.Pose);
                }
            }
        }

        private void LocalizeContent(Transform anchor, Transform content, Pose markerPose)
        {
            _currentLocalizationStep++;

            // Drive anchor by latest detection pose (no orientation adjustments)
            anchor.position = markerPose.position;
            anchor.rotation = markerPose.rotation;

            float progressPercent = (_currentLocalizationStep / (float)_localizationSteps) * 100f;
            string progressMessage = $"Localization: {Mathf.RoundToInt(progressPercent)}% Complete.";

            // Fire progress event for UI systems
            OnLocalizationProgress?.Invoke(progressPercent, progressMessage);

            // Check if localization is complete
            if (_currentLocalizationStep >= _localizationSteps)
            {
                CompleteLocalization();
            }
        }

        private void CompleteLocalization()
        {
            Debug.Log($"Localization completed for marker: {_currentMarkerID}");
            
            // Reset state
            _currentLocalizationStep = 0;
            _localizationInProgress = false;

            // Store content reference before clearing
            GameObject completedContent = _currentContent;

            // Detach back to original parents but keep the new world transform
            if (_currentContent != null && _originalContentParent != null)
            {
                _currentContent.transform.SetParent(_originalContentParent, true);
            }
            if (_currentAnchor != null && _originalAnchorParent != null)
            {
                _currentAnchor.transform.SetParent(_originalAnchorParent, true);
            }

            // Clear caches for next run
            _currentAnchor = null;
            _currentContent = null;
            _previousTransformsCached = false;
            
            // Fire completion event AFTER all transform operations are complete
            // This ensures the content root is properly positioned when external systems respond
            OnLocalizationCompleted?.Invoke(completedContent);
        }

        public void StopLocalization()
        {
            if (!_localizationInProgress) return;
            
            Debug.Log("Stopping localization");
            
            // Reset state
            _currentLocalizationStep = 0;
            _localizationInProgress = false;
            _currentMarkerID = null;

            // Restore transforms if we modified hierarchy
            StartCoroutine(RestoreToPrevious());

            // Fire event for UI systems
            OnLocalizationStopped?.Invoke();
        }

        private IEnumerator RestoreToPrevious()
        {
            yield return new WaitForEndOfFrame();
            if (_currentContent && _previousTransformsCached)
            {
                _currentContent.transform.SetParent(_originalContentParent, true);
                if (_currentAnchor != null)
                    _currentAnchor.transform.SetParent(_originalAnchorParent, true);

                _currentContent.transform.position = _previousContentPosition;
                _currentContent.transform.rotation = _previousContentRotation;

                if (_currentAnchor != null)
                {
                    _currentAnchor.transform.position = _previousAnchorPosition;
                    _currentAnchor.transform.rotation = _previousAnchorRotation;
                }
            }

            _currentAnchor = null;
            _currentContent = null;
            _previousAnchorPosition = Vector3.zero;
            _previousAnchorRotation = Quaternion.identity;
            _previousContentPosition = Vector3.zero;
            _previousContentRotation = Quaternion.identity;
            _previousTransformsCached = false;
        }
    }
}



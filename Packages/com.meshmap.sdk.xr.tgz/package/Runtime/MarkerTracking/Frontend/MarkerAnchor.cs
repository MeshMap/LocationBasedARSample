using System;
using UnityEngine;

namespace MeshMap.XR.MarkerTracking
{
    /// <summary>
    /// Pairs an AR marker's encoded ID (e.g., 0) with the GameObject that represents its pose and visual.
    /// </summary>
    [Serializable]
    public class MarkerAnchor
    {
        public string Id;
        public GameObject Anchor;
    }
}



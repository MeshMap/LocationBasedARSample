using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
#if MAGICLEAP && !METAQUEST && !XREAL
using MagicLeap.OpenXR.Features.MarkerUnderstanding;
#endif

namespace MeshMap.XR.MarkerTracking
{
    public class MarkerTrackingControls : MonoBehaviour
    {
        public static event Action<GameObject> OnLocalizationCompleted;
        
        public List<MarkerAnchor> MarkerAnchorList;
        private Dictionary<string, GameObject> _markerAnchorDict = new();
        
        public List<MarkerContent> MarkerContentList;
        private Dictionary<string, GameObject> _markerContentDict = new();
        
        [Header("Content Settings")]
        [SerializeField] private bool _hideContentUntilLocalizedOnce = true;

        [Header("Marker Detector Settings")]
#if MAGICLEAP && !METAQUEST && !XREAL
        [SerializeField] private MarkerDetectorProfile _markerDetectorProfile = MarkerDetectorProfile.Accuracy;
        [SerializeField] private MarkerType _markerType = MarkerType.AprilTag;
        [SerializeField] private AprilTagType _aprilTagType = AprilTagType.Dictionary_36H11;
        [SerializeField] private ArucoType _arucoType = ArucoType.Dictionary_7x7_50;
#endif
        [SerializeField] private float _markerSize = 0.17f;
        [SerializeField] private bool _estimateSize = false;
        private IPlatformMarkerService _service;
        
        [Header("Additional Localization Settings")]
        [SerializeField] private string _markerEncodedSubstring = null;
        
        [SerializeField, Range(10, 200)] private int _localizationSteps = 200;
        private int _currentLocalizationStep = 0;
        private bool _localizationInProgress = false;
        protected string _currentMarkerID = null;
        private GameObject _currentAnchor;
        private GameObject _currentContent;
        private Vector3 _previousAnchorPosition = Vector3.zero;
        private Quaternion _previousAnchorRotation = Quaternion.identity;
        private Vector3 _previousContentPosition = Vector3.zero;
        private Quaternion _previousContentRotation = Quaternion.identity;
        private bool _previousTransformsCached = false;
        private Transform _originalAnchorParent;
        private Transform _originalContentParent;

        private MarkerOrientation _orientation = MarkerOrientation.Flat;

        [SerializeField] private MarkerTrackerUI _markerTrackerUI;

        protected virtual void Start()
        {
            if (_markerTrackerUI == null)
            {
                _markerTrackerUI = FindObjectOfType<MarkerTrackerUI>(true);
            }
            _markerTrackerUI.StartButton.onClick.AddListener(StartLocalization);
            _markerTrackerUI.CancelButton.onClick.AddListener(StopLocalization);
            
            PopulateDicts();
            
            if (_hideContentUntilLocalizedOnce)
            {
                HideContent();
            }

            _service = PlatformMarkerServiceFactory.Create(gameObject);
            var ids = _markerAnchorDict.Keys.ToList();
            _service.Initialize(gameObject, ids, _markerSize);
#if MAGICLEAP && !METAQUEST && !XREAL
            if (_service is MeshMap.XR.MarkerTracking.MagicLeap.MLMarkerService ml)
            {
                ml.Configure(_markerDetectorProfile, _markerType, _aprilTagType, _arucoType, _estimateSize, _markerEncodedSubstring);
            }
#endif
        }
        
        private void OnDestroy()
        {
            _markerTrackerUI.StartButton.onClick.RemoveListener(StartLocalization);
            _markerTrackerUI.CancelButton.onClick.RemoveListener(StopLocalization);
            _service?.Shutdown();
        }

        private void Update()
        {
            if (_localizationInProgress)
            {
                FindMarker();
            }
        }

        private void PopulateDicts()
        {
            _markerAnchorDict.Clear();
            foreach (var pair in MarkerAnchorList)
            {
                _markerAnchorDict[pair.Id] = pair.Anchor;
            }
            
            _markerContentDict.Clear();
            foreach (var pair in MarkerContentList)
            {
                _markerContentDict[pair.Id] = pair.Content;
            }
        }

        private void HideContent()
        {
            var uniqueContent = _markerContentDict.Values.Distinct().ToList();
            foreach (var content in uniqueContent)
            {
                content.SetActive(false);
            }
        }

        public virtual void StartLocalization()
        {
            if (_localizationInProgress) return;

            _orientation = _markerTrackerUI.GetMarkerOrientation();
            _markerTrackerUI.UpdateLocalizeText($"Please look at the {GetMarkerTypeName()} marker.");
            _markerTrackerUI.OpenLocalizationProgressPanel();

            _currentLocalizationStep = 0;
            _currentMarkerID = null;
            _currentAnchor = null;
            _currentContent = null;
            _previousAnchorPosition = Vector3.zero;
            _previousAnchorRotation = Quaternion.identity;
            _previousContentPosition = Vector3.zero;
            _previousContentRotation = Quaternion.identity;
            _previousTransformsCached = false;
            _localizationInProgress = true;
        }

        private string GetMarkerTypeName()
        {
#if MAGICLEAP && !METAQUEST && !XREAL
            return _markerType.ToString();
#else
            return "AprilTag";
#endif
        }

        private void FindMarker()
        {
            _service.UpdateService();
            var detections = _service.GetDetections();
            for (int i = 0; i < detections.Count; i++)
            {
                var d = detections[i];
                if (_currentMarkerID != null && d.Id == _currentMarkerID)
                {
                    LocalizeContent(_currentAnchor.transform, _currentContent.transform, d.Pose);
                }
                else if (_markerAnchorDict.TryGetValue(d.Id, out var correspondingAnchor))
                {
                    _currentMarkerID = d.Id;
                    _currentAnchor = correspondingAnchor;
                    _currentContent = _markerContentDict[d.Id];
                    _currentContent.SetActive(true);

                    if (!_previousTransformsCached)
                    {
                        _previousAnchorPosition = _currentAnchor.transform.position;
                        _previousAnchorRotation = _currentAnchor.transform.rotation;
                        _previousContentPosition = _currentContent.transform.position;
                        _previousContentRotation = _currentContent.transform.rotation;
                        _previousTransformsCached = true;
                    }

                    LocalizeContent(_currentAnchor.transform, _currentContent.transform, d.Pose);
                }
            }
        }

        protected virtual void LocalizeContent(Transform anchor, Transform content, Pose markerPose)
        {
            _currentLocalizationStep++;
            _markerTrackerUI.UpdateLocalizeText($"Localization: {Mathf.RoundToInt((_currentLocalizationStep / ((float)_localizationSteps)) * 100)}% Complete.");
            
            if (_currentLocalizationStep == 1)
            {
                _originalAnchorParent = anchor.parent;
                _originalContentParent = content.parent;

                anchor.SetParent(content.parent, true);
                content.SetParent(anchor, true);
            }
            
            anchor.position = markerPose.position;
            anchor.rotation = markerPose.rotation;
            
            if (_orientation == MarkerOrientation.Flat)
            {
                anchor.rotation *= Quaternion.AngleAxis(-90, Vector3.right);
            }
            
            if (_currentLocalizationStep >= _localizationSteps)
            {
                anchor.eulerAngles = NullXYZRotation(anchor.eulerAngles);
                
                content.SetParent(_originalContentParent, true);
                anchor.SetParent(_originalAnchorParent, true);

                ResetLocalizationStatus();
                OnLocalizationCompleted?.Invoke(_currentContent);
                _currentAnchor = null;
                _currentContent = null;
                StartCoroutine(_markerTrackerUI.CloseLocalizationProgressPanelAfterDelay());
            }
        }

        private Vector3 NullXYZRotation(Vector3 rotation)
        {
            float x = rotation.x;
            float y = rotation.y;
            float z = rotation.z;
            return new Vector3(
                _markerTrackerUI.GetXToggle() ? 0 : x,
                _markerTrackerUI.GetYToggle() ? 0 : y,
                _markerTrackerUI.GetZToggle() ? 0 : z
            );
        }

        public void StopLocalization()
        {
            if (!_localizationInProgress) return;
            ResetLocalizationStatus();
            StartCoroutine(RestoreToPrevious());
            _markerTrackerUI.CloseLocalizationProgressPanel();
        }

        private void ResetLocalizationStatus()
        {
            _currentLocalizationStep = 0;
            _localizationInProgress = false;
            _currentMarkerID = null;
        }

        protected virtual IEnumerator RestoreToPrevious()
        {
            yield return new WaitForEndOfFrame();
            if (_currentContent && _previousTransformsCached)
            {
                _currentContent.transform.SetParent(_originalContentParent, true);
                _currentAnchor.transform.SetParent(_originalAnchorParent, true);
                
                _currentContent.transform.position = _previousContentPosition;
                _currentContent.transform.rotation = _previousContentRotation;

                _currentAnchor.transform.position = _previousAnchorPosition;
                _currentAnchor.transform.rotation = _previousAnchorRotation;
            }
            
            _currentAnchor = null;
            _currentContent = null;
            _previousAnchorPosition = Vector3.zero;
            _previousAnchorRotation = Quaternion.identity;
            _previousContentPosition = Vector3.zero;
            _previousContentRotation = Quaternion.identity;
            _previousTransformsCached = false;
        }
    }
}


// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using System.Collections.Generic;
using UnityEngine;

namespace MeshMap.XR.MarkerTracking
{
    /// <summary>
    /// Platform-agnostic marker detection service used by the front-end.
    /// Implementations must provide marker poses for a known set of marker IDs.
    /// </summary>
    public interface IPlatformMarkerService
    {
        void Initialize(GameObject owner, IEnumerable<string> markerIds, float markerSizeMeters);
        void Shutdown();
        void UpdateService();
        IReadOnlyList<DetectedMarker> GetDetections();
    }

    public struct DetectedMarker
    {
        public string Id;
        public Pose Pose;
    }
}



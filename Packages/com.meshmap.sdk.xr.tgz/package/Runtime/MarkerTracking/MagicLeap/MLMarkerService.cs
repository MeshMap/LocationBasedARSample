// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if (MAGICLEAP) && !(METAQUEST) && !(XREAL)
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.OpenXR;
using MagicLeap.OpenXR.Features.MarkerUnderstanding;

namespace MeshMap.XR.MarkerTracking.MagicLeap
{
    public sealed class MLMarkerService : IPlatformMarkerService
    {
        private readonly List<DetectedMarker> _buffer = new();
        private readonly HashSet<string> _allowedIds = new();
        private float _markerSizeMeters;
        private string _markerEncodedSubstring;
        private MagicLeapMarkerUnderstandingFeature _feature;
        private MarkerDetector _detector;
        private MarkerDetectorSettings _settings;

        public void Initialize(GameObject owner, IEnumerable<string> markerIds, float markerSizeMeters)
        {
            _allowedIds.Clear();
            if (markerIds != null)
            {
                foreach (var id in markerIds)
                    _allowedIds.Add(id);
            }
            _markerSizeMeters = markerSizeMeters;

            _feature = OpenXRSettings.Instance.GetFeature<MagicLeapMarkerUnderstandingFeature>();
            if (_settings.MarkerType == 0)
            {
                _settings = new MarkerDetectorSettings
                {
                    MarkerDetectorProfile = MarkerDetectorProfile.Accuracy,
                    MarkerType = MarkerType.AprilTag
                };
                _settings.AprilTagSettings.AprilTagType = AprilTagType.Dictionary_36H11;
                _settings.AprilTagSettings.AprilTagLength = _markerSizeMeters;
            }
            else
            {
                switch (_settings.MarkerType)
                {
                    case MarkerType.AprilTag:
                        _settings.AprilTagSettings.AprilTagLength = _markerSizeMeters;
                        break;
                    case MarkerType.Aruco:
                        _settings.ArucoSettings.ArucoLength = _markerSizeMeters;
                        break;
                    case MarkerType.QR:
                        _settings.QRSettings.QRLength = _markerSizeMeters;
                        break;
                }
            }

            _feature.CreateMarkerDetector(_settings);
            _detector = _feature.MarkerDetectors.Count > 0 ? _feature.MarkerDetectors[0] : null;
        }

        public void Shutdown()
        {
            if (_feature != null)
            {
                _feature.DestroyAllMarkerDetectors();
            }
        }

        public void UpdateService()
        {
            if (_feature == null || _detector == null)
                return;

            _feature.UpdateMarkerDetectors();
            _buffer.Clear();

            if (_detector.Status != MarkerDetectorStatus.Ready)
                return;

            for (int i = 0; i < _detector.Data.Count; i++)
            {
                var md = _detector.Data[i];
                if (!md.MarkerPose.HasValue)
                    continue;

                string id;
                switch (_settings.MarkerType)
                {
                    case MarkerType.AprilTag:
                    case MarkerType.Aruco:
                        id = md.MarkerNumber.ToString();
                        break;
                    case MarkerType.QR:
                        id = string.IsNullOrEmpty(_markerEncodedSubstring)
                            ? md.MarkerString
                            : md.MarkerString.Substring(md.MarkerString.IndexOf(_markerEncodedSubstring) + _markerEncodedSubstring.Length);
                        break;
                    default:
                        id = md.MarkerNumber.ToString();
                        break;
                }
                if (_allowedIds.Count > 0 && !_allowedIds.Contains(id))
                    continue;

                _buffer.Add(new DetectedMarker
                {
                    Id = id,
                    Pose = md.MarkerPose.Value
                });
            }
        }

        public IReadOnlyList<DetectedMarker> GetDetections() => _buffer;

        public void Configure(MarkerDetectorProfile profile,
                              MarkerType type,
                              AprilTagType aprilTagType,
                              ArucoType arucoType,
                              bool estimateSize,
                              string markerEncodedSubstring)
        {
            _settings.MarkerDetectorProfile = profile;
            _settings.MarkerType = type;
            _markerEncodedSubstring = markerEncodedSubstring;
            switch (type)
            {
                case MarkerType.AprilTag:
                    _settings.AprilTagSettings.AprilTagType = aprilTagType;
                    _settings.AprilTagSettings.EstimateAprilTagLength = estimateSize;
                    break;
                case MarkerType.Aruco:
                    _settings.ArucoSettings.ArucoType = arucoType;
                    _settings.ArucoSettings.EstimateArucoLength = estimateSize;
                    break;
                case MarkerType.QR:
                    _settings.QRSettings.EstimateQRLength = estimateSize;
                    break;
            }
        }
    }
}
#endif

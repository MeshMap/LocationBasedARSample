// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using UnityEngine.Events;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

namespace MeshMap.XR.UI
{
    /// <summary>
    /// A 3D "button" that reacts to hover/select from any XRI interactor.
    /// </summary>
    public class SpatialButton : XRSimpleInteractable
    {
        // Public events which can be accessed by external classes
        public UnityEvent OnHovered;
        public UnityEvent OnHoverEnded;
        public UnityEvent OnSelected;
        public UnityEvent OnSelectEnded;
        
        protected override void OnHoverEntered(HoverEnterEventArgs args)
        {
            base.OnHoverEntered(args);
            OnHovered?.Invoke();
        }

        protected override void OnHoverExited(HoverExitEventArgs args)
        {
            base.OnHoverExited(args);
            OnHoverEnded?.Invoke();
        }

        protected override void OnSelectEntered(SelectEnterEventArgs args)
        {
            base.OnSelectEntered(args);
            OnSelected?.Invoke();
        }

        protected override void OnSelectExited(SelectExitEventArgs args)
        {
            base.OnSelectExited(args);
            OnSelectEnded?.Invoke();
        }
    }
}
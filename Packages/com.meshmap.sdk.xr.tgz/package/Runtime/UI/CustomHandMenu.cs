// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.XR.Interaction.Toolkit.Interactors;
using Unity.XR.CoreUtils;

namespace MeshMap.XR.UI
{
    /// <summary>
    /// A simplified hand menu that follows hand tracking and activates based on palm orientation and camera gaze.
    /// Inspired by Unity's XR Interaction Toolkit HandMenu but streamlined for specific use cases.
    /// </summary>
    [AddComponentMenu("XR/Hand Menu (MeshMap)")]
    public class CustomHandMenu : MonoBehaviour
    {
        // Static event for menu state changes
        public static System.Action OnMenuDeactivated;
        
        [Header("Hand Tracking")]
        [SerializeField, Tooltip("Transform representing the left hand position and orientation")]
        private Transform leftHandTransform;
        
        [SerializeField, Tooltip("Transform representing the right hand position and orientation")]
        private Transform rightHandTransform;
        
        [SerializeField, Tooltip("Main camera transform for position and rotation reference")]
        private Transform cameraTransform;
        
        [SerializeField, Tooltip("The menu GameObject to activate/deactivate and position")]
        private GameObject menuGameObject;
        
        [SerializeField, Tooltip("Optional offset transform to apply final positioning adjustments. If only one is provided, the opposite hand offset will be automatically mirrored.")]
        private Transform leftHandOffsetTransform;
        
        [SerializeField, Tooltip("Optional offset transform for right hand. If not provided, will be automatically mirrored from left hand offset.")]
        private Transform rightHandOffsetTransform;

        [SerializeField, Tooltip("Optional Y offset for XREAL from the XR Origin")]
        private XROrigin _xrOrigin;

        [Header("Interaction Prevention")]
        [SerializeField, Tooltip("Left hand interactor group (parent containing all left hand interactors). If not set, will search for interactors automatically.")]
        private Transform leftHandInteractorGroup;
        
        [SerializeField, Tooltip("Right hand interactor group (parent containing all right hand interactors). If not set, will search for interactors automatically.")]
        private Transform rightHandInteractorGroup;
        
        [SerializeField, Tooltip("Hide menu when hand is grabbing objects")]
        private bool hideMenuWhileGrabbing = true;

        [Header("Detection Thresholds")]
        [SerializeField, Tooltip("Dot product threshold for palm facing camera (0.75 = ~41 degrees)")]
        [Range(0f, 1f)]
        private float palmFacingThreshold = 0.75f;
        
        [SerializeField, Tooltip("Dot product threshold for camera looking at hand (0.9 = ~25 degrees)")]
        [Range(0f, 1f)]
        private float cameraLookingThreshold = 0.9f;

        [Header("Animation Settings")]
        [SerializeField, Tooltip("Speed of position and rotation lerping")]
        private float lerpSpeed = 5f;
        
        [SerializeField, Tooltip("Duration of scale animation in seconds")]
        private float scaleAnimationDuration = 0.2f;
        
        [SerializeField, Tooltip("Target scale when menu is fully activated")]
        private Vector3 targetScale = Vector3.one;

        [Header("Performance Optimization")]
        [SerializeField, Tooltip("Minimum distance to move before updating position (reduces micro-movements)")]
        private float positionUpdateThreshold = 0.001f;
        
        [SerializeField, Tooltip("Minimum angle difference to rotate before updating rotation (in degrees)")]
        private float rotationUpdateThreshold = 1f;
        
        [SerializeField, Tooltip("Update frequency divisor (1 = every frame, 2 = every other frame, etc.)")]
        [Range(1, 5)]
        private int updateFrequencyDivisor = 1;

        [Header("Debug")]
        [SerializeField, Tooltip("Enable debug logging for troubleshooting")]
        private bool enableDebugLogging = false;

        // Internal state tracking
        private enum ActiveHand { None, Left, Right }
        private ActiveHand currentActiveHand = ActiveHand.None;
        private bool isMenuActive = false;
        private Vector3 initialScale;
        private Coroutine scaleCoroutine;

        // Cached interactors for performance
        private List<XRBaseInteractor> leftHandInteractors = new List<XRBaseInteractor>();
        private List<XRBaseInteractor> rightHandInteractors = new List<XRBaseInteractor>();
        private bool interactorsCached = false;

        // Performance optimization caching
        private int frameCounter = 0;
        private bool leftHandGrabbingCache = false;
        private bool rightHandGrabbingCache = false;
        private int lastGrabCheckFrame = -1;
        private Vector3 lastTargetPosition = Vector3.zero;
        private Quaternion lastTargetRotation = Quaternion.identity;
        
        // Cached calculations to avoid repeated operations
        private float palmFacingThresholdDot;
        private float cameraLookingThresholdDot;

        private void Awake()
        {
            // Store initial scale and ensure menu starts visually hidden but functionally active
            if (menuGameObject != null)
            {
                initialScale = menuGameObject.transform.localScale;
                // Hide menu visually but keep it active so TrashCan can be found by existing MelodyBlocks
                menuGameObject.transform.localScale = Vector3.zero;
                // Don't deactivate: menuGameObject.SetActive(false);
            }
            
            // Cache dot product thresholds to avoid repeated calculations
            palmFacingThresholdDot = palmFacingThreshold;
            cameraLookingThresholdDot = cameraLookingThreshold;
        }

        private void Start()
        {
            // Cache interactors after all objects are initialized
            CacheInteractors();
            
            // Optionally, add the Y offset for XREAL from XROrigin
            #if XREAL
            var xrealTransformOffset = new Vector3(0, _xrOrigin.CameraYOffset, 0);
            transform.position += xrealTransformOffset;
            #endif
        }

        private void Update()
        {
            // Frame-based optimization: only update at specified frequency
            frameCounter++;
            if (frameCounter < updateFrequencyDivisor)
                return;
            frameCounter = 0;

            CheckHandConditions();
            UpdateMenuPosition();
        }

        /// <summary>
        /// Checks both hands against the detection criteria and updates active hand state
        /// </summary>
        private void CheckHandConditions()
        {
            bool leftHandValid = IsHandValid(leftHandTransform, true);
            bool rightHandValid = IsHandValid(rightHandTransform, false);

            ActiveHand newActiveHand = DetermineActiveHand(leftHandValid, rightHandValid);

            // Handle hand switching
            if (newActiveHand != currentActiveHand)
            {
                HandleHandSwitch(newActiveHand);
            }
        }

        /// <summary>
        /// Determines which hand should be active based on validity and current state
        /// </summary>
        private ActiveHand DetermineActiveHand(bool leftHandValid, bool rightHandValid)
        {
            if (leftHandValid && rightHandValid)
            {
                // Both hands valid, prefer current hand or default to left
                return currentActiveHand == ActiveHand.Right ? ActiveHand.Right : ActiveHand.Left;
            }
            else if (leftHandValid)
            {
                return ActiveHand.Left;
            }
            else if (rightHandValid)
            {
                return ActiveHand.Right;
            }
            else
            {
                return ActiveHand.None;
            }
        }

        /// <summary>
        /// Handles switching between hands and menu activation/deactivation
        /// </summary>
        private void HandleHandSwitch(ActiveHand newActiveHand)
        {
            // Log hand switching (but not initial state)
            if (enableDebugLogging && currentActiveHand != ActiveHand.None && newActiveHand != ActiveHand.None)
            {
                Debug.Log($"[SimpleHandMenu] Switching from {currentActiveHand} hand to {newActiveHand} hand");
            }

            currentActiveHand = newActiveHand;

            // Handle menu activation/deactivation
            bool shouldBeActive = currentActiveHand != ActiveHand.None;
            if (shouldBeActive != isMenuActive)
            {
                if (shouldBeActive)
                {
                    ActivateMenu();
                }
                else
                {
                    DeactivateMenu();
                }
            }
        }

        /// <summary>
        /// Checks if a hand meets both palm orientation and camera gaze criteria
        /// Optimized with early exits and cached calculations
        /// </summary>
        private bool IsHandValid(Transform handTransform, bool isLeftHand)
        {
            // Early exit for null references
            if (handTransform == null || cameraTransform == null) 
                return false;

            // Early exit: Check if hand is currently grabbing something (most expensive check first)
            if (hideMenuWhileGrabbing && IsHandGrabbingCached(isLeftHand))
                return false;

            // Cache frequently used positions
            Vector3 handPosition = handTransform.position;
            Vector3 cameraPosition = cameraTransform.position;

            // Check palm orientation: positive X for left hand, negative X for right hand
            Vector3 palmDirection = isLeftHand ? handTransform.right : -handTransform.right;
            Vector3 toCameraDirection = (cameraPosition - handPosition).normalized;
            float palmDot = Vector3.Dot(palmDirection, toCameraDirection);

            // Early exit if palm orientation fails
            if (palmDot < palmFacingThresholdDot) 
                return false;

            // Check if camera is looking at hand
            Vector3 cameraForward = cameraTransform.forward;
            Vector3 toHandDirection = (handPosition - cameraPosition).normalized;
            float cameraDot = Vector3.Dot(cameraForward, toHandDirection);

            return cameraDot > cameraLookingThresholdDot;
        }

        /// <summary>
        /// Updates menu position and rotation to follow the active hand and face the camera
        /// Optimized with threshold-based updates to avoid micro-movements
        /// </summary>
        private void UpdateMenuPosition()
        {
            // Early exit if menu is not active
            if (!isMenuActive || menuGameObject == null) 
                return;

            Transform activeHandPoseTransform = GetActiveHandPoseTransform();
            if (activeHandPoseTransform == null) 
                return;

            // Calculate base target position from hand pose
            Vector3 baseTargetPosition = activeHandPoseTransform.position;
            
            // Calculate base target rotation (always face the camera)
            Vector3 lookDirection = cameraTransform.position - baseTargetPosition;
            Quaternion baseTargetRotation = Quaternion.identity;
            if (lookDirection.sqrMagnitude > 0.001f) // Use sqrMagnitude for performance
            {
                baseTargetRotation = Quaternion.LookRotation(lookDirection);
            }

            // Apply offset transform if provided
            Vector3 finalTargetPosition = baseTargetPosition;
            Quaternion finalTargetRotation = baseTargetRotation;
            
            Vector3 offsetPosition;
            Quaternion offsetRotation;
            if (GetOffsetForActiveHand(out offsetPosition, out offsetRotation))
            {
                // Apply offset position relative to the base rotation
                finalTargetPosition += baseTargetRotation * offsetPosition;
                
                // Apply offset rotation
                finalTargetRotation *= offsetRotation;
            }

            // Threshold-based updates to avoid unnecessary micro-movements
            Transform menuTransform = menuGameObject.transform;
            bool shouldUpdatePosition = Vector3.SqrMagnitude(finalTargetPosition - menuTransform.position) > positionUpdateThreshold * positionUpdateThreshold;
            bool shouldUpdateRotation = Quaternion.Angle(finalTargetRotation, menuTransform.rotation) > rotationUpdateThreshold;

            // Compensate lerp speed for reduced update frequency
            float adjustedLerpSpeed = lerpSpeed * Time.deltaTime * updateFrequencyDivisor;

            // Only update if changes are significant enough
            if (shouldUpdatePosition)
            {
                menuTransform.position = Vector3.Lerp(menuTransform.position, finalTargetPosition, adjustedLerpSpeed);
                lastTargetPosition = finalTargetPosition;
            }

            if (shouldUpdateRotation)
            {
                menuTransform.rotation = Quaternion.Lerp(menuTransform.rotation, finalTargetRotation, adjustedLerpSpeed);
                lastTargetRotation = finalTargetRotation;
            }
        }

        /// <summary>
        /// Gets the transform of the currently active hand (parent transform for activation logic)
        /// </summary>
        private Transform GetActiveHandTransform()
        {
            switch (currentActiveHand)
            {
                case ActiveHand.Left: return leftHandTransform;
                case ActiveHand.Right: return rightHandTransform;
                default: return null;
            }
        }

        /// <summary>
        /// Gets the first child transform of the currently active hand (used for positioning)
        /// </summary>
        private Transform GetActiveHandPoseTransform()
        {
            Transform handTransform = GetActiveHandTransform();
            if (handTransform == null || handTransform.childCount == 0)
                return handTransform; // Fallback to parent if no children

            return handTransform.GetChild(0);
        }

        /// <summary>
        /// Gets the offset position and rotation for the currently active hand, with automatic mirroring
        /// </summary>
        private bool GetOffsetForActiveHand(out Vector3 offsetPosition, out Quaternion offsetRotation)
        {
            offsetPosition = Vector3.zero;
            offsetRotation = Quaternion.identity;

            if (currentActiveHand == ActiveHand.Left)
            {
                if (leftHandOffsetTransform != null)
                {
                    offsetPosition = leftHandOffsetTransform.localPosition;
                    offsetRotation = leftHandOffsetTransform.localRotation;
                    return true;
                }
                else if (rightHandOffsetTransform != null)
                {
                    // Mirror right hand offset for left hand
                    MirrorOffsetForOppositeHand(rightHandOffsetTransform.localPosition, rightHandOffsetTransform.localRotation, out offsetPosition, out offsetRotation);
                    return true;
                }
            }
            else if (currentActiveHand == ActiveHand.Right)
            {
                if (rightHandOffsetTransform != null)
                {
                    offsetPosition = rightHandOffsetTransform.localPosition;
                    offsetRotation = rightHandOffsetTransform.localRotation;
                    return true;
                }
                else if (leftHandOffsetTransform != null)
                {
                    // Mirror left hand offset for right hand
                    MirrorOffsetForOppositeHand(leftHandOffsetTransform.localPosition, leftHandOffsetTransform.localRotation, out offsetPosition, out offsetRotation);
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Mirrors an offset position and rotation for the opposite hand
        /// </summary>
        private void MirrorOffsetForOppositeHand(Vector3 sourcePosition, Quaternion sourceRotation, out Vector3 mirroredPosition, out Quaternion mirroredRotation)
        {
            // Mirror position: flip X axis
            mirroredPosition = new Vector3(-sourcePosition.x, sourcePosition.y, sourcePosition.z);

            // Mirror rotation: negate Y and Z components to mirror across YZ plane
            mirroredRotation = new Quaternion(sourceRotation.x, -sourceRotation.y, -sourceRotation.z, sourceRotation.w);
        }

        /// <summary>
        /// Activates the menu with scaling animation
        /// </summary>
        private void ActivateMenu()
        {
            if (menuGameObject == null) 
                return;

            isMenuActive = true;
            
            // Enable MenuIconsBar colliders
            SetMenuCollidersEnabled(true);
            
            if (enableDebugLogging)
            {
                string offsetInfo = GetOffsetDebugInfo();
                Debug.Log($"[SimpleHandMenu] Activating menu for {currentActiveHand} hand{offsetInfo}");
            }
            // GameObject is always active now, just scale up from current scale

            // Start scale-up animation from current scale to target scale
            if (scaleCoroutine != null)
            {
                StopCoroutine(scaleCoroutine);
            }
            scaleCoroutine = StartCoroutine(ScaleAnimation(menuGameObject.transform.localScale, targetScale));
        }

        /// <summary>
        /// Gets debug information about which offset is being used
        /// </summary>
        private string GetOffsetDebugInfo()
        {
            if (currentActiveHand == ActiveHand.Left)
            {
                if (leftHandOffsetTransform != null)
                    return " (using left hand offset)";
                else if (rightHandOffsetTransform != null)
                    return " (using mirrored right hand offset)";
            }
            else if (currentActiveHand == ActiveHand.Right)
            {
                if (rightHandOffsetTransform != null)
                    return " (using right hand offset)";
                else if (leftHandOffsetTransform != null)
                    return " (using mirrored left hand offset)";
            }
            return " (no offset)";
        }

        /// <summary>
        /// Cache interactors for both hands for performance
        /// </summary>
        private void CacheInteractors()
        {
            if (interactorsCached) return;

            leftHandInteractors.Clear();
            rightHandInteractors.Clear();

            // Cache left hand interactors
            Transform leftGroup = leftHandInteractorGroup != null ? leftHandInteractorGroup : leftHandTransform;
            if (leftGroup != null)
            {
                XRBaseInteractor[] leftInteractors = leftGroup.GetComponentsInChildren<XRBaseInteractor>();
                leftHandInteractors.AddRange(leftInteractors);
            }

            // Cache right hand interactors
            Transform rightGroup = rightHandInteractorGroup != null ? rightHandInteractorGroup : rightHandTransform;
            if (rightGroup != null)
            {
                XRBaseInteractor[] rightInteractors = rightGroup.GetComponentsInChildren<XRBaseInteractor>();
                rightHandInteractors.AddRange(rightInteractors);
            }

            interactorsCached = true;
        }

        /// <summary>
        /// Check if a specific hand is currently grabbing/selecting something (with frame-based caching)
        /// </summary>
        private bool IsHandGrabbingCached(bool isLeftHand)
        {
            // Update grab cache only once per frame for performance
            if (Time.frameCount != lastGrabCheckFrame)
            {
                UpdateGrabCache();
            }

            return isLeftHand ? leftHandGrabbingCache : rightHandGrabbingCache;
        }

        /// <summary>
        /// Updates the grab detection cache for both hands (called once per frame max)
        /// </summary>
        private void UpdateGrabCache()
        {
            lastGrabCheckFrame = Time.frameCount;
            
            if (!interactorsCached)
                CacheInteractors();

            leftHandGrabbingCache = CheckInteractorsForGrab(leftHandInteractors);
            rightHandGrabbingCache = CheckInteractorsForGrab(rightHandInteractors);
        }

        /// <summary>
        /// Check if any interactor in the list is currently grabbing (optimized)
        /// </summary>
        private bool CheckInteractorsForGrab(List<XRBaseInteractor> interactors)
        {
            for (int i = 0; i < interactors.Count; i++)
            {
                var interactor = interactors[i];
                if (interactor != null && interactor.hasSelection)
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Refresh the cached interactors (call this if interactors are added/removed at runtime)
        /// </summary>
        public void RefreshInteractorCache()
        {
            interactorsCached = false;
            lastGrabCheckFrame = -1;
            leftHandGrabbingCache = false;
            rightHandGrabbingCache = false;
            CacheInteractors();
        }

        /// <summary>
        /// Adjust performance settings at runtime for different scenarios
        /// </summary>
        public void SetPerformanceMode(bool highPerformance)
        {
            if (highPerformance)
            {
                // High performance: reduce update frequency, increase thresholds
                updateFrequencyDivisor = 3;
                positionUpdateThreshold = 0.005f;
                rotationUpdateThreshold = 3f;
            }
            else
            {
                // High quality: more frequent updates, lower thresholds
                updateFrequencyDivisor = 1;
                positionUpdateThreshold = 0.001f;
                rotationUpdateThreshold = 1f;
            }
        }

        /// <summary>
        /// Enable or disable debug logging at runtime
        /// </summary>
        public void SetDebugLogging(bool enabled)
        {
            enableDebugLogging = enabled;
        }

        /// <summary>
        /// Helper method for conditional debug logging (for future use)
        /// </summary>
        private void DebugLog(string message)
        {
            if (enableDebugLogging)
            {
                Debug.Log($"[SimpleHandMenu] {message}");
            }
        }

        /// <summary>
        /// Get current debug logging status
        /// </summary>
        public bool IsDebugLoggingEnabled()
        {
            return enableDebugLogging;
        }

        /// <summary>
        /// Deactivates the menu with scaling animation
        /// </summary>
        private void DeactivateMenu()
        {
            if (menuGameObject == null) 
                return;

            isMenuActive = false;
            
            // Disable MenuIconsBar colliders
            SetMenuCollidersEnabled(false);
            
            // Notify all objects in menu zones to exit
            OnMenuDeactivated?.Invoke();
            
            if (enableDebugLogging)
            {
                Debug.Log("[SimpleHandMenu] Deactivating menu");
            }

            // Start scale-down animation to zero (but keep GameObject active for TrashCan)
            if (scaleCoroutine != null)
            {
                StopCoroutine(scaleCoroutine);
            }
            scaleCoroutine = StartCoroutine(ScaleAnimation(menuGameObject.transform.localScale, Vector3.zero, false));
        }

        /// <summary>
        /// Enables or disables all interactive colliders within the menu.
        /// This includes MenuIconsBar and SpatialButton colliders.
        /// </summary>
        /// <param name="enabled">Whether to enable or disable the colliders.</param>
        private void SetMenuCollidersEnabled(bool enabled)
        {
            if (menuGameObject == null) return;
            
            // Find all colliders in the menu hierarchy
            Collider[] menuColliders = menuGameObject.GetComponentsInChildren<Collider>(true);
            
            foreach (Collider collider in menuColliders)
            {
                // Disable colliders that are interactive UI elements
                if (collider.CompareTag("MenuIconsBar") ||
                    collider.CompareTag("SpatialButton"))
                {
                    collider.enabled = enabled;
                }
            }
        }

        /// <summary>
        /// Coroutine for smooth scale animation between two scales
        /// </summary>
        private IEnumerator ScaleAnimation(Vector3 fromScale, Vector3 toScale, bool deactivateAtEnd = false)
        {
            float elapsed = 0f;
            
            while (elapsed < scaleAnimationDuration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / scaleAnimationDuration;
                
                // Use smooth step for better animation curve
                t = t * t * (3f - 2f * t);
                
                menuGameObject.transform.localScale = Vector3.Lerp(fromScale, toScale, t);
                yield return null;
            }

            menuGameObject.transform.localScale = toScale;
            
            // Note: We no longer deactivate the GameObject to keep TrashCan findable
            // if (deactivateAtEnd)
            // {
            //     menuGameObject.SetActive(false);
            // }

            scaleCoroutine = null;
        }

        /// <summary>
        /// Clean up coroutines when disabled
        /// </summary>
        private void OnDisable()
        {
            if (scaleCoroutine != null)
            {
                StopCoroutine(scaleCoroutine);
                scaleCoroutine = null;
            }
            
            // Reset menu to initial scale when component is disabled
            if (menuGameObject != null && initialScale != Vector3.zero)
            {
                menuGameObject.transform.localScale = initialScale;
            }
            
            // Reset interactor cache when disabled
            interactorsCached = false;
            lastGrabCheckFrame = -1;
            leftHandGrabbingCache = false;
            rightHandGrabbingCache = false;
            frameCounter = 0;
        }

        /// <summary>
        /// Reset menu state when component is destroyed
        /// </summary>
        private void OnDestroy()
        {
            if (menuGameObject != null && initialScale != Vector3.zero)
            {
                menuGameObject.transform.localScale = initialScale;
            }
        }

        // Editor helpers for debugging
        #if UNITY_EDITOR
        private void OnDrawGizmosSelected()
        {
            if (!Application.isPlaying) return;

            // Draw debug lines to show detection rays
            if (cameraTransform != null)
            {
                Gizmos.color = Color.blue;
                Gizmos.DrawRay(cameraTransform.position, cameraTransform.forward * 2f);
                
                if (leftHandTransform != null)
                {
                    Gizmos.color = IsHandValid(leftHandTransform, true) ? Color.green : Color.red;
                    Gizmos.DrawRay(leftHandTransform.position, leftHandTransform.right * 0.5f);
                    Gizmos.DrawLine(cameraTransform.position, leftHandTransform.position);
                }
                
                if (rightHandTransform != null)
                {
                    Gizmos.color = IsHandValid(rightHandTransform, false) ? Color.green : Color.red;
                    Gizmos.DrawRay(rightHandTransform.position, -rightHandTransform.right * 0.5f);
                    Gizmos.DrawLine(cameraTransform.position, rightHandTransform.position);
                }
            }
        }
        #endif
    }
} 
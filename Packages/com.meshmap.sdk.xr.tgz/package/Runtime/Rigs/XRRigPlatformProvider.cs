// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR.Interaction.Toolkit.Inputs;

namespace MeshMap.XR.Rigs
{
    /// <summary>
    /// Provides platform-specific XR rig and input action assets at runtime based on the active build target's scripting define.
    /// </summary>
    public class XRRigPlatformProvider : MonoBehaviour
    {
        private readonly string _xrealRig = "Rigs/Prefabs/XREAL";
        private readonly string _metaQuestRig = "Rigs/Prefabs/METAQUEST";
        private readonly string _magicLeapRig = "Rigs/Prefabs/MAGICLEAP";

        private readonly string _xrealInput = "Rigs/Input/XREAL Actions";
        private readonly string _magicLeapInput = "Rigs/Input/MagicLeapOpenXRInput";

        private void Awake()
        {   
            #if XREAL
            ProvidePlatformExtensions(_xrealInput, _xrealRig);
            #elif METAQUEST
            ProvidePlatformExtensions("", _metaQuestRig);
            #elif MAGICLEAP
            ProvidePlatformExtensions(_magicLeapInput, _magicLeapRig);
            #endif
        }

        private void ProvidePlatformExtensions(string input, string rig)
        {
            InputActionManager inputActionManager = GetComponentInChildren<InputActionManager>();

            if (inputActionManager == null)
            {
                Debug.LogError("XRRig PLATFORM PROVIDER: InputActionManager not found");
                return;
            }

            var inputAsset = Resources.Load<InputActionAsset>(input);
            if (inputAsset == null)
            {
                Debug.LogWarning($"XRRig PLATFORM PROVIDER: InputActionAsset not found: {input}");
            }
            else 
            {
                inputActionManager.actionAssets.Add(inputAsset);
            }

            var rigObject = Resources.Load<GameObject>(rig);
            if (rigObject == null)
            {
                Debug.LogWarning($"XRRig PLATFORM PROVIDER: Rig not found: {rig}");
            }
            else 
            {
                Instantiate(rigObject, transform);
            }
        }
    }
}
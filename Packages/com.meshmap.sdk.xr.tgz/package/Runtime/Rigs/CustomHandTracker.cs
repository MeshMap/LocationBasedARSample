// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using UnityEngine;

namespace MeshMap.XR
{
    /// <summary>
    /// Hand tracking helper that switches between <c>TrackedPoseDriver</c> and <c>TrackedPoseDriver (Input System)</c> depending on target device.
    /// </summary>
    [RequireComponent(typeof(UnityEngine.InputSystem.XR.TrackedPoseDriver), typeof(UnityEngine.SpatialTracking.TrackedPoseDriver))]
    public class CustomHandTracker : MonoBehaviour
    {
        void Awake()
        {
            TryGetComponent(out UnityEngine.InputSystem.XR.TrackedPoseDriver trackedPoseDriver);
            TryGetComponent(out UnityEngine.SpatialTracking.TrackedPoseDriver trackedPoseDriverFallback);
            if (trackedPoseDriverFallback == null || trackedPoseDriver == null)
            {
                Debug.LogWarning("CustomHandTracker: TrackedPoseDrivers not set up properly, disabling CustomHandTracker.");

                enabled = false;

                return;
            }

            #if XREAL
            trackedPoseDriver.enabled = true;
            trackedPoseDriverFallback.enabled = false;
            #else
            trackedPoseDriver.enabled = false;
            trackedPoseDriverFallback.enabled = true;
            #endif
        }
    }
}

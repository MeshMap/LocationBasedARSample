// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using UnityEngine;
using UnityEngine.XR.Hands;
using UnityEngine.XR.Interaction.Toolkit.Interactors;
using UnityEngine.XR.Management;
using UnityEngine.InputSystem.XR;

namespace MeshMap.XR.Interactors
{
    /// <summary>
    /// Tracks and updates the pose of the <see cref="XRPokeInteractor"/>.
    /// </summary>
    public class XRPokeInteractorDriver : MonoBehaviour
    {
        /// <summary>
        /// Reference to the XR Hand Subsystem used for accessing hand tracking data.
        /// </summary>
        protected XRHandSubsystem _handSubsystem;
        
        /// <summary>
        /// The XRHandJointID representing the index fingertip joint.
        /// </summary>
        protected readonly XRHandJointID _indexTipJoint = XRHandJointID.IndexTip;
        
        [SerializeField] protected InteractorHandedness _handedness = InteractorHandedness.Left;
        [SerializeField] protected XRPokeInteractor _pokeInteractor;

        protected void Start()
        {
            #if MAGICLEAP
            TryGetComponent<TrackedPoseDriver>(out TrackedPoseDriver trackedPoseDriver);
            if (trackedPoseDriver != null)
            {
                trackedPoseDriver.enabled = false;
            }
            InitializeXRHandSubsystem();
            #else
            this.enabled = false;
            #endif
        }

        protected void Update()
        {
            if (_handSubsystem == null) return;
            
            if (TryGetTrackedHand(out XRHand hand) && TryGetIndexPose(hand, out Pose pose))
            {
                _pokeInteractor.attachTransform.position = pose.position;
                _pokeInteractor.attachTransform.rotation = pose.rotation;
            }
        }
        
        /// <summary>
        /// Attempts to find and assign the XRHandSubsystem from the active XR loader.
        /// </summary>
        protected void InitializeXRHandSubsystem()
        {
            _handSubsystem = XRGeneralSettings.Instance.Manager.activeLoader?.GetLoadedSubsystem<XRHandSubsystem>();
            if (_handSubsystem == null)
                Debug.LogWarning("XRHandSubsystem not found.");
        }
        
        /// <summary>
        /// Attempts to retrieve the currently tracked XRHand based on the selected handedness.
        /// </summary>
        /// <returns>The left or right XRHand.</returns>
        protected bool TryGetTrackedHand(out XRHand hand)
        {
            if (_handedness == InteractorHandedness.Left)
            {
                hand = _handSubsystem.leftHand;
                return hand.isTracked;
            }
            else if (_handedness == InteractorHandedness.Right)
            {
                hand = _handSubsystem.rightHand;
                return hand.isTracked;
            }

            hand = default;
            return false;
        }
        
        /// <summary>
        /// Attempts to retrieve the pose of the index fingertip joint.
        /// </summary>
        /// <param name="hand">The XRHand to query.</param>
        /// <param name="indexPose">Output pose of the index fingertip.</param>
        /// <returns>True if joint pose was successfully retrieved; otherwise false.</returns>
        protected bool TryGetIndexPose(XRHand hand, out Pose pose)
        {
            pose = default;

            if (!hand.isTracked)
                return false;
            
            var indexTip = hand.GetJoint(_indexTipJoint);
            bool indexOk = indexTip.TryGetPose(out pose);

            return indexOk;
        }
    }
}
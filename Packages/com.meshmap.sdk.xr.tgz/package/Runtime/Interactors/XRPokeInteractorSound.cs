// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.XR.Interaction.Toolkit.Interactors;
using UnityEngine.XR.Interaction.Toolkit.UI;
#if USING_MM_BUILDING_BLOCKS
using MeshMap.BuildingBlocks.Audio;
#endif

namespace MeshMap.XR.Interactors
{
    /// <summary>
    /// Controls the sound effects of the <see cref="XRPokeInteractor"/>.
    /// </summary>
    public class XRPokeInteractorSound : MonoBehaviour
    {
        [SerializeField] private XRUIInputModule _XRUIInputModule;
        
        [SerializeField, Tooltip("Use the Audio Manager and Audio Registry. Requires MeshMap Building Blocks.")]
        private bool _useAudioRegistry = true;
        [SerializeField, Tooltip("String key used to lookup clip in Audio Registry.")]
        private string _audioClipKey = "UI.Hover";

        [SerializeField, Tooltip("Optional local Audio Source override.")]
        private AudioSource _localAudioSource;
        
        private void OnEnable()
        {
            if (_XRUIInputModule != null)
                _XRUIInputModule.pointerClick += OnXRPointerClick;
        }

        private void OnDisable()
        {
            if (_XRUIInputModule != null)
                _XRUIInputModule.pointerClick -= OnXRPointerClick;
        }

        private void OnXRPointerClick(GameObject target, PointerEventData data)
        {
            if (target == null) return;

            if (_useAudioRegistry)
            {
                #if USING_MM_BUILDING_BLOCKS
                AudioManager.Instance.PlayUI(_audioClipKey);
                #else
                Debug.LogWarning("The MeshMap Building Blocks package (com.mmsdk.unity.bb) is required to use this function.");
                #endif
            }
            else
            {
                _localAudioSource.Play();
            }
        }
    }
}
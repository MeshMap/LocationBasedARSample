// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;
#if XR_HANDS_1_1_OR_NEWER
using UnityEngine.XR.Hands;
#endif
#if UNITY_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace MeshMap.XR.Interactors
{
    /// <summary>
    /// This component is a platform-agnostic helper for XRInputModalityManager to robustly switch between hands and controllers,
    /// with an override to use controller when any controller button is pressed, even if the OS hasn't reported tracking yet.
    /// Per-hand switching on MQ3 is not yet supported through OpenXR (https://developers.meta.com/horizon/documentation/unity/unity-multimodal/).
    /// </summary>
    [AddComponentMenu("XR/XR Input Modality Manager (MeshMap)")]
    public class CustomXRInputModalityManager : MonoBehaviour
    {
        public enum InputMode
        {
            None,
            TrackedHand,
            MotionController,
        }

        [Header("Hand Tracking")]
        [SerializeField]
        GameObject m_LeftHand;

        [SerializeField]
        GameObject m_RightHand;

        [Header("Motion Controllers")]
        [SerializeField]
        GameObject m_LeftController;

        [SerializeField]
        GameObject m_RightController;

        InputMode m_LeftInputMode;
        InputMode m_RightInputMode;

#if XR_HANDS_1_1_OR_NEWER
        XRHandSubsystem m_HandSubsystem;
        static readonly List<XRHandSubsystem> s_HandSubsystems = new List<XRHandSubsystem>();
#endif

        static readonly InputDeviceCharacteristics k_LeftController =
            InputDeviceCharacteristics.HeldInHand | InputDeviceCharacteristics.TrackedDevice | InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Left;
        static readonly InputDeviceCharacteristics k_RightController =
            InputDeviceCharacteristics.HeldInHand | InputDeviceCharacteristics.TrackedDevice | InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Right;

        void OnEnable()
        {
#if XR_HANDS_1_1_OR_NEWER
            TryGetHandSubsystem(out m_HandSubsystem);
#endif
            UpdateLeftMode();
            UpdateRightMode();
        }

        void Update()
        {
#if XR_HANDS_1_1_OR_NEWER
            if (m_HandSubsystem == null || !m_HandSubsystem.running)
                TryGetHandSubsystem(out m_HandSubsystem);
#endif
            UpdateLeftMode();
            UpdateRightMode();

#if UNITY_INPUT_SYSTEM
            // If any ML2 controller button is pressed, prioritize controller mode for that hand
            DetectControllerButtonActivity();
#endif
            // Also probe XR module button usages to be independent of Input System layouts
            DetectControllerButtonActivityXRModule();
        }

        void UpdateLeftMode()
        {
            var controllerTracked = TryGetControllerTracked(k_LeftController);
            var handTracked = GetLeftHandIsTracked();

            if (controllerTracked)
            {
                SetLeftMode(InputMode.MotionController);
            }
            else if (handTracked)
            {
                SetLeftMode(InputMode.TrackedHand);
            }
            else
            {
                SetLeftMode(InputMode.None);
            }
        }

        void UpdateRightMode()
        {
            var controllerTracked = TryGetControllerTracked(k_RightController);
            var handTracked = GetRightHandIsTracked();

            if (controllerTracked)
            {
                SetRightMode(InputMode.MotionController);
            }
            else if (handTracked)
            {
                SetRightMode(InputMode.TrackedHand);
            }
            else
            {
                SetRightMode(InputMode.None);
            }
        }

        void SetLeftMode(InputMode mode)
        {
            SafeSetActive(m_LeftHand, mode == InputMode.TrackedHand);
            SafeSetActive(m_LeftController, mode == InputMode.MotionController);
            m_LeftInputMode = mode;
        }

        void SetRightMode(InputMode mode)
        {
            SafeSetActive(m_RightHand, mode == InputMode.TrackedHand);
            SafeSetActive(m_RightController, mode == InputMode.MotionController);
            m_RightInputMode = mode;
        }

        public void SetReferences(GameObject leftHand, GameObject rightHand, GameObject leftController, GameObject rightController)
        {
            m_LeftHand = leftHand;
            m_RightHand = rightHand;
            m_LeftController = leftController;
            m_RightController = rightController;
        }

        static void SafeSetActive(GameObject go, bool active)
        {
            if (go != null && go.activeSelf != active)
                go.SetActive(active);
        }

        static bool TryGetControllerTracked(InputDeviceCharacteristics desiredCharacteristics)
        {
            var devices = s_TempDevices;
            InputDevices.GetDevicesWithCharacteristics(desiredCharacteristics, devices);
            for (var i = 0; i < devices.Count; ++i)
            {
                if (IsTracked(devices[i]))
                    return true;
            }
            return false;
        }

        static readonly List<InputDevice> s_TempDevices = new List<InputDevice>(4);

        static bool IsTracked(InputDevice device)
        {
            if (!device.isValid)
                return false;

            if (device.TryGetFeatureValue(CommonUsages.isTracked, out var isTracked) && isTracked)
                return true;

            const InputTrackingState positionAndRotation = InputTrackingState.Position | InputTrackingState.Rotation;
            return device.TryGetFeatureValue(CommonUsages.trackingState, out var trackingState) &&
                   (trackingState & positionAndRotation) == positionAndRotation;
        }

        void DetectControllerButtonActivityXRModule()
        {
            // Left
            s_TempDevices.Clear();
            InputDevices.GetDevicesWithCharacteristics(k_LeftController, s_TempDevices);
            for (var i = 0; i < s_TempDevices.Count; ++i)
            {
                if (AnyControllerButtonPressed(s_TempDevices[i]))
                {
                    SetLeftMode(InputMode.MotionController);
                    break;
                }
            }

            // Right
            s_TempDevices.Clear();
            InputDevices.GetDevicesWithCharacteristics(k_RightController, s_TempDevices);
            for (var i = 0; i < s_TempDevices.Count; ++i)
            {
                if (AnyControllerButtonPressed(s_TempDevices[i]))
                {
                    SetRightMode(InputMode.MotionController);
                    break;
                }
            }
        }

        static bool AnyControllerButtonPressed(InputDevice device)
        {
            if (!device.isValid)
                return false;

            bool value;
            if (device.TryGetFeatureValue(CommonUsages.menuButton, out value) && value) return true;
            if (device.TryGetFeatureValue(CommonUsages.gripButton, out value) && value) return true;
            if (device.TryGetFeatureValue(CommonUsages.triggerButton, out value) && value) return true;
            if (device.TryGetFeatureValue(CommonUsages.primaryButton, out value) && value) return true;
            if (device.TryGetFeatureValue(CommonUsages.secondaryButton, out value) && value) return true;
            if (device.TryGetFeatureValue(CommonUsages.primary2DAxisClick, out value) && value) return true;
            if (device.TryGetFeatureValue(CommonUsages.primary2DAxisTouch, out value) && value) return true;
            return false;
        }

        #if UNITY_INPUT_SYSTEM
        void DetectControllerButtonActivity()
        {
            var devices = InputSystem.InputSystem.devices;
            for (var i = 0; i < devices.Count; ++i)
            {
                if (devices[i] is InputSystem.XR.XRController xrController)
                {
                    // Heuristics: treat any XRController with typical button controls as a controller

                    // Probe common button controls by name; ignore if none exist
                    bool anyPressed = false;
                    var ctrl = (InputControl)xrController;
                    anyPressed |= ctrl.TryGetChildControl<ButtonControl>("menu")?.isPressed == true;
                    anyPressed |= ctrl.TryGetChildControl<ButtonControl>("triggerPressed")?.isPressed == true;
                    anyPressed |= ctrl.TryGetChildControl<ButtonControl>("gripPressed")?.isPressed == true;
                    anyPressed |= ctrl.TryGetChildControl<ButtonControl>("gripButton")?.isPressed == true;
                    anyPressed |= ctrl.TryGetChildControl<ButtonControl>("primaryButton")?.isPressed == true;
                    anyPressed |= ctrl.TryGetChildControl<ButtonControl>("secondaryButton")?.isPressed == true;
                    anyPressed |= ctrl.TryGetChildControl<ButtonControl>("primary2DAxisClick")?.isPressed == true;
                    anyPressed |= ctrl.TryGetChildControl<ButtonControl>("primary2DAxisTouch")?.isPressed == true;
                    anyPressed |= ctrl.TryGetChildControl<ButtonControl>("trackpadClicked")?.isPressed == true; // ML
                    anyPressed |= ctrl.TryGetChildControl<ButtonControl>("trackpadTouched")?.isPressed == true; // ML

                    if (!anyPressed)
                        continue;

                    var usages = xrController.usages;
                    if (usages.Contains(UnityEngine.InputSystem.CommonUsages.LeftHand))
                        SetLeftMode(InputMode.MotionController);
                    else if (usages.Contains(UnityEngine.InputSystem.CommonUsages.RightHand))
                        SetRightMode(InputMode.MotionController);
                }
            }
        }
        #endif

        bool GetLeftHandIsTracked()
        {
#if XR_HANDS_1_1_OR_NEWER
            return m_HandSubsystem != null && m_HandSubsystem.running && m_HandSubsystem.leftHand.isTracked;
#else
            return false;
#endif
        }

        bool GetRightHandIsTracked()
        {
#if XR_HANDS_1_1_OR_NEWER
            return m_HandSubsystem != null && m_HandSubsystem.running && m_HandSubsystem.rightHand.isTracked;
#else
            return false;
#endif
        }

#if XR_HANDS_1_1_OR_NEWER
        static bool TryGetHandSubsystem(out XRHandSubsystem handSubsystem)
        {
            s_HandSubsystems.Clear();
            SubsystemManager.GetSubsystems(s_HandSubsystems);
            for (var i = 0; i < s_HandSubsystems.Count; ++i)
            {
                var sub = s_HandSubsystems[i];
                if (sub != null && sub.running)
                {
                    handSubsystem = sub;
                    return true;
                }
            }
            handSubsystem = null;
            return false;
        }
#endif
    }
}



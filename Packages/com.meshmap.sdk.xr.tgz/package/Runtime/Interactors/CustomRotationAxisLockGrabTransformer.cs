// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using UnityEngine.XR.Interaction.Toolkit.Interactables;
using UnityEngine.XR.Interaction.Toolkit.Transformers;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine;

namespace MeshMap.XR.Interactors
{
    /// <summary>
    /// An XR grab transformer that allows for the locking of specific rotation axes in world space. When an object is grabbed and manipulated,
    /// this class ensures that rotations are only applied to the specified axes in global coordinates, preserving the initial world rotation for the others.
    /// </summary>
    [AddComponentMenu("XR/Rotation Axis Lock Grab Transformer (MeshMap)")]
    public class CustomRotationAxisLockGrabTransformer : XRBaseGrabTransformer
    {
        [SerializeField]
        [Tooltip("Defines which rotation axes are allowed when an object is grabbed. Axes not selected will maintain their initial world rotation.")]
        XRGeneralGrabTransformer.ManipulationAxes m_PermittedRotationAxis = XRGeneralGrabTransformer.ManipulationAxes.All;

        /// <inheritdoc />
        protected override RegistrationMode registrationMode => RegistrationMode.SingleAndMultiple;

        Vector3 m_InitialWorldEulerRotation;

        /// <summary>
        /// Public property to access and modify the initial world rotation
        /// </summary>
        public Vector3 InitialEulerRotation
        {
            get => m_InitialWorldEulerRotation;
            set => m_InitialWorldEulerRotation = value;
        }

        /// <inheritdoc />
        public override void OnLink(XRGrabInteractable grabInteractable)
        {
            base.OnLink(grabInteractable);
            
            // Cache the current world rotation
            m_InitialWorldEulerRotation = grabInteractable.transform.rotation.eulerAngles;
        }

        /// <inheritdoc />
        public override void Process(XRGrabInteractable grabInteractable, XRInteractionUpdateOrder.UpdatePhase updatePhase, ref Pose targetPose, ref Vector3 localScale)
        {
            Vector3 newRotationEuler = targetPose.rotation.eulerAngles;

            // Apply axis locking based on permissions using initial world rotation
            if ((m_PermittedRotationAxis & XRGeneralGrabTransformer.ManipulationAxes.X) == 0)
                newRotationEuler.x = m_InitialWorldEulerRotation.x;

            if ((m_PermittedRotationAxis & XRGeneralGrabTransformer.ManipulationAxes.Y) == 0)
                newRotationEuler.y = m_InitialWorldEulerRotation.y;

            if ((m_PermittedRotationAxis & XRGeneralGrabTransformer.ManipulationAxes.Z) == 0)
                newRotationEuler.z = m_InitialWorldEulerRotation.z;

            targetPose.rotation = Quaternion.Euler(newRotationEuler);
        }
    }
}

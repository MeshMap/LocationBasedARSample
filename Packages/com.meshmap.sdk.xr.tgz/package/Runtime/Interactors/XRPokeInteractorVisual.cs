// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Interactors;

namespace MeshMap.XR.Interactors
{
    /// <summary>
    /// Updates the position of a visual indicator to follow the <see cref="XRPokeInteractor"/>.
    /// </summary>
    public class XRPokeInteractorVisual : MonoBehaviour
    {
        [SerializeField] protected XRPokeInteractor _pokeInteractor;

        protected void Update()
        {
            if (_pokeInteractor != null && _pokeInteractor.attachTransform != null)
            {
                transform.position = _pokeInteractor.attachTransform.position;
            }
        }
    }
}
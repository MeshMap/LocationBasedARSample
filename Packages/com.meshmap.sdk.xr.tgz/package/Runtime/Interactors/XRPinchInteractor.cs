// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem.XR;
using UnityEngine.XR.Hands;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using UnityEngine.XR.Interaction.Toolkit.Interactors;
using UnityEngine.XR.Management;

namespace MeshMap.XR.Interactors
{
    /// <summary>
    /// XR Interactor that tracks hand joints via <see cref="XRHandSubsystem"/> to detect pinch gestures.
    /// Reports valid targets via GetValidTargets so the <see cref="XRInteractionManager"/> and can arbitrate with other interactors.
    /// Optionally, attach a <see cref="TrackedPoseDriver"/> to update the position instead of XR Hands pose.
    /// Supports <see cref="XRSimpleInteractable"/> and <see cref="XRGrabInteractable"/>.
    /// Cross-platform compatible with Magic Leap, Meta Quest, and XREAL devices.
    /// </summary>
    public class XRPinchInteractor : XRBaseInteractor
    {
        [SerializeField, Min(0f), Tooltip("Maximum distance between index fingertip and thumb fingertip to count as a pinch gesture.")]
        private float _pinchThreshold = 0.02f;

        /// <summary>
        /// Maximum distance (meters) between index and thumb tips to count as a pinch gesture.
        /// </summary>
        public float PinchThreshold
        {
            get => _pinchThreshold;
            set => _pinchThreshold = Mathf.Max(0f, value);
        }

        [SerializeField, Tooltip("If true, use an attached TrackedPoseDriver for pose updates instead of XR Hands joint pose.")]
        private bool _useTrackedPoseDriver = false;

        /// <summary>
        /// If true, uses an attached TrackedPoseDriver for pose updates; otherwise uses XR Hands joint pose.
        /// </summary>
        public bool UseTrackedPoseDriver
        {
            get => _useTrackedPoseDriver;
            set => _useTrackedPoseDriver = value;
        }
        
        [SerializeField, Min(0f), Tooltip("Radius (meters) around the pinch/attach point to search for interactables.")]
        private float _detectionRadius = 0.016f;

        /// <summary>
        /// Radius (meters) around the pinch/attach point to search for interactables.
        /// </summary>
        public float DetectionRadius
        {
            get => _detectionRadius;
            set => _detectionRadius = Mathf.Max(0f, value);
        }
        
        [SerializeField, Tooltip("Physics layers considered during the overlap search in GetValidTargets.")]
        private LayerMask _physicsLayerMask = Physics.AllLayers;

        /// <summary>
        /// Physics layers considered during the overlap search in <c>GetValidTargets</c>.
        /// </summary>
        public LayerMask PhysicsLayerMask
        {
            get => _physicsLayerMask;
            set => _physicsLayerMask = value;
        }
        
        [SerializeField, Tooltip("Should the overlap include trigger colliders? (UseGlobal / Ignore / Collide)")]
        private QueryTriggerInteraction _physicsTriggerInteraction = QueryTriggerInteraction.Collide;

        /// <summary>
        /// Whether sphere overlaps include triggers: UseGlobal / Ignore / Collide.
        /// </summary>
        public QueryTriggerInteraction PhysicsTriggerInteraction
        {
            get => _physicsTriggerInteraction;
            set => _physicsTriggerInteraction = value;
        }
        
        /// <summary>
        /// Reference to the XR Hand Subsystem used for accessing hand tracking data.
        /// </summary>
        protected XRHandSubsystem _handSubsystem;
        
        /// <summary>
        /// The XRHandJointID representing the index fingertip joint.
        /// </summary>
        protected readonly XRHandJointID _indexTipJoint = XRHandJointID.IndexTip;
        
        /// <summary>
        /// The XRHandJointID representing the thumb fingertip joint.
        /// </summary>
        protected  readonly XRHandJointID _thumbTipJoint = XRHandJointID.ThumbTip;
        
        /// <summary>
        /// Returns whether a pinch gesture is currently detected.
        /// </summary>
        public bool IsPinching => _isPinching;
        protected bool _isPinching = false;
        
        /// <summary>
        /// Returns whether this interactor is currently grabbing an object.
        /// </summary>
        public bool IsGrabbing => _isGrabbing;
        protected bool _isGrabbing = false;
        
        /// <summary>
        /// The currently grabbed XRGrabInteractable, if any.
        /// </summary>
        protected XRGrabInteractable _grabbedInteractable = null;
        
        /// <summary>
        /// The currently selected XRSelectInteractable, if any.
        /// </summary>
        protected IXRSelectInteractable _selectedInteractable = null;
        
        readonly Collider[] _overlapHits = new Collider[32];
        readonly List<IXRInteractable> _scratchTargets = new List<IXRInteractable>(32);
        readonly List<IXRInteractable> _filteredBuffer = new List<IXRInteractable>(32);

        #region Unity Callbacks
        
        protected override void Start()
        {
            base.Start();
            
            #if MAGICLEAP
            // On Magic Leap, disable TrackedPoseDriver and use hand tracking positions directly
            TryGetComponent<TrackedPoseDriver>(out TrackedPoseDriver trackedPoseDriver);
            if (trackedPoseDriver != null)
            {
                trackedPoseDriver.enabled = false;
                Debug.Log($"Disabled TrackedPoseDriver on {gameObject.name} for Magic Leap");
            }
            _useTrackedPoseDriver = false;
            #elif XREAL
            attachTransform.localEulerAngles = new Vector3(45f, 0f, -45f);
            #elif METAQUEST
            attachTransform.localEulerAngles = new Vector3(-20f, 0f, 15f);
            #endif

            InitializeXRHandSubsystem();
        }
        
        protected void Update()
        {
            if (_handSubsystem == null) return;
            
            if (TryGetTrackedHand(out XRHand hand) && TryGetJointPoses(hand, out Pose indexPose, out Pose thumbPose))
            {
                if (!_useTrackedPoseDriver)
                {
                    transform.position = indexPose.position;
                    transform.rotation = indexPose.rotation;
                }
                AssessPinch(indexPose, thumbPose);
            }
        }

        protected void LateUpdate()
        {
            // Handle potential transfer of ownership to another XR interactor
            if (_grabbedInteractable != null && (Object)_grabbedInteractable.firstInteractorSelecting != this)
            {
                _grabbedInteractable = null;
                _isGrabbing = false;
            }
            
            // Handle potential delete when transferring ownership
            if (_grabbedInteractable == null && _isGrabbing)
            {
                _isGrabbing = false;
            }
        }
        
        #endregion
        
        #region XRHandSubsystem Helpers
        
        /// <summary>
        /// Attempts to find and assign the XRHandSubsystem from the active XR loader.
        /// </summary>
        protected void InitializeXRHandSubsystem()
        {
            _handSubsystem = XRGeneralSettings.Instance.Manager.activeLoader?.GetLoadedSubsystem<XRHandSubsystem>();
            if (_handSubsystem == null)
                Debug.LogWarning("XRHandSubsystem not found.");
        }

        /// <summary>
        /// Attempts to retrieve the currently tracked XRHand based on the selected handedness.
        /// </summary>
        /// <returns>The left or right XRHand.</returns>
        protected bool TryGetTrackedHand(out XRHand hand)
        {
            if (handedness == InteractorHandedness.Left)
            {
                hand = _handSubsystem.leftHand;
                return hand.isTracked;
            }
            else if (handedness == InteractorHandedness.Right)
            {
                hand = _handSubsystem.rightHand;
                return hand.isTracked;
            }

            hand = default;
            return false;
        }
        
        /// <summary>
        /// Attempts to retrieve the poses of the index fingertip and thumb fingertip joints.
        /// </summary>
        /// <param name="hand">The XRHand to query.</param>
        /// <param name="indexPose">Output pose of the index fingertip.</param>
        /// <param name="thumbPose">Output pose of the thumb fingertip.</param>
        /// <returns>True if both joint poses were successfully retrieved; otherwise false.</returns>
        protected bool TryGetJointPoses(XRHand hand, out Pose indexPose, out Pose thumbPose)
        {
            indexPose = default;
            thumbPose = default;

            if (!hand.isTracked)
                return false;
            
            var indexTip = hand.GetJoint(_indexTipJoint);
            var thumbTip = hand.GetJoint(_thumbTipJoint);

            bool indexOk = indexTip.TryGetPose(out indexPose);
            bool thumbOk = thumbTip.TryGetPose(out thumbPose);

            return indexOk && thumbOk;
        }
        
        #endregion
        
        #region XRBaseInteractor Hooks
        
        /// <summary>
        /// Compute candidates by overlapping a sphere at the pinch/attach point.
        /// Filter by XRI interface gating and (optionally) the targetFilter.
        /// Sorted closest-first so arbitration is stable and intuitive.
        /// </summary>
        public override void GetValidTargets(List<IXRInteractable> targets)
        {
            targets.Clear();
            
            if (!isActiveAndEnabled || interactionManager == null)
                return;

            var attach = GetAttachTransform(null);
            var center = attach ? attach.position : transform.position;

            int hitCount = Physics.OverlapSphereNonAlloc(
                center, _detectionRadius, _overlapHits, _physicsLayerMask, _physicsTriggerInteraction);

            _scratchTargets.Clear();
            
            for (int i = 0; i < hitCount; i++)
            {
                var col = _overlapHits[i];
                if (col == null) continue;

                if (!interactionManager.TryGetInteractableForCollider(col, out var ixr))
                    continue;

                // Gate via interfaces
                bool hoverable = false;
                bool selectable = false;

                if (this is IXRHoverInteractor hov && ixr is IXRHoverInteractable hx)
                    hoverable = hx.IsHoverableBy(hov);

                if (this is IXRSelectInteractor sel && ixr is IXRSelectInteractable sx)
                    selectable = sx.IsSelectableBy(sel);

                if (!hoverable && !selectable)
                    continue;

                if (!_scratchTargets.Contains(ixr))
                    _scratchTargets.Add(ixr);
            }

            // Sort by distance to attach point
            _scratchTargets.Sort((a, b) =>
            {
                var ta = (a as Component)?.transform;
                var tb = (b as Component)?.transform;
                if (!ta || !tb) return 0;
                float da = (ta.position - center).sqrMagnitude;
                float db = (tb.position - center).sqrMagnitude;
                return da.CompareTo(db);
            });
            
            // Optional target filter
            if (targetFilter != null && targetFilter.canProcess && _scratchTargets.Count > 0)
            {
                // use a simple temp list instead of internal ListPool
                _filteredBuffer.Clear();
                targetFilter.Process(this, _scratchTargets, _filteredBuffer);
                targets.AddRange(_filteredBuffer);
            }
            else
            {
                targets.AddRange(_scratchTargets);
            }
        }
        
        #endregion
        
        #region Pinch State
        
        /// <summary>
        /// Assesses if the distance between index fingertip and thumb fingertip is below the pinch threshold.
        /// </summary>
        /// <param name="indexPose">The pose of the index fingertip joint.</param>
        /// <param name="thumbPose">The pose of the thumb fingertip joint.</param>
        protected void AssessPinch(Pose indexPose, Pose thumbPose)
        {
            bool wasPinching = _isPinching;
            float pinchDistance = Vector3.Distance(indexPose.position, thumbPose.position);
            _isPinching = pinchDistance < _pinchThreshold;

            if (!wasPinching && _isPinching)
            {
                if (_isGrabbing || _selectedInteractable != null || interactionManager == null)
                    return;
                
                // Get the short list of valid targets from the interaction manager
                _filteredBuffer.Clear();
                GetValidTargets(_filteredBuffer);
                
                // Pick nearest interactable
                IXRSelectInteractable target = null;
                if (this is IXRSelectInteractor sel)
                {
                    for (int i = 0; i < _filteredBuffer.Count; i++)
                    {
                        if (_filteredBuffer[i] is IXRSelectInteractable s && s.IsSelectableBy(sel))
                        {
                            target = s;
                            break;
                        }
                    }
                }
                
                if (target == null)
                    return;

                // Grab or select it
                if (target is XRGrabInteractable grab)
                {
                    interactionManager.SelectEnter(this, target);
                    _grabbedInteractable = grab;
                    _isGrabbing = true;
                }
                else
                {
                    interactionManager.SelectEnter(this, target);
                    _selectedInteractable = target;
                }

            }
            else if (wasPinching && !_isPinching)
            {
                // Release or exit from it
                if (_isGrabbing)
                {
                    ReleaseGrab();
                }
                else if (_selectedInteractable != null)
                {
                    interactionManager?.SelectExit(this, _selectedInteractable);
                    _selectedInteractable = null;
                }
            }
        }
        
        /// <summary>
        /// Release the XR Grab Interactable.
        /// </summary>
        protected virtual void ReleaseGrab()
        {
            if (_grabbedInteractable == null)
                return;

            interactionManager?.SelectExit(this, (IXRSelectInteractable)_grabbedInteractable);
            _grabbedInteractable = null;
            _isGrabbing = false;
        }
        
        #endregion
    }
}
# MeshMap XR Changelog

## [0.1.0-exp.2] - 2025-09-29
### Add License Information
- Added Apache 2.0 License and third-party disclosures.
- Fixed namespace of Marker Tracking sample to be `MeshMap.XR.Samples.MarkerTracking`.

## [0.1.0-exp.1] - 2025-09-17
### SpatialButton, XRPinchInteractor refactor, and SemVer adjustment
- Added `SpatialButton` to create XR-native 3D menu buttons with events.
- Refactored `XRPinchInteractor` to follow the `IXRSelectInteractor` conventions.
- Updated dependency on Building Blocks package to be conditional. For example, see `XRPokeInteractorSound`.
- Switched to using the "Experimental" version tag to clearly communicate that some of the features in this package are unstable and subject to change. 

## [0.0.12] - 2025-09-07
### CustomHandTracker
- Added `CustomHandTracker` for switching between Input System-based `TrackedPoseDriver` or old version depending on platform.

## [0.0.11] - 2025-08-22
### XRPokeInteractorSound
- Added MeshMap.BuildingBlocks dependency for this audio-reactive poke example.
- (Should likely be moved to BuildingBlocks directly).

### XRPinchInteractor for Building Blocks / SpatialButton
- Major refactor of XRPinchInteractor to include full XRGrabInteractable support with cross-platform compatibility.
- Added grab/release functionality with automatic closest-object selection and collision-based interaction detection.
- Added comprehensive state management for pinching, grabbing, and hovered interactables.
- Includes virtual methods for extensibility while maintaining project-agnostic design.

### Custom Rotation Axis Lock Grab Transformer
- Added `CustomRotationAxisLockGrabTransformer` (from XRI Toolkit 3.0.8 - 'Starter Assets' Sample).
- Provides public `InitialEulerRotation` property for external rotation cache management.
- Supports world-space axis locking in global coordinates for all objects using the transformer.

### Simple Marker Tracking Controls
- Created `SimpleMarkerTrackingControls` with improved event timing for external system integration.

### Namespace Refactor
- Swapped MeshMapLabs for MeshMap to adhere with global naming conventions.
- Affects CustomHandMenu & UPMWrapper.

## [0.0.10] - 2025-08-16
### ToggleMarkerVisuals
- Fixed marker tracker settings that had gotten overridden.
- Updated ToggleMarkerVisuals.cs

## [0.0.9] - 2025-08-15
### Hand Menu and XR Input Modality
- Removed manual SDK wrapper menu items in `MeshMap > Tools > UPM Wrapper`.
- Added a checkable toggle `Show Wrapping Info Logs` to hide info-level wrapping logs.
- NOTE: Default behavior is to keep info logs hidden until enabled.
- Introduced `CustomXRInputModalityManager` for cross-platform hand/controller switching.
- Updated Marker Tracking sample scenes and prefabs with Hand Menu and minor assignment fixes.

## [0.0.8] - 2025-08-15
### Marker Tracking sample assignment fix
- Fixed the backwards marker content and marker anchor assignments.

## [0.0.7] - 2025-08-15
### MQ3 marker tracking and UPM wrapper options
- Added time checks to adjust when to allow big shifts in marker pose when tracking on MQ3.
- Updated the toolbar options for UPM wrapper to allow toggling the automation.

## [0.0.6] - 2025-08-14
### Platform-based interactors and build setup
- XRPinchInteractor now configures per platform at runtime (via scripting defines):
  - Magic Leap: disables `TrackedPoseDriver` and ignores tracked pose driver usage.
  - Meta Quest: sets `attachTransform` local euler rotation to `(-20, 0, 15)`.
  - XREAL: sets `attachTransform` local euler rotation to `(45, 0, -45)`.
- XRPokeInteractorDriver:
  - Enabled only for Magic Leap and disables `TrackedPoseDriver` on the same GameObject.
  - Disabled for Meta Quest and XREAL (those use `TrackedPoseDriver`).
- Android manifest selection updated:
  - Build preprocessor now applies one of `AndroidManifest_MagicLeap.xml`, `AndroidManifest_MetaQuest.xml`, or `AndroidManifest_XREAL.xml` from the package `Resources/Manifests` based on the active scripting define.

## [0.0.5] - 2025-08-14
### MQ3 marker tracking
- Fixed `MQMarkerService`.
- Added `MarkerTrackingLifetimeScope` to `MarkerTracker`.prefab.

## [0.0.4] - 2025-08-12
### Documentation
- Updated README core feature list and added XML summaries.
- Fixed typo in Magic Leap input actions resource reference.
- Renamed Crossplatform namespace to Rigs.
- Added VContainer, OpenXR, and CompositionLayers to package.json.

## [0.0.3] - 2025-08-12
### Cross-platform rig, inputs, and scene 
- Added a cross-platform rig and input actions.
- Created cross-platform sample scene for marker tracking.

## [0.0.2] - 2025-08-11
### Package management and marker tracking
- Updated references to `com.magicleap.unitysdk`.
- Added support classes for XRPokeInteractor.
- Added AprilTag marker tracking and sample scenes for ML2 and MQ3.
- Updated SDK wrapper tool to run automatically when Unity Editor compiles.

## [0.0.1] - 2025-08-09
### Package Setup
- Initial setup of the package with interactors and SDK wrapper tool.
# MeshMap XR

> [!IMPORTANT]
> This package uses a minimally modified version of the Magic Leap SDK to prevent compilation errors when building for multiple target XR devices. In accordance with the [Magic Leap 2 Software License Agreement](https://www.magicleap.com/legal/software-license-agreement-ml2), the package is included in our [ML2 Samples project](https://github.com/MeshMap/mmsdk-samples-magicleap2), but not redistributed solely on its own.
> 
> This package also uses a minimally modified version of jp.keijiro.apriltag which includes the 36h11 tag family. It is licensed under the BSD 2-Clause License.

Current version: 0.1.0-exp.2

Last updated: 29 September 2025

[Changelog](https://github.com/MeshMap/com.meshmap.sdk.xr/blob/main/CHANGELOG.md)

[Documentation](https://docs.meshmap.com/unity-sdk/xr)

---

## Description

The MeshMap XR package contains sample assets for creating cross-device XR apps in Unity 6.

The goal is to provide Unity developers of all skill levels with tools that simplify and accelerate their workflow from weeks to minutes.

---

## Features

- Cross-device XR rigs and input actions.
- Target device build profiles and UPM wrapper editor tool.
- Localize AR content using markers (AprilTags, ArUco markers, and QR codes).
- Calibrate localized content using a simple UI tool.

---

## Requirements

- **Unity 6000.0.50f1 LTS** or later
- Android Build Support
- Universal Render Pipeline (URP)

---

## Package Dependencies

- VContainer `jp.hadashikick.vcontainer v1.16.8`
- Unity XR Plugin Management `com.unity.xr.management v4.5.1`
- Unity XR Interaction Toolkit `com.unity.xr.interaction.toolkit v3.0.8`
- Unity XR Hands `com.unity.xr.hands v1.5.1`
- Unity OpenXR Plugin `com.unity.xr.openxr v1.15.0`
- Unity XR Composition Layers `com.unity.xr.compositionlayers v2.0.0`
- Unity Meta OpenXR `com.unity.xr.meta-openxr v2.2.0`
- Unity Meta XR `com.meta.xr.sdk.core v74.0.0`
- Unity Meta MR Utility Kit `com.meta.xr.mrutilitykit v74.0.0`
- Magic Leap Unity SDK `com.magicleap.unity v2.6.0-pre.R15-meshmap`
- XREAL Unity SDK `com.xreal.xr v3.0.0`
- Keijiro AprilTag `jp.keijiro.apriltag.meshmap v1.0.2-meshmap`

---

## Getting Started

*Requires Unity 6000.0.50f1 or higher with Android Build Support module. This can be installed via [Unity Hub](https://unity.com/unity-hub).*

### For beginners (easiest, read-only)

1. Download the [Location-based AR](https://github.com/MeshMap/LocationBasedARSample) sample Unity project which already includes the necessary settings, dependencies, and sample scenes.
2. Open the project in Unity Editor.

### For existing projects (read-only)

1. Open your project in Unity Editor.
2. Import the Starter Assets and Hand Interactions Demo samples from Unity XR Interaction Toolkit v3.0.8, and Hand Visualizer sample from Unity XR Hands v1.5.1.
3. In the `Packages/manifest.json` file, add the `openupm` scoped registry for `vcontainer`. Alternatively, you can do this in the Editor by going to Edit > Project Settings > Package Manager > Scoped Registries and adding the information below.

   ```json
   "scopedRegistries": [
      {
         "name": "package.openupm.com",
         "url": "https://package.openupm.com",
         "scopes": [
            "jp.hadashikick.vcontainer"
         ]
      }
   ],
   ```
4. Go to Window > Package Manager > *(click the + dropdown icon in the top-left of the Package Manager window)* > Add Package from git URL...
5. Copy and paste `https://github.com/MeshMap/com.meshmap.sdk.xr.git`, then click Add.
   - If you want to import a specific version, include the release number. For example, `https://github.com/MeshMap/com.meshmap.sdk.xr.git#v0.0.1`
   - If your import permission is denied because you are using Mac, try using this path instead `git@github.com:MeshMap/com.meshmap.sdk.xr.git#v0.0.1`
   - If your import permission is denied because this is a private repo, then add an [SSH key to your GitHub account](https://docs.github.com/en/authentication/connecting-to-github-with-ssh/adding-a-new-ssh-key-to-your-github-account).

### For contributors (read and write)

1. Follow steps 1 through 3 above.
2. Clone this repository to your computer and create a new local branch.
3. In the `Packages/manifest.json` file, add a dependency reference to the cloned repository.<br>By adding it in this way rather than via git URL, Unity will treat the SDK as an editable part of the project even though it's located outside the project folder. You can repeat this step across all your projects using the SDK and the edits will always sync properly. This eliminates the chance of any potential code conflicts that may arise if you also use git version control for your Unity projects.

   ```json
   {
      "dependencies": {
         "com.meshmap.sdk.xr": "file:/path/to/com.meshmap.sdk.xr/"
      }
   }
   ```

---

## Basic Usage

After import, the files should be available in the `Packages` section of the `Project` window in Unity Editor.

Editor windows and tools can be accessed under the `MeshMap` section of the toolbar at the top of the Unity Editor.

For contributors, rename the `Samples~` folder to `Samples` **before** making changes to the Samples assets. You may need to delete the samples from your `Assets` folder if they are already imported. Then, add the `~` back in and reimport the samples before committing changes to the main branch. This ensures that contributions are properly synced in the package and GUIDs are not mismatched.

*Note: The files will not work outside the `Packages` section due to dependencies and assembly definitions that are specific to the Editor and Runtime, so be sure to import them correctly using one of the processes described above.*

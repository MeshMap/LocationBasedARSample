# MeshMap AprilTag Changelog

## [1.0.2-meshmap.2] - 2025-09-28
### License Info
- Tweaked documentation to make following licensing information easier.

## [1.0.2-meshmap] - 2025-08-09
### More AprilTag Families
- Added support for 36h11.

Original Unity repository: [GitHub Repository Link](https://github.com/keijiro/jp.keijiro.apriltag)
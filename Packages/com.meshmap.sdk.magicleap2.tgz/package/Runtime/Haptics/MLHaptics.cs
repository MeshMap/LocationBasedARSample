// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;
using UnityEngine.XR.MagicLeap;

namespace MeshMap.MagicLeap2
{
    /// <summary>
    /// Haptics for Magic Leap 2 using native extensions and OpenXR.
    /// </summary>
    public static class MLHaptics
    {
        /// <summary>
        /// Predefined haptic Type A from the Magic Leap 2 extension.
        /// </summary>
        public static void PlayVKBHover()
        {
            InputSubsystem.Extensions.Haptics.StartPreDefined(InputSubsystem.Extensions.Haptics.PreDefined.Type.A);
        }

        /// <summary>
        /// Predefined haptic Type B from the Magic Leap 2 extension.
        /// </summary>
        public static void PlayVKBSelect()
        {
            InputSubsystem.Extensions.Haptics.StartPreDefined(InputSubsystem.Extensions.Haptics.PreDefined.Type.B);
        }

        /// <summary>
        /// Predefined haptic Type C from the Magic Leap 2 extension.
        /// </summary>
        public static void PlayHomeMenuHover()
        {
            InputSubsystem.Extensions.Haptics.StartPreDefined(InputSubsystem.Extensions.Haptics.PreDefined.Type.C);
        }
        
        /// <summary>
        /// Sends a custom haptic impulse to the first valid controller using Unity OpenXR.
        /// </summary>
        /// <param name="amplitude">Intensity between 0 and 1.0.</param>
        /// <param name="duration">Duration of the pulse in seconds.</param>
        public static void SendHaptic(float amplitude, float duration)
        {
            if (TryGetController(out InputDevice device))
            {
                // channel 0 is standard for XR haptics
                device.SendHapticImpulse(0, Mathf.Clamp01(amplitude), duration);
            }
        }
        
        /// <summary>
        /// Finds the first valid controller (right or left hand) and returns it.
        /// </summary>
        private static bool TryGetController(out InputDevice device)
        {
            var devices = new List<InputDevice>();
            InputDevices.GetDevicesWithCharacteristics(InputDeviceCharacteristics.HeldInHand | InputDeviceCharacteristics.Controller, devices);

            foreach (var d in devices)
            {
                if (d.isValid && d.TryGetHapticCapabilities(out HapticCapabilities capabilities) && capabilities.supportsImpulse)
                {
                    device = d;
                    return true;
                }
            }

            device = default;
            return false;
        }
    }
}
#endif
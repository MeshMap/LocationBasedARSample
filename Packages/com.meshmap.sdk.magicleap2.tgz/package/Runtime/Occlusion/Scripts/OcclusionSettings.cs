// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using System;
using UnityEngine;
using UnityEngine.UI;

namespace MeshMap.MagicLeap2
{
    /// <summary>
    /// Controls settings for occlusion via UI.
    /// </summary>
    public class OcclusionSettings : MonoBehaviour
    {
        public static event Action<bool> OnOcclusionToggled;
        
        [SerializeField] private Toggle _occlusionToggle;
        
        private void Awake()
        {
            _occlusionToggle.onValueChanged.AddListener(ToggleOcclusion);
        }

        private void OnDestroy()
        {
            _occlusionToggle.onValueChanged.RemoveListener(ToggleOcclusion);
        }

        public bool OcclusionToggleStatus()
        {
            return _occlusionToggle.isOn;
        }
        
        private void ToggleOcclusion(bool status)
        {
            _occlusionToggle.isOn = status;
            OnOcclusionToggled?.Invoke(status);
        }
    }
}
#endif
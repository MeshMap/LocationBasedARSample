// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using UnityEngine;

namespace MeshMap.MagicLeap2
{
    /// <summary>
    /// Caches an array of GameObjects with an occlusion material that should be toggled by <see cref="OcclusionSettings"/>.
    /// </summary>
    public class OcclusionMesh : MonoBehaviour
    {
        [SerializeField] private GameObject[] _occlusionMeshes;
        [SerializeField] private string _occlusionSettingsTag = "OcclusionSettings";
        private OcclusionSettings _settings;
        
        private void Awake()
        {
            OcclusionSettings.OnOcclusionToggled += ToggleOcclusion;
        }

        private void Start()
        {
            _settings = GameObject.FindGameObjectWithTag(_occlusionSettingsTag).GetComponent<OcclusionSettings>();
            ToggleOcclusion(_settings.OcclusionToggleStatus());
        }

        private void OnDestroy()
        {
            OcclusionSettings.OnOcclusionToggled -= ToggleOcclusion;
        }

        private void ToggleOcclusion(bool status)
        {
            foreach (var occlusionMesh in _occlusionMeshes)
            {
                occlusionMesh.SetActive(status);
            }
        }
    }
}
#endif
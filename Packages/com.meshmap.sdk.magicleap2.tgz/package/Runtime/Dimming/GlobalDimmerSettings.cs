// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using TMPro;
using UnityEngine.XR.OpenXR;
using MagicLeap.OpenXR.Features;

namespace MeshMap.MagicLeap2
{
    /// <summary>
    /// Controls settings for the Magic Leap 2 Global Dimmer via UI and XR inputs.
    /// </summary>
    public class GlobalDimmerSettings : MonoBehaviour
    {
        [SerializeField] private Slider _slider;
        [SerializeField] private TextMeshProUGUI _sliderText;
        
        [SerializeField, Tooltip("Set the Global Dimmer to the default value on app start.")]
        private bool _useDefaultValue = false;
        
        [SerializeField, Range(0f, 1f)]
        private float _defaultValue = 0.5f;
        
        [SerializeField] private string _format = "P0";

        [SerializeField, Tooltip("Optional XR interaction to toggle Global Dimming on/off.")]
        private InputActionProperty _toggleGlobalDimmer;
        
        private MagicLeapRenderingExtensionsFeature _renderFeature;

        private void Start()
        {
            InitializeGlobalDimmer();
            InitializeUI();
            InitializeInputs();
        }

        private void OnDestroy()
        {
            if (_renderFeature != null)
            {
                _renderFeature.GlobalDimmerEnabled = false;
            }

            if (_slider != null && _sliderText != null)
            {
                _slider.onValueChanged.RemoveListener(SetGlobalDimmerValue);
            }
            
            if (_toggleGlobalDimmer.action != null)
            {
                _toggleGlobalDimmer.action.performed -= ToggleGlobalDimmerInput;
            }
        }

        private void InitializeGlobalDimmer()
        {
            if (!OpenXRRuntime.IsExtensionEnabled("XR_ML_global_dimmer"))
            {
                Debug.LogError($"The OpenXR Feature \"Magic Leap 2 Rendering Extensions\" must be enabled in Project Settings.");
                enabled = false;
                return;
            }
            
            _renderFeature = OpenXRSettings.Instance.GetFeature<MagicLeapRenderingExtensionsFeature>();
            _renderFeature.GlobalDimmerEnabled = true;
        }

        private void InitializeUI()
        {
            if (_slider == null || _sliderText == null)
            {
                Debug.LogError("A UI element has not been assigned.");
                return;
            }
            
            // Add listeners
            _slider.onValueChanged.AddListener(SetGlobalDimmerValue);
            
            // Set the start value of the slider
            if (_useDefaultValue)
            {
                _slider.value = _defaultValue;
            }
            else
            {
                _slider.value = _renderFeature.GlobalDimmerValue;
            }
            SetGlobalDimmerValue(_slider.value);
        }

        private void InitializeInputs()
        {
            if (_toggleGlobalDimmer.action != null)
            {
                _toggleGlobalDimmer.action.performed += ToggleGlobalDimmerInput;
            }
        }

        private void ToggleGlobalDimmerInput(InputAction.CallbackContext context)
        {
            ToggleGlobalDimmer();
        }
        
        /// <summary>
        /// Toggle the Magic Leap Global Dimming feature on and off.
        /// </summary>
        public void ToggleGlobalDimmer()
        {
            _renderFeature.GlobalDimmerEnabled = !_renderFeature.GlobalDimmerEnabled;
        }
        
        /// <summary>
        /// Set the value of the Magic Leap Global Dimming setting and update the UI slider text.
        /// </summary>
        /// <param name="value">Global Dimming value between 0.0 and 1.0.</param>
        public void SetGlobalDimmerValue(float value)
        {
            _renderFeature.GlobalDimmerValue = value;
            _sliderText.text = value.ToString(_format);
        }
    }
}
#endif
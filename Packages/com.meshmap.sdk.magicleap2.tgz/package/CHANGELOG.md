# MeshMap Magic Leap 2 Support Changelog

## [0.2.0-pre.2] - 2025-09-24
###  Added Apache 2.0 License
- Included license information for the package and its dependencies.

## [0.2.0-pre.1] - 2025-09-17
###  Pre-release SemVer Tag
- Switched to using pre-release tag to better communicate the changing nature of this package.

## [0.1.3] - 2025-08-10
###  Fixed asmdef constraints
- Replaced version constraints with define constraint in .asmdef files because they conflicted with `mmsdk-xr-upm MeshMap.XR.Editor.UPMWrapper`.

## [0.1.2] - 2025-08-10
###  Update package dependencies
- Reverted name of Magic Leap Unity SDK dependency to `com.magicleap.unitysdk` because it was causing too many avoidable UPM and settings errors.

## [0.1.1] - 2025-08-09
###  Reorganized packages
- Organized runtime assets by feature.
- Moved `ToggleMenu` to `MeshMap.BuildingBlocks.UI`.
- Update package.json to properly include all package dependencies.

## [0.1.0] - 2025-08-08
###  Using custom version of Magic Leap Unity SDK
- Switched to using [com.magicleap.unitysdk.meshmap `(v2.6.0-pre.R15-meshmap)`](https://github.com/MeshMap/com.magicleap.unitysdk.meshmap) to prevent compilation errors with Open XR 1.15.0 (which is a dependency of Unity OpenXR Meta) when building for multiple devices.

## [0.0.18] - 2025-06-25
###  Added MAGICLEAP scripting define
- Wrapped all C# classes with #if MAGICLEAP #endif. This supports using multiple device SDKs in the same Unity 6 project with build profiles.

## [0.0.17] - 2025-06-18
###  Fixed TMPro dependency
- Added TextMeshPro to the package dependencies.

## [0.0.16] - 2025-06-17
###  Added occlusion shaders and materials, and XML documentation
- Cloned URP shaders for Lit, Particles, Sprite Unlit, and TMP SDF Mobile, and created occlusion-compatible shaders and materials. Includes copies for ZTest Always and for LEqual.
- Added complete XML documentation for all samples.

## [0.0.15] - 2025-04-22
###  Upgraded EyeTracking Sample
- Added a simple EyeGaze sample that demonstrates how to visualize eye gaze and detect raycast hits using Eye Gaze direction with the OpenXR Eye Gaze Interaction Profile.

## [0.0.14] - 2025-04-19
###  EyeTracking Sample
- Added a simple EyeTracking sample that demonstrates how to get data from the Magic Leap 2 Eye Tracker Feature.

## [0.0.13] - 2025-04-18
###  More Naming Conventions
- Updated any incorrect variable names to follow Unity C# conventions.

## [0.0.12] - 2025-04-18
### Update to mmsdk-buildingblocks-upm v0.0.6 and Naming Conventions
- Updated LocalizeSpaceTriggerEvent.
- Updated any incorrect variable names to follow Unity C# conventions.

## [0.0.11] - 2025-04-17
### Reticle
- Added reticle assets.

## [0.0.10] - 2025-04-10
### LocalizeSpaceEvent and Spatial Anchors
- Added the LocalizeSpaceEvent which is a completable event using the MeshMap Building Blocks package.
- Added the Spatial Anchors sample which uses the Magic Leap 2 Spatial Anchor Subsystem.

## [0.0.9] - 2025-04-05
### Voice Commands
- Added the Voice Commands sample which uses ML Voice Intents to listen for keywords and execute commands.

## [0.0.8] - 2025-04-04
### Global Dimming and User Calibration
- Added GlobalDimming.cs to adjust dimming from inside the application.
- Added the User Calibration sample which uses the experimental Magic Leap 2 User Calibration Feature.

## [0.0.7] - 2025-04-02
### Physical Occlusion
- Added the Physical Occlusion sample which uses the experimental Magic Leap 2 Physical Occlusion Feature.

## [0.0.6] - 2025-04-01
### Simplify Marker Localization
- Simplified the Marker Tracking sample and made it compatible with space localization.
- Added a configurable wait to the manual option in the Space Localization sample.
- Added a miniature Calibration Tutorial prefab and scene to the Marker Tracking sample.

## [0.0.5] - 2025-03-29
### Localize using ML Spaces
- Added the Space Localization sample which uses the MLSpaces API to localize pre-designed content.

## [0.0.4] - 2025-03-12
### Hide M:1 Content Before Localization
- Added toggle to optionally hide M:1 content before any corresponding marker has been localized.
- 
## [0.0.3] - 2025-03-09
### Fixed Duplicate Rig Assets
- Removed duplicate ML Rig assets from the Samples~ folder.

## [0.0.2] - 2025-03-09
### Added M:1 Localization Support
- Further developed the Marker Tracking sample to include support for Many to One (M:1) localization. Multiple markers can correspond to the same AR content, and preserve their relative position and rotation in Unity coordinate system.

## [0.0.1] - 2025-03-07
### Initial Release
- Initial release of the package with basic functionality, including AR marker localization and calibration.
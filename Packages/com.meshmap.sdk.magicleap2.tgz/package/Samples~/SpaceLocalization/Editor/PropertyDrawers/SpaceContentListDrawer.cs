#if MAGICLEAP
using UnityEditor;
using UnityEngine;

namespace MeshMap.MagicLeap2.Samples.SpaceLocalization
{
    [CustomPropertyDrawer(typeof(SpaceContent))]
    public class SpaceContentListDrawer : PropertyDrawer
    {
        private string _space = "Space";
        private string _contentField = "Content";

        private float _padding = 5f;
        private float _spaceWidth = 150f;
        private float _contentFieldWidth = 250f;
        
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            SerializedProperty spaceProp = property.FindPropertyRelative(_space);
            SerializedProperty contentProp = property.FindPropertyRelative(_contentField);

            Rect markerIDRect = new Rect(position.x, position.y, _spaceWidth, position.height);
            Rect contentRect = new Rect(position.x + _spaceWidth + _padding, position.y, _contentFieldWidth, position.height);

            EditorGUI.PropertyField(markerIDRect, spaceProp, GUIContent.none);
            EditorGUI.PropertyField(contentRect, contentProp, GUIContent.none);
        }

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            // The height is the same for each row
            return EditorGUIUtility.singleLineHeight;
        }
    }
}
#endif
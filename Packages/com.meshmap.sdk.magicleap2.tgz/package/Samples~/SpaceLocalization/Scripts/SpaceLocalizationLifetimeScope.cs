// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using VContainer;
using VContainer.Unity;

namespace MeshMap.MagicLeap2.Samples.SpaceLocalization
{
    /// <summary>
    /// Configures the dependency injection container for Space localization components.
    /// Registers relevant components found in the scene hierarchy for injection.
    /// </summary>
    public class SpaceLocalizationLifetimeScope : LifetimeScope
    {
        /// <summary>
        /// Registers Space localization related components with the dependency injection container.
        /// </summary>
        /// <param name="builder">The container builder used to register components.</param>
        protected override void Configure(IContainerBuilder builder)
        {
            builder.RegisterComponentInHierarchy<SpaceManagerUI>();
            builder.RegisterComponentInHierarchy<SpaceManager>();
        }

        private void Start()
        {
            // Inject all instances of LocalizeSpaceEvent in the active scene.
            var localizeSpaceEvents = FindObjectsOfType<LocalizeSpaceTriggerEvent>();
            foreach (var localizeSpaceEvent in localizeSpaceEvents)
            {
                Container.Inject(localizeSpaceEvent);
            }
        }
    }
}
#endif
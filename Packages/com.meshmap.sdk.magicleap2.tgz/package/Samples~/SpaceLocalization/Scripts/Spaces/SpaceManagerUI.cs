// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace MeshMap.MagicLeap2.Samples.SpaceLocalization
{
    /// <summary>
    /// Handles UI updates and interactions for Magic Leap Space localization.
    /// Manages status text, countdown timer, dropdown space selection, and start/stop button visibility.
    /// </summary>
    public class SpaceManagerUI : MonoBehaviour
    {
        [SerializeField, Tooltip("TMP text showing the current localization status.")]
        private TextMeshProUGUI _statusText;

        [SerializeField, Tooltip("TMP text showing the countdown time.")]
        private TextMeshProUGUI _countdownText;
        
        [SerializeField, Tooltip("UI dropdown for setting the currently selected space.")]
        private TMP_Dropdown _spacesDropdown;

        public Button StartButton;
        public Button StopButton;

        private void Start()
        {
            _spacesDropdown.ClearOptions();
        }
        
        /// <summary>
        /// Updates the status display text on the UI.
        /// </summary>
        /// <param name="text">The new status message to display.</param>
        public void UpdateStatusText(string text)
        {
            _statusText.text = text;
        }

        /// <summary>
        /// Updates the countdown timer text on the UI.
        /// </summary>
        /// <param name="text">The new countdown value to display.</param>
        public void UpdateCountdownText(string text)
        {
            _countdownText.text = text;
        }

        /// <summary>
        /// Populates the dropdown with a list of Magic Leap Space names and refreshes the view.
        /// </summary>
        /// <param name="names">The list of Space names to add.</param>
        public void AddSpaceOptions(List<string> names)
        {
            _spacesDropdown.AddOptions(names);
            _spacesDropdown.RefreshShownValue();
            _spacesDropdown.Hide();
        }

        /// <summary>
        /// Gets the name of the currently selected Magic Leap Space in the dropdown.
        /// </summary>
        /// <returns>The selected Space name.</returns>
        public string GetSelectedSpace()
        {
            return _spacesDropdown.options[_spacesDropdown.value].text;
        }

        /// <summary>
        /// Sets the dropdown to select a specific Magic Leap Space if it exists in the options.
        /// </summary>
        /// <param name="space">The name of the Space to select.</param>
        public void SetSelectedSpace(string space)
        {
            int index = _spacesDropdown.options.FindIndex(optionData => optionData.text == space);
            if (index != -1)
            {
                _spacesDropdown.value = index;
            }
        }

        /// <summary>
        /// Displays the Start button and hides the Stop button.
        /// </summary>
        public void ShowStartButton()
        {
            StopButton.gameObject.SetActive(false);
            StartButton.gameObject.SetActive(true);
        }

        /// <summary>
        /// Hides the Start button and shows the Stop button.
        /// </summary>
        public void HideStartButton()
        {
            StartButton.gameObject.SetActive(false);
            StopButton.gameObject.SetActive(true);
        }
    }
}
#endif
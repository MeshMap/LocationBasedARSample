// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.XR.OpenXR;
using UnityEngine.XR.OpenXR.NativeTypes;
using MagicLeap.OpenXR.Features.LocalizationMaps;
using VContainer;

namespace MeshMap.MagicLeap2.Samples.SpaceLocalization
{
    /// <summary>
    /// Manages localization and content placement using Magic Leap Spaces and the Magic Leap Localization Map feature.
    /// </summary>
    public class SpaceManager : MonoBehaviour
    {
        public static event Action<GameObject> OnLocalizationCompleted;
        
        /// <summary>
        /// List of space-content pairs to manage.
        /// </summary>
        public List<SpaceContent> SpaceContentList;
        private Dictionary<string, GameObject> SpaceContentDict = new();

        [Header("Content Settings")]
        [SerializeField, Tooltip("Disable content until the corresponding Space has been localized.")] private bool _hideContentUntilLocalizedOnce = true;
        
        [Header("Localization Settings")]
        [SerializeField, Tooltip("Continuously check for localization map updates.")] private bool _continuousLocalization = false;
        [SerializeField, Tooltip("Show all local Magic Leap spaces or only the spaces used by this app.")] private bool _showAllLocalSpacesInDropdown = false;
        [SerializeField, Tooltip("Show localization map origin position and rotation.")] private bool _showOriginDataInMenu = false;
        
        private MagicLeapLocalizationMapFeature _localizationMapFeature;
        private LocalizationMap[] _maps;
        private LocalizationMap _currentMap;
        private Pose _currentMapOrigin;

        [SerializeField, Range(3, 30), Tooltip("How long to attempt manual space localization.")] private int _manualLocalizationTimeLimitSecs = 30;
        private bool _isManuallyLocalizing = false;
        
        [Inject] private SpaceManagerUI _spaceManagerUI;

        private void Start()
        {
            PopulateDicts();

            if (_hideContentUntilLocalizedOnce)
            {
                HideContent();
            }
            
            InitializeLocalizationMapFeature();

            // Subscribe to button events
            _spaceManagerUI.StartButton.onClick.AddListener(OnStartButtonClicked);
            _spaceManagerUI.StopButton.onClick.AddListener(CancelLocalization);
        }
        
        private void OnDestroy()
        {
            // Unsubscribe from events
            _spaceManagerUI.StartButton.onClick.RemoveListener(OnStartButtonClicked);
            _spaceManagerUI.StopButton.onClick.RemoveListener(CancelLocalization);
            
            if (_localizationMapFeature == null || !_localizationMapFeature.enabled || !_continuousLocalization)
            {
                return;
            }
            MagicLeapLocalizationMapFeature.OnLocalizationChangedEvent -= CheckLocalizationState;
        }

        /// <summary>
        /// Populates internal dictionary from the SpaceContentList for quick lookup.
        /// </summary>
        private void PopulateDicts()
        {
            SpaceContentDict.Clear();
            foreach (var pair in SpaceContentList)
            {
                SpaceContentDict[pair.Space] = pair.Content;
            }
        }

        /// <summary>
        /// Deactivates all content GameObjects managed by this component.
        /// </summary>
        private void HideContent()
        {
            var uniqueContent = SpaceContentDict.Values.Distinct().ToList();
            foreach (var content in uniqueContent)
            {
                content.SetActive(false);
            }
        }
        
        /// <summary>
        /// Initializes the Magic Leap Localization Map feature and sets up event subscriptions.
        /// </summary>
        private void InitializeLocalizationMapFeature()
        {
            // Get the Magic Leap Localization Map Feature and make it accessible
            _localizationMapFeature = OpenXRSettings.Instance.GetFeature<MagicLeapLocalizationMapFeature>();
            if (_localizationMapFeature == null || !_localizationMapFeature.enabled)
            {
                _spaceManagerUI.UpdateStatusText("Magic Leap Localization Map feature does not exist or is not enabled.");
                return;
            }
            
            // Update the list of maps
            UpdateListOfAvailableSpaces();

            // Enable the localization events
            XrResult result = _localizationMapFeature.EnableLocalizationEvents(true);
            if (result != XrResult.Success)
            {
                _spaceManagerUI.UpdateStatusText("Failed to enable localization events.");
            }

            // If continuous, subscribe to localization status event
            if (_continuousLocalization)
            {
                MagicLeapLocalizationMapFeature.OnLocalizationChangedEvent += CheckLocalizationState;
            }
        }
        
        /// <summary>
        /// Updates the dropdown UI with available Magic Leap Spaces based on settings.
        /// </summary>
        private void UpdateListOfAvailableSpaces()
        {
            if (_localizationMapFeature == null || !_localizationMapFeature.enabled)
            {
                _spaceManagerUI.UpdateStatusText("Magic Leap Localization Map feature does not exist or is not enabled.");
                return;
            }

            // Create a list of all Spaces on the device
            _localizationMapFeature.GetLocalizationMapsList(out _maps);
            
            if (_showAllLocalSpacesInDropdown)
            {
                // Add all Spaces to the dropdown
                _spaceManagerUI.AddSpaceOptions(
                    _maps
                        .Select(map => map.Name)
                        .ToList());
            }
            else
            {
                // Add only the Spaces relevant to this app.
                // Note: If SpaceContentDict has a name "Home" and your device has spaces "Home", "Home1", and "Home2", all three will be added. This method is limited by home Magic Leap encodes map.Name before localization.
                List<string> spaceOptions = new List<string>();
                foreach (var map in _maps)
                {
                    foreach (var name in SpaceContentDict.Keys)
                    {
                        if (map.Name.StartsWith(name))
                        {
                            spaceOptions.Add(map.Name);
                        }
                    }
                }
                _spaceManagerUI.AddSpaceOptions(spaceOptions.Distinct().ToList());
            }
        }

        /// <summary>
        /// Handler for start localization button click.
        /// </summary>
        public void OnStartButtonClicked()
        {
            LocalizeIntoSelectedMap();
        }
        
        /// <summary>
        /// Starts localization into the specified or currently selected map.
        /// </summary>
        /// <param name="name">Optional name of the localization map. If null, uses UI selection.</param>
        public void LocalizeIntoSelectedMap(string name = null)
        {
            // If null, get the name of the selected space from the UI
            string mapName = name ?? _spaceManagerUI.GetSelectedSpace();
            if (string.IsNullOrEmpty(mapName))
            {
                _spaceManagerUI.UpdateStatusText("No map selected.");
                return;
            }
            
            // Find the matching localization map and localize
            foreach (var map in _maps)
            {
                if (map.Name == mapName)
                {
                    LocalizeIntoMap(map);
                    return;
                }
            }
            
            // Display status error if no names matched
            _spaceManagerUI.UpdateStatusText("No matching localization map found.");
        }
        
        /// <summary>
        /// Initiates the localization process into a given localization map.
        /// </summary>
        /// <param name="map">Localization map to localize into.</param>
        private void LocalizeIntoMap(LocalizationMap map)
        {
            if (_localizationMapFeature == null || !_localizationMapFeature.enabled)
            {
                _spaceManagerUI.UpdateStatusText("Magic Leap Localization Map feature does not exist or is not enabled.");
                return;
            }

            // Start requesting localization. This is an async method.
            _localizationMapFeature.RequestMapLocalization(map.MapUUID);
            _isManuallyLocalizing = true;

            _spaceManagerUI.UpdateStatusText("Move around very slowly and look at\n" +
                                            "distinct physical features while attemping\n" +
											$"localization to {_spaceManagerUI.GetSelectedSpace()}");
            _spaceManagerUI.HideStartButton();

            StartCoroutine(PollManualResult());
        }

        /// <summary>
        /// Coroutine to poll the localization status manually during localization attempts.
        /// </summary>
        private IEnumerator PollManualResult()
        {
            int timeSecs = 1;

            while (_isManuallyLocalizing && timeSecs <= _manualLocalizationTimeLimitSecs)
            {
                ManualCheckLocalizationStatus();
                _spaceManagerUI.UpdateCountdownText($"{timeSecs.ToString()} / {_manualLocalizationTimeLimitSecs.ToString()}");
                timeSecs++;
                yield return new WaitForSecondsRealtime(1f);
            }
            _isManuallyLocalizing = false;
            
            _spaceManagerUI.UpdateCountdownText(string.Empty);
            _spaceManagerUI.ShowStartButton();

            if (timeSecs > _manualLocalizationTimeLimitSecs)
            {
                _spaceManagerUI.UpdateStatusText("Localization attempt timed out. Please try again.");
            }
        }

        /// <summary>
        /// Cancels the ongoing manual localization process.
        /// </summary>
        private void CancelLocalization()
        {
            StopCoroutine(PollManualResult());
            _isManuallyLocalizing = false;
            _spaceManagerUI.UpdateCountdownText(string.Empty);
            _spaceManagerUI.ShowStartButton();
            _spaceManagerUI.UpdateStatusText("Cancelled localization attempt.");
        }
        
        /// <summary>
        /// Manually checks the localization status by polling the latest event data.
        /// </summary>
        private void ManualCheckLocalizationStatus()
        {
            if (_localizationMapFeature.GetLatestLocalizationMapData(out LocalizationEventData data))
            {
                CheckLocalizationState(data);
            }
        }
        
        /// <summary>
        /// Checks the current localization state and acts accordingly.
        /// </summary>
        /// <param name="data">The localization event data.</param>
        private void CheckLocalizationState(LocalizationEventData data)
        {
            // Continuous
            if (_continuousLocalization)
            {
                if (data.State == LocalizationMapState.Localized)
                {
                    GetLocalizationMapData(data);
                }
                else
                {
                    _spaceManagerUI.UpdateStatusText("Attempting localization. Try moving and looking around very slowly...");
                }
            }
            // Manual
            else if (data.State == LocalizationMapState.Localized)
            {
                _isManuallyLocalizing = false;
                _spaceManagerUI.UpdateCountdownText(string.Empty);
                GetLocalizationMapData(data);
            }
        }

        /// <summary>
        /// Processes localization event data and updates content and UI accordingly.
        /// </summary>
        /// <param name="data">Localization event data.</param>
        private void GetLocalizationMapData(LocalizationEventData data)
        {
            // Cache the current localization map
            _currentMap = data.Map;
            string mapName = _currentMap.Name;
            string confidence = data.Confidence.ToString();
                
            // Cache the localization map origin
            _currentMapOrigin = _localizationMapFeature.GetMapOrigin();
                
            // Update status text in canvas
            if (_showOriginDataInMenu)
            {
                _spaceManagerUI.UpdateStatusText($"Localized {mapName}\n" +
                                                $"Confidence: {confidence}\n" +
                                                $"Map Position: {_currentMapOrigin.position}\n" +
                                                $"Map Rotation: {_currentMapOrigin.rotation.eulerAngles}");
            }
            else
            {
                _spaceManagerUI.UpdateStatusText($"Localized {mapName}\n" +
                                                $"Confidence: {confidence}");
            }
                
            // Reposition content based on the localization map origin
            PositionContent();
        }

        /// <summary>
        /// Moves the localized content GameObject to the position and rotation defined by the current map's origin.
        /// </summary>
        private void PositionContent()
        {
            // Check if the key is in the dictionary
            if (SpaceContentDict.TryGetValue(_currentMap.Name, out GameObject currentContent))
            {
                currentContent.SetActive(true);
                currentContent.transform.position = _currentMapOrigin.position;
                currentContent.transform.rotation = _currentMapOrigin.rotation;
                OnLocalizationCompleted?.Invoke(currentContent);
            }
            else
            {
                _spaceManagerUI.UpdateStatusText("Please select a different Space.\n" +
                                                $"This app does not use: {_currentMap.Name}.");
            }
        }

        /// <summary>
        /// Returns the list of all available localization maps retrieved from the Magic Leap feature.
        /// </summary>
        /// <returns>An array of <see cref="LocalizationMap"/> objects available on the device.</returns>
        public LocalizationMap[] GetLocalizationMaps()
        {
            return _maps;
        }

        /// <summary>
        /// Gets the name of the currently localized map.
        /// </summary>
        /// <returns>The name of the currently active <see cref="LocalizationMap"/>.</returns>
        public string GetCurrentMapName()
        {
            return _currentMap.Name;
        }
        
        /// <summary>
        /// Gets the world-space pose (position and rotation) of the currently localized map's origin.
        /// </summary>
        /// <returns>A <see cref="Pose"/> struct representing the map's origin.</returns>
        public Pose GetCurrentMapOrigin()
        {
            return _currentMapOrigin;
        }
    }
}
#endif
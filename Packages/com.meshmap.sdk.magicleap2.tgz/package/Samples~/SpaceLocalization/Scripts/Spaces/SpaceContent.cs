// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using System;
using UnityEngine;

namespace MeshMap.MagicLeap2.Samples.SpaceLocalization
{
    /// <summary>
    /// Represents a mapping between a Magic Leap Space name and its associated content GameObject.
    /// </summary>
    [Serializable]
    public class SpaceContent
    {
        /// <summary>
        /// The name of the Magic Leap Space this content is associated with.
        /// </summary>
        public string Space;
        
        /// <summary>
        /// The GameObject to be shown when the corresponding Space is localized.
        /// </summary>
        public GameObject Content;
    }
}
#endif
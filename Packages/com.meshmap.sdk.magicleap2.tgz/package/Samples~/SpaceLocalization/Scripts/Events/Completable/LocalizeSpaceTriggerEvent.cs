// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using System.Collections;
using UnityEngine;
using MeshMap.BuildingBlocks.Events;
using VContainer;

namespace MeshMap.MagicLeap2.Samples.SpaceLocalization
{
    /// <summary>
    /// Trigger event that attempts to localize into a specified Magic Leap Space,
    /// and marks itself completed when localization is confirmed or resets after a timeout.
    /// </summary>
    public class LocalizeSpaceTriggerEvent : CompletableTriggerEvent
    {
        [SerializeField, Tooltip("Time interval in seconds between localization status checks.")]
        private int _checkCompletionTime = 3;
        [SerializeField, Range(3, 30), Tooltip("Maximum time allowed for localization before forcing a reset.")]
        private int _forceCompletionTime = 30;
        [SerializeField, Tooltip("Name of the ML Space to localized into.")]
        private string _spaceName;
        [SerializeField, Tooltip("Content associated with the Space.")]
        private GameObject _content;
        [SerializeField] private string _eventName = "LocalizeSpaceTriggerEvent";

        private Coroutine _checkCompletionCoroutine;
        private Coroutine _forceCompletionCoroutine;

        [Inject] private SpaceManager _spaceManager;
        
        /// <summary>
        /// Starts attempting localization into the specified Magic Leap Space and initiates completion checks and timeout logic.
        /// </summary>
        public override void ActivateEvent()
        {
            base.ActivateEvent();
            Debug.Log($"{_eventName} activated.");

            foreach (var map in _spaceManager.GetLocalizationMaps())
            {
                if (map.Name.StartsWith(_spaceName))
                {
                    _spaceManager.LocalizeIntoSelectedMap(map.Name);
                    break;
                }
            }

            _checkCompletionCoroutine = StartCoroutine(CheckCompletionCoroutine());
            _forceCompletionCoroutine = StartCoroutine(ForceStateChangeAfterDelayCoroutine());
        }

        /// <summary>
        /// Coroutine that checks periodically whether the device has localized to the desired Space.
        /// </summary>
        private IEnumerator CheckCompletionCoroutine()
        {
            // Continuously check for completion
            while (_currentState == CompletableEventState.Active)
            {
                if (IsLocalized())
                {
                    SetToCompleted();
                }
                yield return new WaitForSeconds(_checkCompletionTime);
            }
        }

        /// <summary>
        /// Returns <c>true</c> if the current localized Space matches the configured Space name.
        /// </summary>
        public bool IsLocalized()
        {
            if (_spaceManager.GetCurrentMapName().StartsWith(_spaceName))
            {
                return true;
            }
            return false;
        }

        /// <summary>
        /// Completes the event and stops internal coroutines.
        /// </summary>
        public override void SetToCompleted()
        {
            base.SetToCompleted();
            Debug.Log($"{_eventName} completed.");
            
            if (_checkCompletionCoroutine != null)
            {
                StopCoroutine(_checkCompletionCoroutine);
                _checkCompletionCoroutine = null;
            }

            if (_forceCompletionCoroutine != null)
            {
                StopCoroutine(_forceCompletionCoroutine);
                _forceCompletionCoroutine = null;
            }
        }

        /// <summary>
        /// Coroutine that resets the event if it has not completed within the force timeout window.
        /// </summary>
        protected override IEnumerator ForceStateChangeAfterDelayCoroutine()
        {
            yield return new WaitForSeconds(_forceCompletionTime);
            if (_currentState == CompletableEventState.Active)
            {
                Debug.Log($"{_eventName} timed out before completion and reset.");
                _currentState = CompletableEventState.NotStarted;
            }
        }
    }
}
#endif
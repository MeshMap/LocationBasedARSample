// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.InputSystem;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
using UnityEngine.XR.Management;
using UnityEngine.XR.OpenXR;
using UnityEngine.XR.OpenXR.NativeTypes;
using MagicLeap.OpenXR.Features.LocalizationMaps;
using MagicLeap.OpenXR.Features.SpatialAnchors;
using MagicLeap.OpenXR.Subsystems;
using MagicLeap.Android;

namespace MeshMap.MagicLeap2.Samples.SpatialAnchors
{
    /// <summary>
    /// Manages the creation, publishing, localization, and querying of spatial anchors using Magic Leap's Spatial Anchors, Localization Maps, and Storage features.
    /// </summary>
    public class SpatialAnchorManager : MonoBehaviour
    {
        [Header("Anchor Management")]
        [SerializeField] private ARAnchorManager _anchorManager;
        [SerializeField] private GameObject _anchorPrefab;
        [SerializeField] private float _queryAnchorsRadius = 10f;

        [Header("Controller Settings")]
        [SerializeField, Tooltip("Input action to place/remove AR anchors.")]
        private InputActionProperty _anchorInputAction;
        
        [SerializeField, Tooltip("XR controller used to position the anchors.")]
        private Transform _controllerTransform;
        
        [Header("UI Settings")]
        [SerializeField] private TMP_Dropdown _mapsDropdown;
        [SerializeField] private TMP_Dropdown _anchorSettingDropdown;
        [SerializeField] private Button _localizeSpaceButton;
        [SerializeField] private Button _publishAnchorsButton;
        [SerializeField] private TextMeshProUGUI _localizationStatusText;
        [SerializeField] private TextMeshProUGUI _spaceNameText;
        [SerializeField] private TextMeshProUGUI _publishedAnchorsText;
        [SerializeField] private TextMeshProUGUI _localAnchorsText;

        private MagicLeapLocalizationMapFeature _localizationMapFeature;
        private MagicLeapSpatialAnchorsFeature _spatialAnchorsFeature;
        private MagicLeapSpatialAnchorsStorageFeature _storageFeature;
        private MLXrAnchorSubsystem _anchorSubsystem;
        private bool _permissionGranted;
        
        private LocalizationMap[] _maps;
        private LocalizationEventData _mapData;
        
        private List<PublishedAnchor> _publishedAnchors = new();
        private List<ARAnchor> _activeAnchors = new();
        private List<ARAnchor> _pendingPublishedAnchors = new();
        private List<ARAnchor> _localAnchors = new();

        /// <summary>
        /// Internal struct representing a published anchor and its associated metadata.
        /// </summary>
        private struct PublishedAnchor
        {
            public ulong AnchorId;
            public string AnchorMapPositionId;
            public ARAnchor AnchorObject;
        }
        
        private IEnumerator Start()
        {
            yield return new WaitUntil(AreSubsystemsLoaded);
            
            GetFeatures();
            SetUpInputs();
            AttachStorageListeners();
            
            _localizationMapFeature = OpenXRSettings.Instance.GetFeature<MagicLeapLocalizationMapFeature>();
            
            Permissions.RequestPermission(Permissions.SpaceImportExport, OnPermissionGranted, OnPermissionDenied);
        }
        
        private void Update()
        {
            if (_permissionGranted)
            {
                if (_pendingPublishedAnchors.Count > 0)
                {
                    for (int i = _pendingPublishedAnchors.Count - 1; i >= 0; i--)
                    {
                        if (_pendingPublishedAnchors[i].trackingState == TrackingState.Tracking)
                        {
                            ulong anchorId = _anchorSubsystem.GetAnchorId(_pendingPublishedAnchors[i]);
                            if (!_storageFeature.PublishSpatialAnchorsToStorage(new List<ulong>() { anchorId }, 0))
                            {
                                Debug.LogError($"Failed to publish anchor {anchorId} at position {_pendingPublishedAnchors[i].gameObject.transform.position} to storage");
                            }
                            else
                            {
                                _pendingPublishedAnchors.RemoveAt(i);
                            }
                        }
                    }
                }

                if (_localizationMapFeature.enabled)
                {
                    _localizationMapFeature.GetLatestLocalizationMapData(out LocalizationEventData data);
                    CheckLocalizationState(data);
                }

                UpdateStoredAnchorTransforms();
            }
        }

        private void OnDestroy()
        {
            _anchorInputAction.action.performed -= OnAnchorInput;
            _localizeSpaceButton.onClick.RemoveListener(LocalizeMap);
            _publishAnchorsButton.onClick.RemoveListener(PublishAnchors);
            
            _storageFeature.OnCreationCompleteFromStorage -= OnCreateFromStorageComplete;
            _storageFeature.OnPublishComplete -= OnPublishComplete;
            _storageFeature.OnQueryComplete -= OnQueryComplete;
            _storageFeature.OnDeletedComplete -= OnDeletedComplete;
        }

        /// <summary>
        /// Waits for XR subsystems to load and assigns the anchor subsystem.
        /// </summary>
        /// <returns>True when subsystems are loaded.</returns>
        private bool AreSubsystemsLoaded()
        {
            if (XRGeneralSettings.Instance == null) return false;
            if (XRGeneralSettings.Instance.Manager == null) return false;
            var activeLoader = XRGeneralSettings.Instance.Manager.activeLoader;
            if (activeLoader == null) return false;
            _anchorSubsystem = activeLoader.GetLoadedSubsystem<XRAnchorSubsystem>() as MLXrAnchorSubsystem;
            return _anchorSubsystem != null;
        }
        
        /// <summary>
        /// Retrieves references to required Magic Leap OpenXR features.
        /// </summary>
        private void GetFeatures()
        {
            _spatialAnchorsFeature = OpenXRSettings.Instance.GetFeature<MagicLeapSpatialAnchorsFeature>();
            _storageFeature = OpenXRSettings.Instance.GetFeature<MagicLeapSpatialAnchorsStorageFeature>();
            _localizationMapFeature = OpenXRSettings.Instance.GetFeature<MagicLeapLocalizationMapFeature>();
            if (!_spatialAnchorsFeature || !_localizationMapFeature || !_storageFeature)
            {
                enabled = false;
            }
        }

        /// <summary>
        /// Sets up input actions and UI button listeners.
        /// </summary>
        private void SetUpInputs()
        {
            _anchorInputAction.action.performed += OnAnchorInput;
            _localizeSpaceButton.onClick.AddListener(LocalizeMap);
            _publishAnchorsButton.onClick.AddListener(PublishAnchors);
        }

        /// <summary>
        /// Attaches callbacks to spatial anchor storage events.
        /// </summary>
        private void AttachStorageListeners()
        {
            // Anchors created from a list of map location ids from querying storage
            _storageFeature.OnCreationCompleteFromStorage += OnCreateFromStorageComplete;

            // Publish local anchors to storage
            _storageFeature.OnPublishComplete += OnPublishComplete;

            // Querying storage for a list of published anchors
            _storageFeature.OnQueryComplete += OnQueryComplete;

            // Deleting a published / stored anchor from storage
            _storageFeature.OnDeletedComplete += OnDeletedComplete;
        }
        
        private void OnPermissionDenied(string permission)
        {
            _permissionGranted = false;
            Debug.LogError("Spatial anchor publishing and map localization will not work without permission.");
        }
        
        /// <summary>
        /// Called when the SpaceImportExport permission is granted.
        /// Fetches available maps and enables localization events.
        /// </summary>
        private void OnPermissionGranted(string permission)
        {
            _permissionGranted = true;
            if (_localizationMapFeature.GetLocalizationMapsList(out _maps) == XrResult.Success)
            {
                _mapsDropdown.AddOptions(_maps.Select(map => map.Name).ToList());
                _mapsDropdown.Hide();
                Debug.Log("Successfully got localization maps list");
            }

            XrResult res = _localizationMapFeature.EnableLocalizationEvents(true);
            if (res != XrResult.Success)
            {
                Debug.LogError("EnableLocalizationEvents failed: " + res);
            }
        }

        /// <summary>
        /// Handles input action for anchors, creating or deleting anchors
        /// depending on the current dropdown selection.
        /// </summary>
        /// <param name="context">Input action callback context.</param>
        private void OnAnchorInput(InputAction.CallbackContext context)
        {
            if (_anchorSettingDropdown.value == 0)
            {
                CreateAnchor();
            }
            else
            {
                DeleteAnchor();
            }
        }
        
        /// <summary>
        /// Creates a new anchor at the controller's position and rotation, and adds it to active and local anchor lists.
        /// </summary>
        public void CreateAnchor()
        {
            var instance = Instantiate(_anchorPrefab, _controllerTransform.position, _controllerTransform.rotation);
            if (instance.GetComponent<ARAnchor>() == null)
            {
                instance.AddComponent<ARAnchor>();
            }
            ARAnchor newAnchor = instance.GetComponent<ARAnchor>();
            _activeAnchors.Add(newAnchor);
            _localAnchors.Add(newAnchor);
            
            Debug.Log("Created a new anchor");
        }
        
        /// <summary>
        /// Callback when an anchor is created from storage.
        /// Instantiates anchor GameObject and adds it to the published anchors list.
        /// </summary>
        /// <param name="pose">Pose of the anchor.</param>
        /// <param name="anchorId">Unique ID of the anchor.</param>
        /// <param name="anchorMapPositionId">Map position identifier for the anchor.</param>
        /// <param name="result">Result of the anchor creation operation.</param>
        private void OnCreateFromStorageComplete(Pose pose, ulong anchorId, string anchorMapPositionId, XrResult result)
        {
            if (result != XrResult.Success)
            {
                Debug.LogError("Could not create anchor from storage: " + result);
                return;
            }

            GameObject newAnchor = Instantiate(_anchorPrefab, pose.position, pose.rotation);
            ARAnchor newAnchorComponent = newAnchor.AddComponent<ARAnchor>();

            PublishedAnchor newPublishedAnchor = new PublishedAnchor
            {
                AnchorId = anchorId,
                AnchorMapPositionId = anchorMapPositionId,
                AnchorObject = newAnchorComponent
            };

            _publishedAnchors.Add(newPublishedAnchor);
        }

        /// <summary>
        /// Deletes the most recently created local anchor. If none exist, deletes the last published anchor from storage.
        /// </summary>
        public void DeleteAnchor()
        {
            // Delete most recent local anchor first
            if (_localAnchors.Count > 0)
            {
                Destroy(_localAnchors[^1].gameObject);
                _localAnchors.RemoveAt(_localAnchors.Count - 1);
                Debug.Log("Deleted the most recent local anchor");
            }
            // Delete the last published anchor
            else if (_publishedAnchors.Count > 0)
            {
                _storageFeature.DeleteStoredSpatialAnchors(new List<string> { _publishedAnchors[^1].AnchorMapPositionId });
                Debug.Log("No more local anchors, so deleted the last published anchor");
            }
        }
        
        /// <summary>
        /// Callback invoked when anchor deletion is complete.
        /// Removes corresponding published anchors and destroys their GameObjects.
        /// </summary>
        /// <param name="anchorMapPositionIds">List of deleted anchor map position IDs.</param>
        private void OnDeletedComplete(List<string> anchorMapPositionIds)
        {
            foreach (string anchorMapPositionId in anchorMapPositionIds)
            {
                for (int i = _publishedAnchors.Count - 1; i >= 0; i--)
                {
                    if (_publishedAnchors[i].AnchorMapPositionId == anchorMapPositionId)
                    {
                        Destroy(_publishedAnchors[i].AnchorObject.gameObject);
                        _publishedAnchors.RemoveAt(i);
                        Debug.Log($"OnDeletedComplete AnchorId: {_publishedAnchors[i].AnchorId} anchorMapPositionId: {_publishedAnchors[i].AnchorMapPositionId} was removed");
                        break;
                    }
                }
            }
        }
        
        /// <summary>
        /// Publishes all locally created anchors to spatial anchor storage.
        /// Moves them from local to pending published anchors list.
        /// </summary>
        public void PublishAnchors()
        {
            foreach (ARAnchor anchor in _localAnchors)
            {
                _pendingPublishedAnchors.Add(anchor);
                Debug.Log("Published anchor at " + anchor.transform.position.ToString());
            }
            _localAnchors.Clear();
        }
        
        /// <summary>
        /// Coroutine that waits until the given anchor is tracked before
        /// publishing it to storage.
        /// </summary>
        /// <param name="toPublish">Anchor to publish.</param>
        /// <returns>Coroutine enumerator.</returns>
        private IEnumerator PublishAnchorFromQuery(ARAnchor toPublish)
        {
            while (toPublish.trackingState != TrackingState.Tracking)
            {
                yield return null;
            }
            _storageFeature.PublishSpatialAnchorsToStorage(new List<ARAnchor> { toPublish  }, 0);
        }
        
        /// <summary>
        /// Callback when publishing an anchor completes successfully.
        /// Moves the anchor from active to published anchors list.
        /// </summary>
        /// <param name="anchorId">Anchor's unique ID.</param>
        /// <param name="anchorMapPositionId">Anchor's map position ID.</param>
        private void OnPublishComplete(ulong anchorId, string anchorMapPositionId)
        {
            Debug.Log($"OnPublishCompleted AnchorID: {anchorId} AnchorMapPositionId: {anchorMapPositionId}");
            for (int i = _activeAnchors.Count - 1; i >= 0; i--)
            {
                if (_anchorSubsystem.GetAnchorId(_activeAnchors[i]) == anchorId)
                {
                    PublishedAnchor newPublishedAnchor = new PublishedAnchor
                    {
                        AnchorId = anchorId,
                        AnchorMapPositionId = anchorMapPositionId,
                        AnchorObject = _activeAnchors[i]
                    };

                    _publishedAnchors.Add(newPublishedAnchor);
                    _activeAnchors.RemoveAt(i);
                    break;
                }
            }
        }
        
        /// <summary>
        /// Queries stored anchors around the controller's current position within a specified radius.
        /// </summary>
        public void QueryAnchors()
        {
            if (!_storageFeature.QueryStoredSpatialAnchors(_controllerTransform.position, _queryAnchorsRadius))
            {
                Debug.LogError("Could not query stored anchors");
            }
            else
            {
                Debug.Log($"Querying anchors within a radius of {_queryAnchorsRadius} meters");
            }
        }
        
        /// <summary>
        /// Callback when anchor query completes.
        /// Instantiates new anchors for queried IDs not already loaded,
        /// and removes any published anchors no longer returned in query results.
        /// </summary>
        /// <param name="anchorMapPositionIds">List of anchor map position IDs returned by the query.</param>

        private void OnQueryComplete(List<string> anchorMapPositionIds)
        {
            if (_publishedAnchors.Count == 0)
            {
                if (!_storageFeature.CreateSpatialAnchorsFromStorage(anchorMapPositionIds))
                {
                    Debug.LogError("Couldn't create spatial anchors from storage");
                }
                return;
            }

            foreach (string anchorMapPositionId in anchorMapPositionIds)
            {
                var matches = _publishedAnchors.Where(p => p.AnchorMapPositionId == anchorMapPositionId);
                if (matches.Count() == 0)
                {
                    if (!_storageFeature.CreateSpatialAnchorsFromStorage(new List<string>() { anchorMapPositionId }))
                    {
                        Debug.LogError("Couldn't create spatial anchors from storage");
                    }
                }
            }

            for (int i = _publishedAnchors.Count - 1; i >= 0; i--)
            {
                if (!anchorMapPositionIds.Contains(_publishedAnchors[i].AnchorMapPositionId))
                {
                    Destroy(_publishedAnchors[i].AnchorObject.gameObject);
                    _publishedAnchors.RemoveAt(i);
                }
            }
        }
        
        /// <summary>
        /// Updates the transforms of all stored published anchors based on the latest anchor poses from the anchor subsystem.
        /// </summary>
        private void UpdateStoredAnchorTransforms()
        {
            if (_anchorSubsystem == null)
            {
                return;
            }
            foreach (var anchor in _publishedAnchors)
            {
                var anchorObject = anchor.AnchorObject.gameObject;
                var pose = _anchorSubsystem.GetAnchorPoseFromId(anchor.AnchorId);
                anchorObject.transform.position = pose.position;
                anchorObject.transform.rotation = pose.rotation;
            }
        }
        
        /// <summary>
        /// Initiates localization of the currently selected map from the dropdown,
        /// clearing existing anchors and preparing to query new anchors from storage.
        /// </summary>
        public void LocalizeMap()
        {
            if (_permissionGranted == false || _localizationMapFeature == null)
            {
                return;
            }

            string map = _maps.Length > 0 ? _maps[_mapsDropdown.value].MapUUID : "";
            var res = _localizationMapFeature.RequestMapLocalization(map);
            if (res != XrResult.Success)
            {
                Debug.LogError("Failed to request localization: " + res);
                return;
            }

            //On map change, we need to clear up present published anchors and query new ones
            foreach (PublishedAnchor obj in _publishedAnchors)
            {
                Destroy(obj.AnchorObject.gameObject);
            }
            _publishedAnchors.Clear();

            foreach (ARAnchor anchor in _localAnchors)
            {
                Destroy(anchor.gameObject);
            }
            _localAnchors.Clear();

            _activeAnchors.Clear();
        }
        
        /// <summary>
        /// Callback to update UI elements based on the current localization state and confidence.
        /// </summary>
        /// <param name="data">Localization event data containing state, confidence, and map info.</param>
        private void CheckLocalizationState(LocalizationEventData data)
        {
            UpdateUIText(_localizationStatusText, $"{data.State} ({data.Confidence})");
            UpdateUIText(_spaceNameText, data.Map.Name);
            UpdateUIText(_publishedAnchorsText, _publishedAnchors.Count.ToString());
            UpdateUIText(_localAnchorsText, _localAnchors.Count.ToString());
        }
        
        /// <summary>
        /// Utility method to update the text of a given TextMeshProUGUI element.
        /// </summary>
        /// <param name="uiText">UI text element to update.</param>
        /// <param name="text">New text content.</param>
        private void UpdateUIText(TextMeshProUGUI uiText, string text)
        {
            uiText.text = text;
        }
    }
}
#endif
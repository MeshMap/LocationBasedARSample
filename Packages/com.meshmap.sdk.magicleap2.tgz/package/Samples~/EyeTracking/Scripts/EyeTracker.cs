// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using UnityEngine;
using UnityEngine.XR.OpenXR;
using MagicLeap.OpenXR.Features.EyeTracker;
using MagicLeap.Android;

namespace MeshMap.MagicLeap2.Samples.EyeTracking
{
    /// <summary>
    /// Initializes and manages the Magic Leap Eye Tracker using OpenXR.
    /// Handles permission requests, feature activation, and optionally logs gaze, pupil, and geometric data each frame.
    /// </summary>
    public class EyeTracker : MonoBehaviour
    {
        [SerializeField] private bool _logDataEveryFrame = true;
        
        private MagicLeapEyeTrackerFeature _eyeTrackerFeature;
        private bool _eyeTrackPermissionGranted = false;
        private bool _pupilSizePermissionGranted = false;
        
        /// <summary>
        /// Indicates whether the tracker is fully initialized and permissions have been granted.
        /// </summary>
        public bool IsReady => _eyeTrackPermissionGranted && _pupilSizePermissionGranted && _eyeTrackerFeature?.enabled == true;
        
        private void Start()
        {
            if (Permissions.CheckPermission(Permissions.EyeTracking) &&
                Permissions.CheckPermission(Permissions.PupilSize))
            {
                _eyeTrackPermissionGranted = true;
                _pupilSizePermissionGranted = true;
                InitializeEyeTrackerFeature();
            }
            else
            {
                Permissions.RequestPermissions(new string[] { Permissions.EyeTracking, Permissions.PupilSize }, OnPermissionGranted, OnPermissionDenied);
            }
        }

        private void Update()
        {
            if (!_eyeTrackPermissionGranted || !_pupilSizePermissionGranted)
                return;

            if (_eyeTrackerFeature != null && _eyeTrackerFeature.enabled)
            {
                if (_logDataEveryFrame)
                {
                    LogLatestData();
                }
            }
        }

        private void OnDestroy()
        {
            if (_eyeTrackerFeature != null && _eyeTrackerFeature.enabled)
            {
                _eyeTrackerFeature.DestroyEyeTracker();
                Debug.Log("Eye Tracker destroyed.");
            }
        }

        private void OnPermissionDenied(string permission)
        {
            Debug.LogError($"{permission} denied. Eye Tracking will not be available.");
            enabled = false;
        }

        private void OnPermissionGranted(string permission)
        {
            if (permission == Permissions.EyeTracking)
            {
                _eyeTrackPermissionGranted = true;
                Debug.Log("Eye Tracking permission granted.");
            }

            if (permission == Permissions.PupilSize)
            {
                _pupilSizePermissionGranted = true;
                Debug.Log("Pupil Size permission granted.");
            }

            // If both permissions are granted, initialize the eye tracker
            if (_eyeTrackPermissionGranted && _pupilSizePermissionGranted)
            {
                InitializeEyeTrackerFeature();
            }
        }

        /// <summary>
        /// Initializes the Magic Leap Eye Tracker feature if it is enabled in the OpenXR project settings.
        /// </summary>
        private void InitializeEyeTrackerFeature()
        {
            _eyeTrackerFeature = OpenXRSettings.Instance.GetFeature<MagicLeapEyeTrackerFeature>();
            if (_eyeTrackerFeature != null && _eyeTrackerFeature.enabled)
            {
                _eyeTrackerFeature.CreateEyeTracker();
                Debug.Log("Eye Tracker initialized.");
            }
            else
            {
                Debug.LogError("Failed to initialize the Eye Tracker. Ensure the feature is enabled in OpenXR settings.");
            }
        }
        
        /// <summary>
        /// Retrieves and logs detailed eye tracking data including geometric data, pupil size, gaze behavior, and static calibration info.
        /// </summary>
        private void LogLatestData()
        {
            // Retrieve all eye-tracking data
            EyeTrackerData eyeTrackerData = _eyeTrackerFeature.GetEyeTrackerData();

            // Log Geometric Data
            foreach (var geometricData in eyeTrackerData.GeometricData)
            {
                Debug.Log($"Geometric Data - Eye: {geometricData.Eye}, Openness: {geometricData.EyeOpenness}, Position: {geometricData.EyeInSkullPosition}");
            }

            // Log Pupil Data
            foreach (var pupilData in eyeTrackerData.PupilData)
            {
                Debug.Log($"Pupil Data - Eye: {pupilData.Eye}, Diameter: {pupilData.PupilDiameter} meters");
            }

            // Log Gaze Behavior Data
            GazeBehavior gazeBehavior = eyeTrackerData.GazeBehaviorData;
            Debug.Log($"Gaze Behavior - Type: {gazeBehavior.GazeBehaviorType}, Duration: {gazeBehavior.Duration}, Amplitude: {gazeBehavior.MetaData.Amplitude}, Direction: {gazeBehavior.MetaData.Direction}, Velocity: {gazeBehavior.MetaData.Velocity}");

            // Log Static Data
            StaticData staticData = eyeTrackerData.StaticData;
            Debug.Log($"Static Data - Max Width: {staticData.EyeWidthMax}, Max Height: {staticData.EyeHeightMax}");
        }
        
        /// <summary>
        /// Returns the latest eye tracking data.
        /// </summary>
        public EyeTrackerData LatestData => _eyeTrackerFeature?.GetEyeTrackerData() ?? default;
    }
}
#endif
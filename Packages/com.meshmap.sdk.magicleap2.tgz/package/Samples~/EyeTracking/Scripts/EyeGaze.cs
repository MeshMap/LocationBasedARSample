// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;
using UnityEngine.XR.OpenXR.Features.Interactions;
using MagicLeap.Android;
using InputDevice = UnityEngine.XR.InputDevice;

namespace MeshMap.MagicLeap2.Samples.EyeTracking
{
    /// <summary>
    /// Finds and initializes a Magic Leap eye tracking input device, retrieves gaze data, and optionally visualizes it in the scene.
    /// Requires the Eye Gaze Interaction Profile to be enabled in the project's OpenXR settings.
    /// </summary>
    public class EyeGaze : MonoBehaviour
    {
        [Header("Gaze Visual Settings")]
        [SerializeField] private bool _showGazeVisual = true;
        [SerializeField] private GameObject _gazeVisual;
        [SerializeField, Tooltip("How quickly the gaze visual's trail renderer updates.")]
        private float _trailSpeed = 12f;
        [SerializeField, Tooltip("Distance threshold for updating the gaze visual's position.")]
        private float _trailThreshold = 0.03f;
        
        [Header("Gaze Target Visual Settings")]
        [SerializeField] private bool _showTargetVisual = true;
        [SerializeField] private GameObject _targetVisual;
        
        [Header("Debug Log Settings")]
        [SerializeField] private bool _logLatestData = false;
        
        private InputDevice _eyeTrackingDevice;
        private bool _permissionGranted;
        
        /// <summary>
        /// Indicates whether eye tracking permission has been granted.
        /// </summary>
        public bool IsReady => _permissionGranted;
        
        /// <summary>
        /// The latest eye gaze origin position in world space.
        /// </summary>
        public Vector3 GazePosition { get; private set; }
        
        /// <summary>
        /// The latest eye gaze rotation in world space.
        /// </summary>
        public Quaternion GazeRotation { get; private set; }
        
        /// <summary>
        /// The forward direction vector of the eye gaze.
        /// </summary>
        public Vector3 GazeDirection { get; private set; }
        
        private Vector3 _targetPosition;

        private Camera _mainCamera;

        private void Start()
        {
            // Assign camera
            _mainCamera = Camera.main;
            
            // Prepare the gaze and target visuals
            _gazeVisual.SetActive(_showGazeVisual);
            _targetVisual.SetActive(false);
            
            // Start permissions checks
            if (Permissions.CheckPermission(Permissions.EyeTracking))
            {
                _permissionGranted = true;
            }
            else
            {
                Permissions.RequestPermission(Permissions.EyeTracking, OnPermissionGranted, OnPermissionDenied);
            }
        }

        private void Update()
        {
            if (!_permissionGranted)
            {
                // Wait for permission
                return;
            }

            if (!_eyeTrackingDevice.isValid)
            {
                // Attempt to reinitialize if necessary
                InitializeEyeTrackingDevice();
            }
            
            GetGazeTrackingInput();
        }
        
        private void OnPermissionDenied(string permission)
        {
            Debug.LogError($"{permission} denied. Eye Tracking will not be available.");
            enabled = false;
        }

        private void OnPermissionGranted(string permission)
        {
            _permissionGranted = true;
            Debug.Log("Eye Tracking permission granted.");
            InitializeEyeTrackingDevice();
        }

        /// <summary>
        /// Attempts to find and assign an available eye tracking input device.
        /// </summary>
        private void InitializeEyeTrackingDevice()
        {
            List<InputDevice> inputDeviceList = new List<InputDevice>();
            InputDevices.GetDevicesWithCharacteristics(InputDeviceCharacteristics.EyeTracking, inputDeviceList);
            
            if (inputDeviceList.Count > 0)
            {
                _eyeTrackingDevice = inputDeviceList[0];
                Debug.Log("Eye Tracking device initialized.");
            }

            if (!_eyeTrackingDevice.isValid)
            {
                Debug.LogWarning($"Unable to acquire eye tracking device. Have permissions been granted?");
                return;
            }
        }

        /// <summary>
        /// Retrieves the latest transform data for the eye gaze from Tracked Pose Driver Input (uses Open XR Gaze Interaction Profile) and updates visuals accordingly.
        /// </summary>
        private void GetGazeTrackingInput()
        {
            bool hasData = _eyeTrackingDevice.TryGetFeatureValue(CommonUsages.isTracked, out bool isTracked);
            hasData &= _eyeTrackingDevice.TryGetFeatureValue(EyeTrackingUsages.gazePosition, out Vector3 position);
            hasData &= _eyeTrackingDevice.TryGetFeatureValue(EyeTrackingUsages.gazeRotation, out Quaternion rotation);

            if (isTracked && hasData)
            {
                // Cache gaze data
                GazePosition = position;
                GazeRotation = rotation;
                GazeDirection = rotation * Vector3.forward;

                // Use gaze data
                UpdateGazeVisual();
                
                if (_showTargetVisual)
                {
                    UpdateTargetVisual();
                }
                
                if (_logLatestData)
                {
                    Debug.Log($"Gaze Origin: {GazePosition} | Gaze Rotation: {GazeRotation} | Gaze Direction {GazeDirection}");
                }
            }
        }

        /// <summary>
        /// Updates the gaze visual's position.
        /// </summary>
        private void UpdateGazeVisual()
        {
            if (_gazeVisual != null)
            {
                // Use a default target one meter away
                _targetPosition = GazePosition + GazeDirection;
                if (Vector3.Distance(_gazeVisual.transform.position, _targetPosition) > _trailThreshold)
                {
                    _gazeVisual.transform.position = Vector3.Lerp(_gazeVisual.transform.position, _targetPosition, Time.deltaTime * _trailSpeed);
                }
            }
        }

        /// <summary>
        /// Updates and positions the target visual if the gaze ray hits a collider in the scene.
        /// </summary>
        private void UpdateTargetVisual()
        {
            var ray = new Ray(GazePosition, GazeDirection);
            if (Physics.Raycast(ray, out RaycastHit hit))
            {
                _targetVisual.SetActive(true);
                
                // Move the target visual to the origin of the object being looked at (use hit.point to use the exact hit location instead)
                _targetVisual.transform.position = hit.transform.position;
                
                // Turn the target visual to face the camera
                _targetVisual.transform.LookAt(_mainCamera.transform);
            }
            else
            {
                _targetVisual.SetActive(false);
            }
        }
    }
}
#endif
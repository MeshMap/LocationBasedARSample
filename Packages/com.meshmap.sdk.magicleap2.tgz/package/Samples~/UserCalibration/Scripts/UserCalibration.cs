// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.XR.OpenXR;
using MagicLeap.OpenXR.Features.UserCalibration;

namespace MeshMap.MagicLeap2.Samples.UserCalibration
{
    /// <summary>
    /// Defines the type of calibration to launch: full headset fitting with eye calibration, or eye calibration only.
    /// </summary>
    public enum CalibrationType
    {
        FittingAndEye,
        Eye
    }
    
    /// <summary>
    /// Manages the user calibration process for Magic Leap 2 using the OpenXR User Calibration feature.
    /// Provides countdown, UI prompts, and launches the system fitting/eye calibration apps based on the current calibration status.
    /// </summary>
    public class FittingCalibration : MonoBehaviour
    {
        public static event Action OnUserCalibrationSatisfactory;
        public static event Action OnUserCalibrationSkipped;
        
        private string _fittingIntentID = "com.magicleap.intent.action.FITTING";
        private string _eyeIntentID = "com.magicleap.intent.action.EYE_CALIBRATION_AUTOMATIC";

        [SerializeField] private CalibrationType _calibrationType = CalibrationType.FittingAndEye;
        [SerializeField] private int _startDelaySecs = 10;
        [SerializeField] private TextMeshProUGUI _countdownText;
        [SerializeField] private TextMeshProUGUI _statusText;
        [SerializeField] private Button _skipButton;
        [SerializeField] private GameObject _userCalibrationPanel;

        private Coroutine _fittingAppCoroutine;
        private MagicLeapUserCalibrationFeature _userCalibrationFeature;
        
        private void Start()
        {
            InitializeUI();
            InitializeCalibrationFeature();
            CheckCalibration();
        }

        private void OnDestroy()
        {
            if (_skipButton != null)
            {
                _skipButton.onClick.RemoveListener(SkipCalibration);
            }
            
            DisableCalibrationEvents();
        }

        private void InitializeUI()
        {
            if (_countdownText == null || _statusText == null || _skipButton == null || _userCalibrationPanel == null)
            {
                Debug.LogError("A UI element is missing.");
                return;
            }
            
            _userCalibrationPanel.SetActive(true);
            
            // Add listeners
            _skipButton.onClick.AddListener(SkipCalibration);
        }

        /// <summary>
        /// Verifies the calibration feature is enabled in OpenXR and sets up event tracking.
        /// </summary>
        private void InitializeCalibrationFeature()
        {
            if (!OpenXRRuntime.IsExtensionEnabled("XR_ML_user_calibration"))
            {
                Debug.LogError("The OpenXR Features \"Magic Leap 2 User Calibration\" and \"Magic Leap 2 Eye Tracker\" must be enabled in Project settings.");
                enabled = false;
                return;
            }
            
            _userCalibrationFeature = OpenXRSettings.Instance.GetFeature<MagicLeapUserCalibrationFeature>();
            _userCalibrationFeature.EnableUserCalibrationEvents(true);
        }

        /// <summary>
        /// Checks the latest eye calibration status and starts the countdown if calibration is needed.
        /// </summary>
        private void CheckCalibration()
        {
            _userCalibrationFeature.GetLastEyeCalibration(out MagicLeapUserCalibrationFeature.EyeCalibrationData eyeCalibrationData);

            _statusText.text = $"User calibration status: {eyeCalibrationData.Status}";

            // Only need to calibrate if the status is poor
            if (eyeCalibrationData.Status != MagicLeapUserCalibrationFeature.EyeCalibrationStatus.Fine)
            {
                _statusText.text += "\nOpening Calibration app...";
                _skipButton.gameObject.SetActive(true);
                _fittingAppCoroutine = StartCoroutine(OpenFittingApp());
            }
            else
            {
                OnUserCalibrationSatisfactory?.Invoke();
                DisableCalibrationEvents();
                ResetUI();
                enabled = false;
            }
        }

        /// <summary>
        /// Coroutine that performs a countdown, then launches the appropriate calibration app via Android Intent.
        /// </summary>
        private IEnumerator OpenFittingApp()
        {
            // Countdown
            int countdown = _startDelaySecs;
            while (countdown > 0)
            {
                _countdownText.text = countdown.ToString();
                yield return new WaitForSeconds(1);
                countdown--;
            }
            
            // Open app using Android Intent
#if UNITY_MAGICLEAP || UNITY_ANDROID
            if (_calibrationType == CalibrationType.FittingAndEye)
            {
                UnityEngine.XR.MagicLeap.SettingsIntentsLauncher.LaunchSystemSettings(_fittingIntentID);
            }
            else
            {
                UnityEngine.XR.MagicLeap.SettingsIntentsLauncher.LaunchSystemSettings(_eyeIntentID);
            }
#endif
            
            // Prepare the app for afterward
            OnUserCalibrationSatisfactory?.Invoke();
            DisableCalibrationEvents();
            ResetUI();
            enabled = false;
        }

        /// <summary>
        /// Skips the calibration process and resets the UI. Raises the skipped event.
        /// </summary>
        public void SkipCalibration()
        {
            if (_fittingAppCoroutine != null)
            {
                StopCoroutine(_fittingAppCoroutine);
            }
            OnUserCalibrationSkipped?.Invoke();
            DisableCalibrationEvents();
            ResetUI();
            enabled = false;
        }

        /// <summary>
        /// Disables user calibration event tracking on the calibration feature.
        /// </summary>
        private void DisableCalibrationEvents()
        {
            if (_userCalibrationFeature != null && _userCalibrationFeature.enabled)
            {
                _userCalibrationFeature.EnableUserCalibrationEvents(false);
            }
        }

        /// <summary>
        /// Resets UI elements and hides the calibration panel.
        /// </summary>
        private void ResetUI()
        {
            _countdownText.text = string.Empty;
            _statusText.text = string.Empty;
            _userCalibrationPanel.SetActive(false);
        }
    }
}
#endif
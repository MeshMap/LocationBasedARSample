// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using UnityEngine;
using UnityEngine.XR.OpenXR;
using MagicLeap.OpenXR.Features.PhysicalOcclusion;

namespace MeshMap.MagicLeap2.Samples.Occlusion
{
    /// <summary>
    /// Configures and enables the Magic Leap 2 Physical Occlusion feature using the specified occlusion sources and depth sensor range.
    /// </summary>
    public class PhysicalOcclusion : MonoBehaviour
    {
        [SerializeField, Tooltip("The sources to use for the Physical Occlusion Feature. Environment (distance) will override DepthSensor (near).")]
        private MagicLeapPhysicalOcclusionFeature.OcclusionSource _occlusionSource = 
            MagicLeapPhysicalOcclusionFeature.OcclusionSource.DepthSensor |
            MagicLeapPhysicalOcclusionFeature.OcclusionSource.Controller |
            MagicLeapPhysicalOcclusionFeature.OcclusionSource.Hands;
    
        [SerializeField, Tooltip("Depth sensor operates at 30fps when maximum range is 0.9 meters or lower. (min 0.3, max 7.5)")]
        private float _nearRange = 0.3f;
    
        [SerializeField, Tooltip("Depth sensor operates at 30fps when maximum range is 0.9 meters or lower. (min 0.3, max 7.5)")]
        private float _farRange = 0.9f;

        private MagicLeapPhysicalOcclusionFeature occlusionFeature;

        private void Start()
        {
            // Initialize the Physical Occlusion feature
            occlusionFeature = OpenXRSettings.Instance.GetFeature<MagicLeapPhysicalOcclusionFeature>();
            
            if (occlusionFeature == null || !occlusionFeature.enabled)
            {
                Debug.LogError("Physical Occlusion feature must be enabled.");
                enabled = false;
                return;
            }
            
            // Enable occlusion and configure sources
            occlusionFeature.EnableOcclusion = true;
            occlusionFeature.EnabledOcclusionSource = _occlusionSource;

            // Configure depth sensor properties to the range specified in the inspector,
            // This will limit environment occlusion to this range as well
            occlusionFeature.DepthSensorNearRange = _nearRange;
            occlusionFeature.DepthSensorFarRange = _farRange;
        }
        
        private void OnDestroy()
        {
            if (occlusionFeature != null && occlusionFeature.enabled)
            {
                // Disable occlusion when the script is destroyed
                occlusionFeature.EnableOcclusion = false;
                occlusionFeature.EnabledOcclusionSource = 0;
            }
        }
    }
}
#endif
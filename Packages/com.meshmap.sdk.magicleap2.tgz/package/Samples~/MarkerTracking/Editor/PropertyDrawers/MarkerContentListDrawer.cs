// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using UnityEditor;
using UnityEngine;

namespace MeshMap.MagicLeap2.Samples.MarkerTracking.Editor
{
    [CustomPropertyDrawer(typeof(MarkerContent))]
    public class MarkerContentListDrawer : PropertyDrawer
    {
        private string _id = "Id";
        private string _contentField = "Content";

        private float _padding = 5f;
        private float _markerIDWidth = 150f;
        private float _contentFieldWidth = 250f;
        
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            SerializedProperty idProp = property.FindPropertyRelative(_id);
            SerializedProperty contentProp = property.FindPropertyRelative(_contentField);

            Rect markerIDRect = new Rect(position.x, position.y, _markerIDWidth, position.height);
            Rect contentRect = new Rect(position.x + _markerIDWidth + _padding, position.y, _contentFieldWidth, position.height);

            EditorGUI.PropertyField(markerIDRect, idProp, GUIContent.none);
            EditorGUI.PropertyField(contentRect, contentProp, GUIContent.none);
        }

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            // The height is the same for each row
            return EditorGUIUtility.singleLineHeight;
        }
    }
}
#endif
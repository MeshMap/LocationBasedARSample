// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using UnityEngine;
using UnityEngine.InputSystem;

namespace MeshMap.MagicLeap2.Samples.MarkerTracking
{
    /// <summary>
    /// Toggles the visibility of localization hint GameObjects based on input action.
    /// </summary>
    public class ToggleHints : MonoBehaviour
    {
        [SerializeField, Tooltip("The XR interaction to toggle hints.")]
        private InputActionProperty _throwActionProperty;

        [SerializeField, Tooltip("Array of GameObjects used as localization hints.")]
        private GameObject[] _localizationHints;
        
        [SerializeField, Tooltip("Whether hints should be visible at game start.")]
        private bool _visibleOnStart;
        
        private bool _visible = true;

        private void Awake()
        {
            _throwActionProperty.action.performed += Toggle;
        }

        private void OnDestroy()
        {
            _throwActionProperty.action.performed -= Toggle;
        }

        private void Start()
        {
            if (_visibleOnStart)
            {
                _visible = true;
            }
        }

        /// <summary>
        /// Toggles the active state of all localization hint GameObjects.
        /// </summary>
        /// <param name="context">Input callback context passed by the input system.</param>
        public void Toggle(InputAction.CallbackContext context)
        {
            foreach (var go in _localizationHints)
            {
                go.SetActive(!_visible);
            }

            _visible = !_visible;
        }
    }
}
#endif
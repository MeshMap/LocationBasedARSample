// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using System;
using UnityEngine;

namespace MeshMap.MagicLeap2.Samples.MarkerTracking
{
    /// <summary>
    /// Represents a pairing between a marker identifier and a corresponding anchor GameObject.
    /// </summary>
    [Serializable]
    public class MarkerAnchor
    {
        /// <summary>
        /// The unique identifier associated with the marker.
        /// </summary>
        public string Id;

        /// <summary>
        /// The anchor GameObject associated with the marker.
        /// </summary>
        public GameObject Anchor;
    }
}
#endif
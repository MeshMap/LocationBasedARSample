// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace MeshMap.MagicLeap2.Samples.MarkerTracking
{
    /// <summary>
    /// UI controller for managing the marker localization process,
    /// including progress panels, user input toggles, and orientation selection.
    /// </summary>
    public class MarkerTrackerUI : MonoBehaviour
    {
        [Header("Panels")]
        [SerializeField] private GameObject _localizationPanel;
        [SerializeField] private GameObject _localizationProgressPanel;

        [Header("Text")]
        [SerializeField] private TextMeshProUGUI _localizeText;

        [Header("Dropdown")]
        [SerializeField, Tooltip("UI dropdown for setting the marker orientation at runtime.")]
        private TMP_Dropdown _orientationDropdown;

        [Header("Toggles")]
        [SerializeField] private Toggle _xToggle;
        [SerializeField] private Toggle _yToggle;
        [SerializeField] private Toggle _zToggle;
        
        [Header("Buttons")]
        public Button StartButton;
        public Button CancelButton;

        /// <summary>
        /// Opens the localization progress panel and hides the main localization panel.
        /// </summary>
        public void OpenLocalizationProgressPanel()
        {
            _localizationProgressPanel.SetActive(true);
            _localizationPanel.SetActive(false);
        }

        /// <summary>
        /// Closes the localization progress panel and returns to the main localization panel.
        /// </summary>
        public void CloseLocalizationProgressPanel()
        {
            _localizationPanel.SetActive(true);
            _localizationProgressPanel.SetActive(false);
        }

        /// <summary>
        /// Closes the localization progress panel after a countdown delay,
        /// updating the UI text during the countdown.
        /// </summary>
        public IEnumerator CloseLocalizationProgressPanelAfterDelay()
        {
            // Hide the cancel button during countdown
            CancelButton.gameObject.SetActive(false);
            
            UpdateLocalizeText("Localization Complete.\nReturning to Main Menu in 3...");
            yield return new WaitForSeconds(1);
            UpdateLocalizeText("Localization Complete.\nReturning to Main Menu in 2...");
            yield return new WaitForSeconds(1);
            UpdateLocalizeText("Localization Complete.\nReturning to Main Menu in 1...");
            yield return new WaitForSeconds(1);

            CloseLocalizationProgressPanel();
            CancelButton.gameObject.SetActive(true);
        }

        /// <summary>
        /// Updates the UI text shown in the localization progress panel.
        /// </summary>
        public void UpdateLocalizeText(string text)
        {
            _localizeText.text = text;
        }

        /// <summary>
        /// Gets the currently selected marker orientation from the dropdown.
        /// </summary>
        /// <returns>The selected <see cref="MarkerOrientation"/>.</returns>
        public MarkerOrientation GetMarkerOrientation()
        {

            return (MarkerOrientation)_orientationDropdown.value;
        }

        /// <summary>
        /// Returns whether the X-axis toggle is enabled.
        /// </summary>
        public bool GetXToggle()
        {
            return _xToggle.isOn;
        }

        /// <summary>
        /// Returns whether the Y-axis toggle is enabled.
        /// </summary>
        public bool GetYToggle()
        {
            return _yToggle.isOn;
        }

        /// <summary>
        /// Returns whether the Z-axis toggle is enabled.
        /// </summary>
        public bool GetZToggle()
        {
            return _zToggle.isOn;
        }
    }
}
#endif
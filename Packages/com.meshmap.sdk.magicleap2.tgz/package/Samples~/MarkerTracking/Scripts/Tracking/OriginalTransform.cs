// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using UnityEngine;

namespace MeshMap.MagicLeap2.Samples.MarkerTracking
{
    /// <summary>
    /// Represents the original position and rotation of a transform.
    /// Used to store and restore the initial state of objects during localization.
    /// </summary>
    public class OriginalTransform
    {
        /// <summary>
        /// The original position of the transform in world space.
        /// </summary>
        public Vector3 Position;

        /// <summary>
        /// The original rotation of the transform in world space.
        /// </summary>
        public Quaternion Rotation;
        
        /// <summary>
        /// Initializes a new instance of the <see cref="OriginalTransform"/> class
        /// with the specified position and rotation.
        /// </summary>
        /// <param name="position">The position to store.</param>
        /// <param name="rotation">The rotation to store.</param>
        public OriginalTransform(Vector3 position, Quaternion rotation)
        {
            Position = position;
            Rotation = rotation;
        }
    }
}
#endif
// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.XR.OpenXR;
using MagicLeap.OpenXR.Features.MarkerUnderstanding;
using VContainer;

namespace MeshMap.MagicLeap2.Samples.MarkerTracking
{
    /// <summary>
    /// Controls marker tracking and content localization using the Magic Leap Marker Understanding feature.
    /// Handles marker detection, content activation, and user-driven localization flow.
    /// </summary>
    public class MarkerTrackingControls : MonoBehaviour
    {
        public static event Action<GameObject> OnLocalizationCompleted;
        
        public List<MarkerAnchor> MarkerAnchorList;
        private Dictionary<string, GameObject> _markerAnchorDict = new();
        
        public List<MarkerContent> MarkerContentList;
        private Dictionary<string, GameObject> _markerContentDict = new();
        
        [Header("Content Settings")]
        [SerializeField, Tooltip("Hide content until any of its corresponding markers has been localized.")] private bool _hideContentUntilLocalizedOnce = true;
        
        [Header("Marker Detector Settings")]
        [SerializeField] private MarkerDetectorProfile _markerDetectorProfile = MarkerDetectorProfile.Accuracy;
        [SerializeField] private MarkerType _markerType = MarkerType.AprilTag;
        [SerializeField, Tooltip("Additional setting required for AprilTags only.")] private AprilTagType _aprilTagType = AprilTagType.Dictionary_36H11;
        [SerializeField, Tooltip("Additional setting required for ArUco markers only.")] private ArucoType _arucoType = ArucoType.Dictionary_7x7_50;
        [SerializeField, Tooltip("The expected size of the marker in centimeters.")] private float _markerSize = 0.17f;
        [SerializeField, Tooltip("Whether the content should be rescaled based on marker size. This setting is optional.")] private bool _estimateSize = false;
        private MagicLeapMarkerUnderstandingFeature _markerFeature;
        private MarkerDetectorSettings _markerDetectorSettings;
        
        [Header("Additional Localization Settings")]
        [SerializeField, Tooltip("The characters preceding the encoded markerID. This setting is optional.")] private string _markerEncodedSubstring = null;
        
        [SerializeField, Range(10, 200), Tooltip("Number of steps to localize content.")] private int _localizationSteps = 200;
        private int _currentLocalizationStep = 0;
        private bool _localizationInProgress = false;
        
        private MarkerDetector _currentDetector;
        protected string _currentMarkerID = null;
        private GameObject _currentAnchor;
        private GameObject _currentContent;
        private Vector3 _previousAnchorPosition = Vector3.zero;
        private Quaternion _previousAnchorRotation = Quaternion.identity;
        private Vector3 _previousContentPosition = Vector3.zero;
        private Quaternion _previousContentRotation = Quaternion.identity;
        private bool _previousTransformsCached = false;
        private Transform _originalAnchorParent;
        private Transform _originalContentParent;

        private MarkerOrientation _orientation = MarkerOrientation.Flat;

        /// <summary>
        /// The UI controller injected via VContainer.
        /// </summary>
        [Inject] private MarkerTrackerUI _markerTrackerUI;

        protected virtual void Start()
        {
            _markerTrackerUI.StartButton.onClick.AddListener(StartLocalization);
            _markerTrackerUI.CancelButton.onClick.AddListener(StopLocalization);
            
            _markerFeature = OpenXRSettings.Instance.GetFeature<MagicLeapMarkerUnderstandingFeature>();

            PopulateDicts();
            
            if (_hideContentUntilLocalizedOnce)
            {
                HideContent();
            }

            CreateDetector();
        }
        
        private void OnDestroy()
        {
            _markerTrackerUI.StartButton.onClick.RemoveListener(StartLocalization);
            _markerTrackerUI.CancelButton.onClick.RemoveListener(StopLocalization);
            
            _markerFeature.DestroyAllMarkerDetectors();
        }

        private void Update()
        {
            if (_localizationInProgress)
            {
                FindMarker();
            }
        }

        /// <summary>
        /// Converts the anchor and content lists to dictionaries for fast lookup by marker ID.
        /// </summary>
        private void PopulateDicts()
        {
            _markerAnchorDict.Clear();
            foreach (var pair in MarkerAnchorList)
            {
                _markerAnchorDict[pair.Id] = pair.Anchor;
            }
            
            _markerContentDict.Clear();
            foreach (var pair in MarkerContentList)
            {
                _markerContentDict[pair.Id] = pair.Content;
            }
        }
        
        /// <summary>
        /// Hides all unique marker content objects until localization is triggered.
        /// </summary>
        private void HideContent()
        {
            var uniqueContent = _markerContentDict.Values.Distinct().ToList();
            foreach (var content in uniqueContent)
            {
                content.SetActive(false);
            }
        }

        /// <summary>
        /// Creates a marker detector using the selected profile, marker type, and type-specific settings.
        /// </summary>
        private void CreateDetector()
        {
            // Apply the marker detector settings
            _markerDetectorSettings.MarkerDetectorProfile = _markerDetectorProfile;
            _markerDetectorSettings.MarkerType = _markerType;

            // Apply the marker detector settings that are specific to marker type
            switch (_markerType)
            {
                case MarkerType.AprilTag:
                    _markerDetectorSettings.AprilTagSettings.AprilTagType = _aprilTagType;
                    _markerDetectorSettings.AprilTagSettings.AprilTagLength = _markerSize;
                    _markerDetectorSettings.AprilTagSettings.EstimateAprilTagLength = _estimateSize;
                    break;

                case MarkerType.Aruco:
                    _markerDetectorSettings.ArucoSettings.ArucoType = _arucoType;
                    _markerDetectorSettings.ArucoSettings.ArucoLength = _markerSize;
                    _markerDetectorSettings.ArucoSettings.EstimateArucoLength = _estimateSize;
                    break;

                case MarkerType.QR:
                    _markerDetectorSettings.QRSettings.QRLength = _markerSize;
                    _markerDetectorSettings.QRSettings.EstimateQRLength = _estimateSize;
                    break;

                default:
                    //Debug.LogWarning($"The {_markerType} marker type is not fully supported. Switching to AprilTag or QR is recommended.");
                    break;
            }
            
            // Create the detector
            _markerFeature.CreateMarkerDetector(_markerDetectorSettings);
        }

        /// <summary>
        /// Begins the localization process by resetting internal states and showing progress UI.
        /// </summary>
        public virtual void StartLocalization()
        {
            if (_localizationInProgress)
            {
                return;
            }

            // Get the orientation of the marker set by the user in the game UI
            _orientation = _markerTrackerUI.GetMarkerOrientation();
            
            // Prepare to show progress
            _markerTrackerUI.UpdateLocalizeText($"Please look at the {_markerType} marker.");
            _markerTrackerUI.OpenLocalizationProgressPanel();

            // Reset all values to be safe
            _currentLocalizationStep = 0;
            _currentMarkerID = null;
            _currentAnchor = null;
            _currentContent = null;
            _previousAnchorPosition = Vector3.zero;
            _previousAnchorRotation = Quaternion.identity;
            _previousContentPosition = Vector3.zero;
            _previousContentRotation = Quaternion.identity;
            _previousTransformsCached = false;
            _localizationInProgress = true;
        }

        /// <summary>
        /// Finds markers using the marker detectors and updates anchor and content transforms accordingly.
        /// </summary>
        private void FindMarker()
        {
            _markerFeature.UpdateMarkerDetectors();

            // Iterate through all of the marker detectors
            for (int i = 0; i < _markerFeature.MarkerDetectors.Count; i++)
            {
                //Verify that the marker detector is running
                if (_markerFeature.MarkerDetectors[i].Status == MarkerDetectorStatus.Ready)
                {
                    _currentDetector = _markerFeature.MarkerDetectors[i];

                    // Iterate through all the detected markers
                    for (int j = 0; j < _currentDetector.Data.Count; j++)
                    {
                        var markerData = _currentDetector.Data[j];
                        
                        // Check whether the marker has valid pose data
                        if (markerData.MarkerPose.HasValue)
                        {
                            string markerID = string.Empty;

                            // Extract the id depending on what type of marker it is, since QR codes are able to encode more
                            if (_markerType == MarkerType.AprilTag || _markerType == MarkerType.Aruco)
                            {
                                markerID = markerData.MarkerNumber.ToString();
                            }
                            else if (_markerType == MarkerType.QR)
                            {
                                markerID = string.IsNullOrEmpty(_markerEncodedSubstring)
                                        ? markerData.MarkerString
                                        : markerData.MarkerString.Substring(markerData.MarkerString.IndexOf(_markerEncodedSubstring) + _markerEncodedSubstring.Length);
                            }

                            // Check whether the marker ID matches the current marker, if there is one (i.e., after a successful localization step)
                            if (_currentMarkerID != null && markerID == _currentMarkerID)
                            {
                                LocalizeContent(_currentAnchor.transform, _currentContent.transform, markerData.MarkerPose.Value);
                            }
                            // Else, check whether we have a corresponding marker game object associated with this marker ID
                            else if (_markerAnchorDict.TryGetValue(markerID, out var correspondingAnchor))
                            {
                                _currentMarkerID = markerID;
                                // Cache reference to the current anchor
                                _currentAnchor = correspondingAnchor;
                                // Get reference to the current content
                                _currentContent = _markerContentDict[markerID];
                                // Show content in case it was hidden on start
                                _currentContent.SetActive(true);

                                // Cache the previous transform on the first localization step only
                                // This enables cancelling localization and restoring the previous position (including any calibration)
                                if (!_previousTransformsCached)
                                {
                                    _previousAnchorPosition = _currentAnchor.transform.position;
                                    _previousAnchorRotation = _currentAnchor.transform.rotation;
                                    _previousContentPosition = _currentContent.transform.position;
                                    _previousContentRotation = _currentContent.transform.rotation;
                                    _previousTransformsCached = true;
                                }
                                
                                // Pass the current anchor, content, and marker pose to the localization method
                                LocalizeContent(_currentAnchor.transform, _currentContent.transform, markerData.MarkerPose.Value);
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Performs a localization step for the specified anchor and content using the given marker pose.
        /// Updates position and rotation progressively over multiple steps.
        /// </summary>
        /// <param name="anchor">The marker anchor transform to update.</param>
        /// <param name="content">The content transform associated with the marker.</param>
        /// <param name="markerPose">The pose of the detected marker.</param>
        protected virtual void LocalizeContent(Transform anchor, Transform content, Pose markerPose)
        {
            // Increment the localization step and update the progress UI
            _currentLocalizationStep++;
            _markerTrackerUI.UpdateLocalizeText($"Localization: {Mathf.RoundToInt((_currentLocalizationStep / ((float)_localizationSteps)) * 100)}% Complete.");
            
            // Store original parents and reparent on first step
            if (_currentLocalizationStep == 1)
            {
                _originalAnchorParent = anchor.parent;
                _originalContentParent = content.parent;

                anchor.SetParent(content.parent, true);
                content.SetParent(anchor, true);
            }
            
            // Update the anchor's position and rotation
            anchor.position = markerPose.position;
            anchor.rotation = markerPose.rotation;
            
            // Rotate further 90 degrees on the x axis if the marker orientation is flat
            if (_orientation == MarkerOrientation.Flat)
            {
                anchor.rotation *= Quaternion.AngleAxis(-90, Vector3.right);
            }
            
            // On the last step
            if (_currentLocalizationStep >= _localizationSteps)
            {
                // Nullify any specified rotations
                anchor.eulerAngles = NullXYZRotation(anchor.eulerAngles);
                
                // Restore parent relationships
                content.SetParent(_originalContentParent, true);
                anchor.SetParent(_originalAnchorParent, true);

                // Finish
                ResetLocalizationStatus();
                OnLocalizationCompleted?.Invoke(_currentContent);
                _currentAnchor = null;
                _currentContent = null;
                StartCoroutine(_markerTrackerUI.CloseLocalizationProgressPanelAfterDelay());
            }
        }

        /// <summary>
        /// Sets any frozen axes (selected in the UI) of the given rotation vector to zero.
        /// </summary>
        /// <param name="rotation">The original Euler angles.</param>
        /// <returns>The Euler angles with frozen axes zeroed out.</returns>
        private Vector3 NullXYZRotation(Vector3 rotation)
        {
            float x = rotation.x;
            float y = rotation.y;
            float z = rotation.z;

            // Set any frozen axes (selected in the UI) to 0
            if (_markerTrackerUI.GetXToggle())
            {
                x = 0;
            }
            if (_markerTrackerUI.GetYToggle())
            {
                y = 0;
            }
            if (_markerTrackerUI.GetZToggle())
            {
                z = 0;
            }
            return new Vector3(x, y, z);
        }

        /// <summary>
        /// Stops the localization process and restores content to its previous position and rotation.
        /// </summary>
        public void StopLocalization()
        {
            if (!_localizationInProgress)
            {
                return;
            }
            ResetLocalizationStatus();
            StartCoroutine(RestoreToPrevious());
            _markerTrackerUI.CloseLocalizationProgressPanel();
        }

        /// <summary>
        /// Resets the internal localization status and clears related state variables.
        /// </summary>
        private void ResetLocalizationStatus()
        {
            _currentLocalizationStep = 0;
            _localizationInProgress = false;
            _currentMarkerID = null;
        }

        /// <summary>
        /// Coroutine to restore anchor and content to their previous transforms if localization was cancelled.
        /// </summary>
        protected virtual IEnumerator RestoreToPrevious()
        {
            // Wait one frame to be sure that the marker localization process is fully stopped
            yield return new WaitForEndOfFrame();
            
            // If the localization process had already identified content to move and cached its data, move it back to its previous position and rotation
            if (_currentContent && _previousTransformsCached)
            {
                _currentContent.transform.SetParent(_originalContentParent, true);
                _currentAnchor.transform.SetParent(_originalAnchorParent, true);
                
                _currentContent.transform.position = _previousContentPosition;
                _currentContent.transform.rotation = _previousContentRotation;

                _currentAnchor.transform.position = _previousAnchorPosition;
                _currentAnchor.transform.rotation = _previousAnchorRotation;
            }
            
            // Reset all values to be safe
            _currentAnchor = null;
            _currentContent = null;
            _previousAnchorPosition = Vector3.zero;
            _previousAnchorRotation = Quaternion.identity;
            _previousContentPosition = Vector3.zero;
            _previousContentRotation = Quaternion.identity;
            _previousTransformsCached = false;
        }
    }
}
#endif
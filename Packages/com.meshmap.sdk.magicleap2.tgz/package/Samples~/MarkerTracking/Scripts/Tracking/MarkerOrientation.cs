// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
namespace MeshMap.MagicLeap2.Samples.MarkerTracking
{
    /// <summary>
    /// Defines the orientation of a tracked marker relative to the environment. <c>Flat</c> or <c>Upright</c>.
    /// </summary>
    public enum MarkerOrientation
    {
        /// <summary>
        /// Marker is positioned flat, typically lying horizontally on the floor, table, or other surface.
        /// </summary>
        Flat,
        
        /// <summary>
        /// Marker is positioned upright, typically on a wall.
        /// </summary>
        Upright
    }
}
#endif
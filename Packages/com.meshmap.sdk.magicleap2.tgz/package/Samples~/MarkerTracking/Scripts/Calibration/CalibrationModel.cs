// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using System;
using UnityEngine;

namespace MeshMap.MagicLeap2.Samples.MarkerTracking
{
    /// <summary>
    /// Manages calibration adjustments for localized AR content.
    /// Provides methods to manipulate position and rotation offsets and broadcasts changes via events.
    /// </summary>
    public class CalibrationModel: MonoBehaviour
    {
        public static event Action<float> OnXPosDiffChanged;
        public static event Action<float> OnYPosDiffChanged;
        public static event Action<float> OnZPosDiffChanged;
        public static event Action<float> OnXRotDiffChanged;
        public static event Action<float> OnYRotDiffChanged;
        public static event Action<float> OnZRotDiffChanged;

        [SerializeField, Range(0.01f, 1f)] private float _increment = 0.05f;

        private float _xPosDiff;
        private float _yPosDiff;
        private float _zPosDiff;
        private float _xRotDiff;
        private float _yRotDiff;
        private float _zRotDiff;

        private GameObject _currentContent;
        private Vector3 _initialPos;
        private Quaternion _initialRot;

        private void Start()
        {
            MarkerTrackingControls.OnLocalizationCompleted += SetContent;
        }

        private void OnDestroy()
        {
            MarkerTrackingControls.OnLocalizationCompleted -= SetContent;
        }

        /// <summary>
        /// Sets the offset value and invokes the corresponding change event.
        /// </summary>
        private void SetDiff(ref float diff, float value, Action<float> eventCallback)
        {
            if (Mathf.Approximately(diff, value)) return;
            
            diff = value;
            eventCallback?.Invoke(diff);
        }
        
        // Internal property wrappers for broadcasting diff changes
        private float XPosDiff { get => _xPosDiff; set => SetDiff(ref _xPosDiff, value, OnXPosDiffChanged); }
        private float YPosDiff { get => _yPosDiff; set => SetDiff(ref _yPosDiff, value, OnYPosDiffChanged); }
        private float ZPosDiff { get => _zPosDiff; set => SetDiff(ref _zPosDiff, value, OnZPosDiffChanged); }
        private float XRotDiff { get => _xRotDiff; set => SetDiff(ref _xRotDiff, value, OnXRotDiffChanged); }
        private float YRotDiff { get => _yRotDiff; set => SetDiff(ref _yRotDiff, value, OnYRotDiffChanged); }
        private float ZRotDiff { get => _zRotDiff; set => SetDiff(ref _zRotDiff, value, OnZRotDiffChanged); }
        
        /// <summary>
        /// Resets all position and rotation offset values to zero.
        /// </summary>
        private void ResetCalibrationData()
        {
            XPosDiff = 0;
            YPosDiff = 0;
            ZPosDiff = 0;
            XRotDiff = 0;
            YRotDiff = 0;
            ZRotDiff = 0;
        }

        /// <summary>
        /// Assigns the localized content GameObject and stores its initial transform.
        /// </summary>
        /// <param name="go">Localized GameObject.</param>
        public void SetContent(GameObject go)
        {
            ResetCalibrationData();
            
            _currentContent = go;
            _initialPos = go.transform.position;
            _initialRot = go.transform.rotation;
        }
        
        /// <summary>
        /// Resets the content to its original calibrated transform and zeroes out offsets.
        /// </summary>
        public void ResetPrecalibratedState()
        {
            if (!_currentContent) return;
            
            _currentContent.transform.position = _initialPos;
            _currentContent.transform.rotation = _initialRot;
            
            ResetCalibrationData();
        }
        
        /// <summary>
        /// Translates the content in the specified direction.
        /// </summary>
        /// <param name="direction">Normalized direction vector.</param>
        private void MoveContent(Vector3 direction)
        {
            _currentContent.transform.Translate(direction * _increment);
        }

        /// <summary>
        /// Rotates the content around the specified axis.
        /// </summary>
        /// <param name="axis">Rotation axis.</param>
        private void RotateContent(Vector3 axis)
        {
            _currentContent.transform.Rotate(axis * _increment);
        }

        /// <summary>
        /// Increases the X position offset and moves the content.
        /// </summary>
        public void IncreaseXPosDiff()
        {
            if (!_currentContent) return;
            MoveContent(Vector3.right);
            XPosDiff += _increment;
        }

        /// <summary>
        /// Decreases the X position offset and moves the content.
        /// </summary>
        public void DecreaseXPosDiff()
        {
            if (!_currentContent) return;
            MoveContent(Vector3.left);
            XPosDiff -= _increment;
        }

        /// <summary>
        /// Increases the Y position offset and moves the content.
        /// </summary>
        public void IncreaseYPosDiff()
        {
            if (!_currentContent) return;
            MoveContent(Vector3.up);
            YPosDiff += _increment;
        }

        /// <summary>
        /// Decreases the Y position offset and moves the content.
        /// </summary>
        public void DecreaseYPosDiff()
        {
            if (!_currentContent) return;
            MoveContent(Vector3.down);
            YPosDiff -= _increment;
        }

        /// <summary>
        /// Increases the Z position offset and moves the content.
        /// </summary>
        public void IncreaseZPosDiff()
        {
            if (!_currentContent) return;
            MoveContent(Vector3.forward);
            ZPosDiff += _increment;
        }

        /// <summary>
        /// Decreases the Z position offset and moves the content.
        /// </summary>
        public void DecreaseZPosDiff()
        {
            if (!_currentContent) return;
            MoveContent(Vector3.back);
            ZPosDiff -= _increment;
        }
        
        /// <summary>
        /// Increases the X rotation offset and rotates the content.
        /// </summary>
        public void IncreaseXRotDiff()
        {
            if (!_currentContent) return;
            RotateContent(Vector3.right);
            XRotDiff += _increment;
        }

        /// <summary>
        /// Decreases the X rotation offset and rotates the content.
        /// </summary>
        public void DecreaseXRotDiff()
        {
            if (!_currentContent) return;
            RotateContent(Vector3.left);
            XRotDiff -= _increment;
        }

        /// <summary>
        /// Increases the Y rotation offset and rotates the content.
        /// </summary>
        public void IncreaseYRotDiff()
        {
            if (!_currentContent) return;
            RotateContent(Vector3.up);
            YRotDiff += _increment;
        }

        /// <summary>
        /// Decreases the Y rotation offset and rotates the content.
        /// </summary>
        public void DecreaseYRotDiff()
        {
            if (!_currentContent) return;
            RotateContent(Vector3.down);
            YRotDiff -= _increment;
        }

        /// <summary>
        /// Increases the Z rotation offset and rotates the content.
        /// </summary>
        public void IncreaseZRotDiff()
        {
            if (!_currentContent) return;
            RotateContent(Vector3.forward);
            ZRotDiff += _increment;
        }

        /// <summary>
        /// Decreases the Z rotation offset and rotates the content.
        /// </summary>
        public void DecreaseZRotDiff()
        {
            if (!_currentContent) return;
            RotateContent(Vector3.back);
            ZRotDiff -= _increment;
        }
        
        /// <summary>
        /// Gets the current position offset vector.
        /// </summary>
        public Vector3 GetPositionData()
        {
            return new Vector3(XPosDiff, YPosDiff, ZPosDiff);
        }

        /// <summary>
        /// Gets the current rotation offset as a quaternion.
        /// </summary>
        public Quaternion GetRotationData()
        {
            return Quaternion.Euler(XRotDiff, YRotDiff, ZRotDiff);
        }
    }
}
#endif
// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using System;
using UnityEngine;
using TMPro;

namespace MeshMap.MagicLeap2.Samples.MarkerTracking
{
    /// <summary>
    /// Displays real-time calibration offset values in the UI for position and rotation.
    /// </summary>
    public class CalibrationView : MonoBehaviour
    {
        [Header("Position Texts")]
        [SerializeField] private TextMeshProUGUI _xPosDiffText;
        [SerializeField] private TextMeshProUGUI _yPosDiffText;
        [SerializeField] private TextMeshProUGUI _zPosDiffText;
        
        [Header("Rotation Texts")]
        [SerializeField] private TextMeshProUGUI _xRotDiffText;
        [SerializeField] private TextMeshProUGUI _yRotDiffText;
        [SerializeField] private TextMeshProUGUI _zRotDiffText;
        
        // Store delegate references so we can unsubscribe later
        private Action<float> _xPosDiffChangedListener;
        private Action<float> _yPosDiffChangedListener;
        private Action<float> _zPosDiffChangedListener;
        private Action<float> _xRotDiffChangedListener;
        private Action<float> _yRotDiffChangedListener;
        private Action<float> _zRotDiffChangedListener;

        private string _format = "F2";

        private void Start()
        {
            // Define the delegate lambdas and store them for unsubscribing later
            _xPosDiffChangedListener = (value) => UpdateDiffText(_xPosDiffText, value);
            _yPosDiffChangedListener = (value) => UpdateDiffText(_yPosDiffText, value);
            _zPosDiffChangedListener = (value) => UpdateDiffText(_zPosDiffText, value);
            
            _xRotDiffChangedListener = (value) => UpdateDiffText(_xRotDiffText, value);
            _yRotDiffChangedListener = (value) => UpdateDiffText(_yRotDiffText, value);
            _zRotDiffChangedListener = (value) => UpdateDiffText(_zRotDiffText, value);
            
            // Subscribe to events
            CalibrationModel.OnXPosDiffChanged += _xPosDiffChangedListener;
            CalibrationModel.OnYPosDiffChanged += _yPosDiffChangedListener;
            CalibrationModel.OnZPosDiffChanged += _zPosDiffChangedListener;

            CalibrationModel.OnXRotDiffChanged += _xRotDiffChangedListener;
            CalibrationModel.OnYRotDiffChanged += _yRotDiffChangedListener;
            CalibrationModel.OnZRotDiffChanged += _zRotDiffChangedListener;
        }

        private void OnDestroy()
        {
            // Unsubscribe using the stored delegate references
            CalibrationModel.OnXPosDiffChanged -= _xPosDiffChangedListener;
            CalibrationModel.OnYPosDiffChanged -= _yPosDiffChangedListener;
            CalibrationModel.OnZPosDiffChanged -= _zPosDiffChangedListener;

            CalibrationModel.OnXRotDiffChanged -= _xRotDiffChangedListener;
            CalibrationModel.OnYRotDiffChanged -= _yRotDiffChangedListener;
            CalibrationModel.OnZRotDiffChanged -= _zRotDiffChangedListener;
        }

        /// <summary>
        /// Updates the given TextMeshProUGUI element with a formatted string representation of the offset value.
        /// </summary>
        /// <param name="text">The TextMeshProUGUI element to update.</param>
        /// <param name="diff">The offset value to display.</param>
        private void UpdateDiffText(TextMeshProUGUI text, float diff)
        {
            // Allow some room for error introduced by floats
            if (diff is < 0.001f and > -0.001f)
            {
                text.text = "0";
            }
            else if (diff > 0)
            {
                text.text = "+" + diff.ToString(_format);
            }
            else
            {
                text.text = diff.ToString(_format);
            }
        }
    }
}
#endif
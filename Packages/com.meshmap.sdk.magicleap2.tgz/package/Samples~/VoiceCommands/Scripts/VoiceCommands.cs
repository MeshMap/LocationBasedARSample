// Copyright 2025 MeshMap Labs Inc.
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// 
//    http://www.apache.org/licenses/LICENSES-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permission and
// limitations under the License.

#if MAGICLEAP
using UnityEngine;
using UnityEngine.XR.MagicLeap;
using MagicLeap.Android;

namespace MeshMap.MagicLeap2.Samples.VoiceCommands
{
    /// <summary>
    /// Initializes and manages Magic Leap voice command intents using a configuration file.
    /// Handles permission requests, subscribes to voice intent events, and maps specific commands to actions like menu toggling or object movement.
    /// Make sure to enable all Voice Commands settings in the Project settings, On-device app settings, and in the Device Settings.
    /// </summary>
    public class VoiceCommands : MonoBehaviour
    {
        [SerializeField, Tooltip("Configuration file that holds list of voice commands.")]
        private MLVoiceIntentsConfiguration _voiceConfiguration;

        [Header("Example Method Dependencies")]
        [SerializeField] private GameObject _menu;
        [SerializeField] private GameObject _cube;
        [SerializeField] private GameObject _sphere;
        
        private void Start()
        {
            if (Permissions.CheckPermission(Permissions.VoiceInput))
            {
                Debug.Log("Voice input permission already enabled.");
                InitializeVoiceConfiguration();
            }
            else
            {
                Debug.Log("Voice input permission requested.");
                Permissions.RequestPermission(Permissions.VoiceInput, OnPermissionGranted, OnPermissionDenied);
            }
        }
        
        // Stop the service and disable the event when the script is destroyed.
        private void OnDestroy()
        {
            MLVoice.Stop();
            MLVoice.OnVoiceEvent -= OnVoiceEvent;
        }
        
        private void OnPermissionDenied(string permission)
        {
            Debug.Log($"{permission} denied. Voice Intents will not be available.");
            enabled = false;
        }

        private void OnPermissionGranted(string permission)
        {
            if (!permission.Equals(Permissions.VoiceInput))
            {
                return;
            }
            Debug.Log($"{permission} granted.");
            InitializeVoiceConfiguration();
        }
        
        /// <summary>
        /// Sets up the Magic Leap voice intent system using the specified configuration.
        /// Subscribes to voice command events on success.
        /// </summary>
        private void InitializeVoiceConfiguration()
        {
            MLResult result = MLVoice.SetupVoiceIntents(_voiceConfiguration);
            if (result.IsOk)
            {
                Debug.Log("Voice intent setup successful.");
                // Subscribe to the voice command event
                MLVoice.OnVoiceEvent += OnVoiceEvent;
            }
            else
            {
                Debug.LogError("Failed to Setup Voice Intents with result: " + result);
            }
        }
        
        /// <summary>
        /// Callback for voice events. Routes specific intent IDs and slot values to actions (e.g., opening menus, moving objects).
        /// </summary>
        /// <param name="wasSuccessful">Whether the voice recognition was successful.</param>
        /// <param name="voiceEvent">The intent event containing ID and slot data.</param>
        private void OnVoiceEvent(in bool wasSuccessful, in MLVoice.IntentEvent voiceEvent)
        {
            Debug.Log($"Detected Voice Command: {voiceEvent.EventName} (ID: {voiceEvent.EventID}.\n" +
                      $"Was Successful: {wasSuccessful}\n" +
                      $"State: {voiceEvent.State}\n)");

            // Open menu
            if (voiceEvent.EventID == 100)
            {
                ToggleMenu(true);
            }
            // Close menu
            else if (voiceEvent.EventID == 101)
            {
                ToggleMenu(false);
            }
            // Move object in direction
            else if (voiceEvent.EventID == 102)
            {
                GameObject go = null;
                Vector3 direction = Vector3.zero;
                MLVoice.EventSlot[] slotData = voiceEvent.EventSlotsUsed.ToArray();
                foreach (MLVoice.EventSlot slot in slotData)
                {
                    if (slot.SlotName == "Object")
                    {
                        switch (slot.SlotValue)
                        {
                            case "Cube":
                                go = _cube;
                                break;
                            case "Sphere":
                                go = _sphere;
                                break;
                        }
                    }

                    if (slot.SlotName == "Direction")
                    {
                        switch (slot.SlotValue)
                        {
                            case "Right":
                                direction = Vector3.right;
                                break;
                            case "Left":
                                direction = Vector3.left;
                                break;
                            case "Up":
                                direction = Vector3.up;
                                break;
                            case "Down":
                                direction = Vector3.down;
                                break;
                            case "Forward":
                                direction = Vector3.forward;
                                break;
                            case "Back":
                                direction = Vector3.back;
                                break;
                            case "Backward":
                                direction = Vector3.back;
                                break;
                        }
                    }
                }

                if (go != null && direction != Vector3.zero)
                {
                    MoveObject(go, direction);
                }
                else
                {
                    Debug.LogError("Invalid object or direction.");
                }
            }
        }

        private void ToggleMenu(bool active)
        {
            _menu.SetActive(active);
        }

        private void MoveObject(GameObject go, Vector3 direction)
        {
            go.transform.position += direction;
        }
    }
}
#endif
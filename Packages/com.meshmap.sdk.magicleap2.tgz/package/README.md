# MeshMap Magic Leap 2 Support

> [!IMPORTANT]
> As of v0.1.0, this package uses a minimally modified version of the Magic Leap SDK to prevent compilation errors when building for multiple target XR devices. In accordance with the [Magic Leap 2 Software License Agreement](https://www.magicleap.com/legal/software-license-agreement-ml2), the package is included in our [ML2 Samples project](https://github.com/MeshMap/mmsdk-samples-magicleap2), but not redistributed solely on its own.

Current version: 0.2.0-pre.2

Last updated: 24 September 2025

[Changelog](https://github.com/MeshMap/com.meshmap.sdk.magicleap2/blob/main/CHANGELOG.md)

[Documentation](https://docs.meshmap.com/unity-sdk/magic-leap-2-support)

---

## Description

The MeshMap Magic Leap 2 Support package contains sample assets for creating location-based AR experiences with the Magic Leap 2 in Unity.

The goal is to provide Unity developers of all skill levels with tools that simplify and accelerate their workflow from weeks to minutes.

---

## Features

- Localize using Magic Leap Spaces.
- Localize using markers (AprilTags, ArUco markers, and QR codes).
- Calibrate localized content using a simple UI tool.
- Position content across sessions using Magic Leap 2 Spatial Anchors Subsystem.
- Enable near and far occlusion using the Magic Leap 2 Physical Occlusion Feature.
- Adjust Global Dimming with a slider.
- Check user headset fit and eye calibration status.
- Get eye tracker data and eye gaze data.
- Add custom voice commands.

---

## Requirements

- **Unity 2022.3.11 LTS** or later
- Android Build Support
- Universal Render Pipeline (URP)

---

## Package Dependencies

- Unity TextMeshPro v3.0.7
- Unity Input System v1.11.2
- Unity XR Interaction Toolkit v2.6.3
- Unity OpenXR v.1.3.0
- [VContainer v1.16.8](https://github.com/hadashiA/VContainer) (`jp.hadashikick.vcontainer`)
- Magic Leap SDK v2.6.0-pre.R15-meshmap (`com.magicleap.unitysdk`)
- [MeshMap Building Blocks v0.0.13](https://github.com/MeshMap/mmsdk-buildingblocks-upm) (`com.meshmap.sdk.bb`)

---

## Getting Started

*Requires Unity 2022.3.11 or higher with Android Build Support module. This can be installed via [Unity Hub](https://unity.com/unity-hub).*

### For beginners (easiest, read-only)

1. Download the [Magic Leap 2](https://github.com/MeshMap/mmsdk-samples-magicleap2) sample Unity project which already includes the necessary settings, dependencies, and sample scenes.
2. Open the project in Unity Editor.

### For existing projects (read-only)

1. Open your project in Unity Editor.
2. In the `Packages/manifest.json` file, add the `openupm` scoped registry for `vcontainer`. Alternatively, you can do this in the Editor by going to Edit > Project Settings > Package Manager > Scoped Registries and adding the information below.

   ```json
   "scopedRegistries": [
      {
         "name": "package.openupm.com",
         "url": "https://package.openupm.com",
         "scopes": [
            "jp.hadashikick.vcontainer"
         ]
      }
   ],
   ```
3. Go to Window > Package Manager > *(click the + dropdown icon in the top-left of the Package Manager window)* > Add Package from git URL...
4. Copy and paste `https://github.com/MeshMap/mmsdk-magicleap2-upm.git`, then click Add.
   - If you want to import a specific version, include the release number. For example, `https://github.com/MeshMap/mmsdk-magicleap2-upm.git#v0.0.1`
   - If your import permission is denied because you are using Mac, try using this path instead `git@github.com:MeshMap/mmsdk-magicleap2-upm.git#v0.0.1`
   - If your import permission is denied because this is a private repo, then add an [SSH key to your GitHub account](https://docs.github.com/en/authentication/connecting-to-github-with-ssh/adding-a-new-ssh-key-to-your-github-account).

### For contributors (read and write)

1. Follow steps 1 & 2 above.
2. Clone this repository to your computer and create a new local branch.
3. In the `Packages/manifest.json` file, add a dependency reference to the cloned repository.<br>By adding it in this way rather than via git URL, Unity will treat the SDK as an editable part of the project even though it's located outside the project folder. You can repeat this step across all your projects using the SDK and the edits will always sync properly. This eliminates the chance of any potential code conflicts that may arise if you also use git version control for your Unity projects.

   ```json
   {
      "dependencies": {
         "com.meshmap.sdk.magicleap2": "file:/path/to/mmsdk-magicleap2-upm/"
      }
   }
   ```

---

## Basic Usage

After import, the files should be available in the `Packages` section of the `Project` window in Unity Editor.

Editor windows and tools can be accessed under the `MeshMap` section of the toolbar at the top of the Unity Editor.

For contributors, rename the `Samples~` folder to `Samples` **before** making changes to the Samples assets. You may need to delete the samples from your `Assets` folder if they are already imported. Then, add the `~` back in and reimport the samples before committing changes to the main branch. This ensures that contributions are properly synced in the package and GUIDs are not mismatched.

*Note: The files will not work outside the `Packages` section due to dependencies and assembly definitions that are specific to the Editor and Runtime, so be sure to import them correctly using one of the processes described above.*

---

## Permissions

Make sure you enable all required permissions for the OpenXR and Magic Leap 2 features that your app uses.

Before building (in Unity):

- In **Project Settings > Player > Android > Other Settings**, make sure the Vulkan Graphics API, DXTC texture compression format, minimum API level Android 10.0 (API level 29), IL2CPP scripting backend, new input system, x86-64 target architecture, and internal write permission are set correctly.
- Check **Project Settings > MagicLeap > Permissions > API Level 29**.
- In **Project Settings > XR Plug-in Management**, enable the OpenXR Plugin and Magic Leap 2 feature groups.
- In **Project Settings > XR Plug-in Management > OpenXR > Enabled Interaction Profiles & Feature Groups**, check that the required interaction profiles, feature groups, and subsystems are enabled.
  - Magic Leap 2 Controller Interaction Profile, Eye Gaze Interaction Profile, and Hand Interaction Profile (if using hand tracking).
- In **Project Settings > XR Plug-in Management > Project Validation**, review that all checks pass successfully.
- In **Project Settings > MagicLeap > Permissions**, include all Android permissions that you anticipate your app needing.

After building (on device):

- Manually grant permissions (e.g., camera, voice input) in **Settings > Apps & Notifications > App info > your-app > Permissions**.
- For the Voice Commands sample, enable Voice Commands in the device at **Settings > Magic Leap Inputs > Voice**.

---

## Build and Installation

To install an .apk to your Magic Leap 2, enable [Developer Mode](https://developer-docs.magicleap.cloud/docs/guides/getting-started/enable-developer-mode/). Then, connect it to your computer via USB-C and use [Magic Leap Hub 3](https://developer-docs.magicleap.cloud/docs/guides/developer-tools/ml-hub-3/get-started/) > Device Bridge.

**If your computer has a USB-A port, you may need to use a USB-A-to-C cable.*
